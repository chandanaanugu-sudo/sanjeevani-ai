export type CapabilityType = 
  | 'Cath Lab (STEMI)'
  | 'Level 1 Trauma'
  | 'Pediatric ICU'
  | 'Comprehensive Stroke Center'
  | 'Burn Center'
  | 'General ER';

export interface Hospital {
  id: string;
  name: string;
  shortCode: string;
  address: string;
  lat: number;
  lng: number;
  traumaLevel: 1 | 2 | 3;
  capabilities: CapabilityType[];
  beds: {
    totalER: number;
    availableER: number;
    totalICU: number;
    availableICU: number;
    reservedBeds: number;
  };
  status: 'optimal' | 'busy' | 'saturated' | 'diverting';
  opdWaitMinutes: number;
  phone: string;
}

export interface VitalsTelemetry {
  heartRate: number;
  bloodPressure: string;
  spo2: number;
  respiratoryRate: number;
  gcs: number; // Glasgow Coma Scale (3-15)
  ecgRhythm: 'Normal Sinus' | 'ST-Elevation (STEMI)' | 'Ventricular Fibrillation' | 'Sinus Tachycardia' | 'Atrial Fibrillation';
  temperature: number;
  timestamp: string;
}

export interface ClinicalSBAR {
  situation: string;
  background: string;
  assessment: string;
  recommendation: string;
  prepChecklist: string[];
}

export interface EmergencyIncident {
  id: string;
  patientName: string;
  age: number;
  gender: 'M' | 'F' | 'Other';
  contactPhone: string;
  reportedTime: string;
  location: {
    lat: number;
    lng: number;
    addressText: string;
  };
  chiefComplaint: string;
  voiceTranscript?: string;
  language?: string;
  esiLevel: 1 | 2 | 3 | 4 | 5; // ESI: 1 = Resuscitation, 2 = Emergent, 3 = Urgent, 4 = Less Urgent, 5 = Non-urgent
  requiredCapabilities: CapabilityType[];
  status: 'reported' | 'ambulance_dispatched' | 'in_transit' | 'handing_off' | 'admitted';
  assignedAmbulanceId?: string;
  assignedHospitalId: string;
  lockedBedNumber?: string;
  reservationExpiresAt?: number; // epoch timestamp
  clinicalSbar?: ClinicalSBAR;
  familyTrackingCode: string;
}

export interface Ambulance {
  id: string;
  callSign: string;
  driverName: string;
  paramedicName: string;
  status: 'idle' | 'dispatched' | 'en_route_pickup' | 'on_scene' | 'transporting' | 'diverted' | 'arrived';
  currentLocation: {
    lat: number;
    lng: number;
  };
  destinationHospitalId: string;
  assignedIncidentId?: string;
  patientVitals: VitalsTelemetry;
  etaMinutes: number;
  isDiverted: boolean;
  diversionHistory?: {
    fromHospitalId: string;
    toHospitalId: string;
    reason: string;
    timestamp: string;
  };
}

export interface OPDToken {
  id: string;
  tokenNumber: string;
  department: 'Cardiology' | 'Orthopedics' | 'General Medicine' | 'Pediatrics' | 'Neurology';
  patientName: string;
  doctorName: string;
  roomNumber: string;
  status: 'waiting_at_home' | 'traveling' | 'in_waiting_room' | 'in_consultation' | 'completed';
  issuedAt: string;
  estimatedConsultationTime: string;
  recommendedLeaveHomeTime: string;
  currentTokenServing: string;
  peopleAhead: number;
  dynamicDelayMinutes: number;
}

export interface SurgeForecast {
  predictedArrivalsNext60m: number;
  currentCapacityPct: number;
  projectedCapacityPct: number;
  riskLevel: 'low' | 'moderate' | 'critical';
  recommendation: string;
}


// ==================== SUPPLYSHIELD ====================

export type MedicineCategory =
  | 'Emergency'
  | 'Cardiology'
  | 'Antibiotic'
  | 'Pediatric'
  | 'General';

export type StockRiskLevel =
  | 'safe'
  | 'moderate'
  | 'high'
  | 'critical';

export interface MedicineInventory {
  id: string;
  hospitalId: string;
  medicineName: string;
  category: MedicineCategory;
  currentStock: number;
  minimumStock: number;
  dailyDemand: number;
  weeklyDemand: number[];
  unit: string;
  supplierId: string;
  lastRestockedAt: string;
  expectedDeliveryAt?: string;
}

export interface MedicineSupplier {
  id: string;
  name: string;
  location: string;
  reliabilityScore: number;
  averageDeliveryHours: number;
  availableMedicines: string[];
}
