import { useState, useEffect } from 'react';
import type { Hospital, Ambulance, EmergencyIncident, OPDToken, SurgeForecast, CapabilityType, MedicineInventory, MedicineSupplier } from '../types';
import { audioService } from '../services/audioService';
import { CLINICAL_PRESETS } from '../services/geminiTriage';
import type { TriageResult } from '../services/geminiTriage';
import {
  calculateStockoutPrediction,
  buildRedistributionRecommendation,
  type StockoutPrediction,
  type RedistributionRecommendation
} from '../services/supplyShield';

// Initial pre-seeded hospitals with realistic spatial coordinates & clinical capabilities
const INITIAL_HOSPITALS: Hospital[] = [
  {
    id: 'hosp-apollo',
    name: 'Apollo Trauma & Heart Institute',
    shortCode: 'ATHI',
    address: 'Central Health Corridor, Zone 1',
    lat: 12.9716,
    lng: 77.5946,
    traumaLevel: 1,
    capabilities: ['Cath Lab (STEMI)', 'Level 1 Trauma', 'Pediatric ICU', 'General ER'],
    beds: {
      totalER: 16,
      availableER: 4,
      totalICU: 8,
      availableICU: 2,
      reservedBeds: 1,
    },
    status: 'optimal',
    opdWaitMinutes: 24,
    phone: '+91 80-2630-1000'
  },
  {
    id: 'hosp-citycare',
    name: 'City Care Comprehensive Stroke & Neuro',
    shortCode: 'CCCS',
    address: 'Metro West Boulevard, Sector 4',
    lat: 12.9850,
    lng: 77.5800,
    traumaLevel: 2,
    capabilities: ['Comprehensive Stroke Center', 'Level 1 Trauma', 'General ER'],
    beds: {
      totalER: 12,
      availableER: 3,
      totalICU: 6,
      availableICU: 1,
      reservedBeds: 0,
    },
    status: 'optimal',
    opdWaitMinutes: 35,
    phone: '+91 80-4100-2200'
  },
  {
    id: 'hosp-fortis',
    name: 'Fortis Pediatric & Emergency Center',
    shortCode: 'FPEC',
    address: 'South Park Avenue, Hub 9',
    lat: 12.9600,
    lng: 77.6100,
    traumaLevel: 2,
    capabilities: ['Pediatric ICU', 'Burn Center', 'General ER'],
    beds: {
      totalER: 10,
      availableER: 3,
      totalICU: 5,
      availableICU: 2,
      reservedBeds: 0,
    },
    status: 'optimal',
    opdWaitMinutes: 18,
    phone: '+91 80-6621-4400'
  },
  {
    id: 'hosp-metro',
    name: 'Metro General Regional Trauma Hospital',
    shortCode: 'MGRT',
    address: 'East Ring Road, Block C',
    lat: 12.9920,
    lng: 77.6250,
    traumaLevel: 1,
    capabilities: ['Cath Lab (STEMI)', 'Level 1 Trauma', 'Burn Center', 'General ER'],
    beds: {
      totalER: 20,
      availableER: 1,
      totalICU: 10,
      availableICU: 1,
      reservedBeds: 2,
    },
    status: 'busy',
    opdWaitMinutes: 50,
    phone: '+91 80-2299-8800'
  }
];

const INITIAL_AMBULANCES: Ambulance[] = [
  {
    id: 'amb-medic01',
    callSign: 'Medic-01 (Advanced ALS)',
    driverName: 'Rajesh Kumar',
    paramedicName: 'Sr. Paramedic Anjali Sharma',
    status: 'transporting',
    currentLocation: { lat: 12.9680, lng: 77.5890 },
    destinationHospitalId: 'hosp-apollo',
    assignedIncidentId: 'inc-demo-cardiac',
    patientVitals: {
      heartRate: 118,
      bloodPressure: '88/56',
      spo2: 91,
      respiratoryRate: 24,
      gcs: 14,
      ecgRhythm: 'ST-Elevation (STEMI)',
      temperature: 37.1,
      timestamp: new Date().toLocaleTimeString()
    },
    etaMinutes: 6,
    isDiverted: false
  },
  {
    id: 'amb-medic02',
    callSign: 'Medic-02 (Mobile ICU)',
    driverName: 'Vikram Singh',
    paramedicName: 'Paramedic Priya Nair',
    status: 'idle',
    currentLocation: { lat: 12.9810, lng: 77.6050 },
    destinationHospitalId: 'hosp-citycare',
    patientVitals: {
      heartRate: 74,
      bloodPressure: '120/80',
      spo2: 98,
      respiratoryRate: 16,
      gcs: 15,
      ecgRhythm: 'Normal Sinus',
      temperature: 36.6,
      timestamp: new Date().toLocaleTimeString()
    },
    etaMinutes: 0,
    isDiverted: false
  }
];

const INITIAL_INCIDENTS: EmergencyIncident[] = [
  {
    id: 'inc-demo-cardiac',
    patientName: 'Ramesh Verma',
    age: 58,
    gender: 'M',
    contactPhone: '+91 98450-23491',
    reportedTime: new Date(Date.now() - 8 * 60 * 1000).toLocaleTimeString(),
    location: {
      lat: 12.9650,
      lng: 77.5850,
      addressText: 'Flat 402, Green Glen Towers, Outer Ring Road'
    },
    chiefComplaint: CLINICAL_PRESETS.cardiac.chiefComplaint,
    esiLevel: 1,
    requiredCapabilities: ['Cath Lab (STEMI)', 'Level 1 Trauma'],
    status: 'in_transit',
    assignedAmbulanceId: 'amb-medic01',
    assignedHospitalId: 'hosp-apollo',
    lockedBedNumber: 'Trauma Resus Bay #2',
    reservationExpiresAt: Date.now() + 22 * 60 * 1000,
    clinicalSbar: CLINICAL_PRESETS.cardiac.clinicalSbar,
    familyTrackingCode: 'PULSE-7892'
  }
];

const INITIAL_OPD_TOKENS: OPDToken[] = [
  {
    id: 'tok-1',
    tokenNumber: 'CARD-101',
    department: 'Cardiology',
    patientName: 'Kavita Menon',
    doctorName: 'Dr. Sudhir Rao, MD (Cardiology)',
    roomNumber: 'Room 204',
    status: 'in_consultation',
    issuedAt: '09:00 AM',
    estimatedConsultationTime: '09:40 AM',
    recommendedLeaveHomeTime: 'Now In Clinic',
    currentTokenServing: 'CARD-101',
    peopleAhead: 0,
    dynamicDelayMinutes: 0
  },
  {
    id: 'tok-2',
    tokenNumber: 'CARD-102',
    department: 'Cardiology',
    patientName: 'Arjun Das',
    doctorName: 'Dr. Sudhir Rao, MD (Cardiology)',
    roomNumber: 'Room 204',
    status: 'in_waiting_room',
    issuedAt: '09:15 AM',
    estimatedConsultationTime: '09:55 AM',
    recommendedLeaveHomeTime: 'Arrived at Clinic',
    currentTokenServing: 'CARD-101',
    peopleAhead: 1,
    dynamicDelayMinutes: 5
  },
  {
    id: 'tok-3',
    tokenNumber: 'CARD-103',
    department: 'Cardiology',
    patientName: 'Pooja Iyer',
    doctorName: 'Dr. Sudhir Rao, MD (Cardiology)',
    roomNumber: 'Room 204',
    status: 'waiting_at_home',
    issuedAt: '09:30 AM',
    estimatedConsultationTime: '10:15 AM',
    recommendedLeaveHomeTime: 'Leave Home at 09:45 AM (15 min transit)',
    currentTokenServing: 'CARD-101',
    peopleAhead: 2,
    dynamicDelayMinutes: 10
  }
];


// ==================== SUPPLYSHIELD MEDICINE INVENTORY ====================

const INITIAL_MEDICINE_INVENTORY: MedicineInventory[] = [
  {
    id: 'med-atorvastatin-apollo',
    hospitalId: 'hosp-apollo',
    medicineName: 'Atorvastatin 40mg',
    category: 'Cardiology',
    currentStock: 120,
    minimumStock: 100,
    dailyDemand: 30,
    weeklyDemand: [18, 21, 23, 25, 27, 29, 30],
    unit: 'tablets',
    supplierId: 'supplier-medlife',
    lastRestockedAt: '2026-09-24T08:00:00Z',
    expectedDeliveryAt: '2026-09-29T10:00:00Z'
  },
  {
    id: 'med-aspirin-apollo',
    hospitalId: 'hosp-apollo',
    medicineName: 'Aspirin 75mg',
    category: 'Emergency',
    currentStock: 420,
    minimumStock: 150,
    dailyDemand: 35,
    weeklyDemand: [30, 32, 31, 33, 34, 35, 35],
    unit: 'tablets',
    supplierId: 'supplier-medlife',
    lastRestockedAt: '2026-09-23T08:00:00Z'
  },
  {
    id: 'med-atorvastatin-citycare',
    hospitalId: 'hosp-citycare',
    medicineName: 'Atorvastatin 40mg',
    category: 'Cardiology',
    currentStock: 360,
    minimumStock: 100,
    dailyDemand: 25,
    weeklyDemand: [20, 21, 22, 23, 24, 24, 25],
    unit: 'tablets',
    supplierId: 'supplier-healthfirst',
    lastRestockedAt: '2026-09-22T08:00:00Z'
  },
  {
    id: 'med-amoxicillin-fortis',
    hospitalId: 'hosp-fortis',
    medicineName: 'Amoxicillin 500mg',
    category: 'Antibiotic',
    currentStock: 80,
    minimumStock: 100,
    dailyDemand: 28,
    weeklyDemand: [15, 18, 20, 22, 24, 26, 28],
    unit: 'capsules',
    supplierId: 'supplier-healthfirst',
    lastRestockedAt: '2026-09-23T08:00:00Z'
  }
];

const INITIAL_MEDICINE_SUPPLIERS: MedicineSupplier[] = [
  {
    id: 'supplier-medlife',
    name: 'MedLife Distribution',
    location: 'Bengaluru',
    reliabilityScore: 94,
    averageDeliveryHours: 18,
    availableMedicines: [
      'Atorvastatin 40mg',
      'Aspirin 75mg'
    ]
  },
  {
    id: 'supplier-healthfirst',
    name: 'HealthFirst Pharma Logistics',
    location: 'Hyderabad',
    reliabilityScore: 89,
    averageDeliveryHours: 24,
    availableMedicines: [
      'Atorvastatin 40mg',
      'Amoxicillin 500mg'
    ]
  }
];

// BroadcastChannel for instant cross-tab / dual-screen sync
let broadcastChannel: BroadcastChannel | null = null;
try {
  broadcastChannel = new BroadcastChannel('pulsegrid_sync_bus');
} catch (e) {
  console.warn('BroadcastChannel not supported:', e);
}

// Global In-Memory Reactive Store
export interface EcosystemState {
  hospitals: Hospital[];
  ambulances: Ambulance[];
  incidents: EmergencyIncident[];
  opdTokens: OPDToken[];
  medicineInventory: MedicineInventory[];
  medicineSuppliers: MedicineSupplier[];
  supplyPredictions: StockoutPrediction[];
  redistributionRecommendations: RedistributionRecommendation[];
  selectedHospitalId: string;
  activeRole: 'patient' | 'ambulance' | 'hospital' | 'city';
  surgeForecast: SurgeForecast;
  notifications: Array<{ id: string; message: string; type: 'info' | 'warning' | 'alert' | 'diversion'; time: string }>;
}

let state: EcosystemState = {
  hospitals: INITIAL_HOSPITALS,
  ambulances: INITIAL_AMBULANCES,
  incidents: INITIAL_INCIDENTS,
  opdTokens: INITIAL_OPD_TOKENS,
  medicineInventory: INITIAL_MEDICINE_INVENTORY,
  medicineSuppliers: INITIAL_MEDICINE_SUPPLIERS,
  supplyPredictions: INITIAL_MEDICINE_INVENTORY.map(calculateStockoutPrediction),
  redistributionRecommendations: [],
  selectedHospitalId: 'hosp-apollo',
  activeRole: 'patient',
  surgeForecast: {
    predictedArrivalsNext60m: 7,
    currentCapacityPct: 78,
    projectedCapacityPct: 92,
    riskLevel: 'moderate',
    recommendation: 'Incoming STEMI + 3 OPD escalations projected. FastTrack non-urgent walk-ins to decompress ER Bay.'
  },
  notifications: [
    {
      id: 'n-1',
      message: 'Medic-01 in transit with Level 1 STEMI. Trauma Resus Bay #2 locked (22m remaining).',
      type: 'alert',
      time: 'Just now'
    }
  ]
};

const listeners = new Set<(s: EcosystemState) => void>();

function notifyAll() {
  listeners.forEach(fn => fn({ ...state }));
  if (broadcastChannel) {
    try {
      broadcastChannel.postMessage({ type: 'SYNC_STATE', payload: state });
    } catch (e) {
      console.warn('Broadcast send error:', e);
    }
  }
}

if (broadcastChannel) {
  broadcastChannel.onmessage = (event) => {
    if (event.data?.type === 'SYNC_STATE' && event.data.payload) {
      state = event.data.payload;
      listeners.forEach(fn => fn({ ...state }));
    }
  };
}

// Haversine distance calculator
export function calculateDistanceKm(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371; // km
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Number((R * c).toFixed(1));
}

// THE UNFAIR ADVANTAGE: Capability-Based Hospital Matching Engine
export function matchBestHospital(
  patientLat: number,
  patientLng: number,
  requiredCapabilities: CapabilityType[],
  excludeHospitalIds: string[] = []
): { hospital: Hospital; distanceKm: number; etaMinutes: number; scoreExplanation: string } | null {
  const candidates = state.hospitals.filter(h => 
    !excludeHospitalIds.includes(h.id) &&
    h.status !== 'saturated' &&
    h.status !== 'diverting' &&
    (h.beds.availableER > 0 || h.beds.availableICU > 0)
  );

  if (candidates.length === 0) {
    // Fallback to any hospital with open beds if none match all capabilities
    const fallback = state.hospitals.find(h => !excludeHospitalIds.includes(h.id) && h.beds.availableER > 0);
    if (!fallback) return null;
    const d = calculateDistanceKm(patientLat, patientLng, fallback.lat, fallback.lng);
    return {
      hospital: fallback,
      distanceKm: d,
      etaMinutes: Math.max(3, Math.round(d * 2.2)),
      scoreExplanation: 'Emergency fallback: Nearest facility with active resuscitation capability.'
    };
  }

  // Score candidate based on Capability Match (primary) + Distance (secondary) + Bed Vacancy (tertiary)
  const scored = candidates.map(h => {
    const matchedCaps = requiredCapabilities.filter(c => h.capabilities.includes(c));
    const capabilityScore = (matchedCaps.length / Math.max(1, requiredCapabilities.length)) * 100;
    const distanceKm = calculateDistanceKm(patientLat, patientLng, h.lat, h.lng);
    const bedBonus = (h.beds.availableICU * 5) + (h.beds.availableER * 2);
    const finalScore = capabilityScore * 2 - (distanceKm * 4) + bedBonus;

    return {
      hospital: h,
      distanceKm,
      etaMinutes: Math.max(3, Math.round(distanceKm * 2.2)),
      capabilityScore,
      scoreExplanation: `${matchedCaps.join(', ')} verified. ${h.beds.availableICU} ICU beds open.`
    };
  });

  scored.sort((a, b) => b.capabilityScore - a.capabilityScore || a.distanceKm - b.distanceKm);
  return scored[0];
}

// Action Creators
export const healthStore = {
  getState: () => state,

  setActiveRole: (role: EcosystemState['activeRole']) => {
    state = { ...state, activeRole: role };
    notifyAll();
  },

  setSelectedHospitalId: (id: string) => {
    state = { ...state, selectedHospitalId: id };
    notifyAll();
  },

  // 1. One-Tap Emergency Trigger with Instant Bed Reservation
  createEmergencySOS: (
    patientName: string,
    chiefComplaint: string,
    triage: TriageResult,
    patientLocation: { lat: number; lng: number; addressText: string }
  ): { incident: EmergencyIncident; matchedHospital: Hospital; ambulance: Ambulance } => {
    const matched = matchBestHospital(patientLocation.lat, patientLocation.lng, triage.requiredCapabilities);
    const targetHospital = matched ? matched.hospital : state.hospitals[0];

    const incidentId = `inc-${Date.now()}`;
    const ambulanceId = `amb-medic01`;
    const bayNumber = `Trauma Bay #${Math.floor(Math.random() * 4) + 1}`;

    const newIncident: EmergencyIncident = {
      id: incidentId,
      patientName,
      age: 52,
      gender: 'M',
      contactPhone: '+91 99887-11223',
      reportedTime: new Date().toLocaleTimeString(),
      location: patientLocation,
      chiefComplaint,
      esiLevel: triage.esiLevel,
      requiredCapabilities: triage.requiredCapabilities,
      status: 'ambulance_dispatched',
      assignedAmbulanceId: ambulanceId,
      assignedHospitalId: targetHospital.id,
      lockedBedNumber: bayNumber,
      reservationExpiresAt: Date.now() + 30 * 60 * 1000, // 30-minute lock
      clinicalSbar: triage.clinicalSbar,
      familyTrackingCode: `PULSE-${Math.floor(1000 + Math.random() * 9000)}`
    };

    // Update Hospital Bed Reservation
    const updatedHospitals = state.hospitals.map(h => {
      if (h.id === targetHospital.id) {
        return {
          ...h,
          beds: {
            ...h.beds,
            availableER: Math.max(0, h.beds.availableER - 1),
            reservedBeds: h.beds.reservedBeds + 1
          }
        };
      }
      return h;
    });

    // Update Ambulance
    const updatedAmbulances = state.ambulances.map(a => {
      if (a.id === ambulanceId) {
        return {
          ...a,
          status: 'transporting' as const,
          destinationHospitalId: targetHospital.id,
          assignedIncidentId: incidentId,
          etaMinutes: matched?.etaMinutes || 7,
          isDiverted: false
        };
      }
      return a;
    });

    state = {
      ...state,
      hospitals: updatedHospitals,
      ambulances: updatedAmbulances,
      incidents: [newIncident, ...state.incidents],
      notifications: [
        {
          id: `n-${Date.now()}`,
          message: `🚨 CODE RED: ${triage.chiefComplaint}. ${bayNumber} locked at ${targetHospital.name}.`,
          type: 'alert',
          time: 'Just now'
        },
        ...state.notifications
      ]
    };

    audioService.playCodeRedAlert();
    notifyAll();

    return {
      incident: newIncident,
      matchedHospital: targetHospital,
      ambulance: updatedAmbulances.find(a => a.id === ambulanceId)!
    };
  },

  // 2. THE WINNING DEMO TRIGGER: Mid-Transit Predictive Auto-Diversion
  triggerMidTransitAutoDiversion: (ambulanceId: string) => {
    const ambulance = state.ambulances.find(a => a.id === ambulanceId);
    if (!ambulance) return;

    const currentHospId = ambulance.destinationHospitalId;
    const currentHosp = state.hospitals.find(h => h.id === currentHospId);
    const incident = state.incidents.find(i => i.id === ambulance.assignedIncidentId);

    // Freeze current hospital due to sudden catastrophic surge
    const updatedHospitals = state.hospitals.map(h => {
      if (h.id === currentHospId) {
        return {
          ...h,
          status: 'saturated' as const,
          beds: { ...h.beds, availableER: 0, availableICU: 0 }
        };
      }
      return h;
    });

    // Re-route to the next best capability-matched hospital
    const requiredCaps = incident?.requiredCapabilities || ['Level 1 Trauma'];
    const matched = matchBestHospital(
      ambulance.currentLocation.lat,
      ambulance.currentLocation.lng,
      requiredCaps,
      [currentHospId] // Exclude current overloaded hospital
    );

    const newTarget = matched ? matched.hospital : state.hospitals.find(h => h.id !== currentHospId)!;
    const newBay = `Emergency Resus Bay #${Math.floor(Math.random() * 3) + 1}`;

    const updatedAmbulances = state.ambulances.map(a => {
      if (a.id === ambulanceId) {
        return {
          ...a,
          destinationHospitalId: newTarget.id,
          etaMinutes: (matched?.etaMinutes || 5) + 3,
          isDiverted: true,
          diversionHistory: {
            fromHospitalId: currentHospId,
            toHospitalId: newTarget.id,
            reason: 'Primary facility reached 100% ICU/Cath Lab saturation. Auto-diverted to prevent golden-hour mortality.',
            timestamp: new Date().toLocaleTimeString()
          }
        };
      }
      return a;
    });

    const updatedIncidents = state.incidents.map(inc => {
      if (inc.id === ambulance.assignedIncidentId) {
        return {
          ...inc,
          assignedHospitalId: newTarget.id,
          lockedBedNumber: newBay,
          reservationExpiresAt: Date.now() + 30 * 60 * 1000
        };
      }
      return inc;
    });

    state = {
      ...state,
      hospitals: updatedHospitals,
      ambulances: updatedAmbulances,
      incidents: updatedIncidents,
      notifications: [
        {
          id: `div-${Date.now()}`,
          message: `🔄 AUTO-DIVERSION TRIGGERED: ${currentHosp?.name} saturated. ${ambulance.callSign} rerouted to ${newTarget.name} (${newBay} locked).`,
          type: 'diversion',
          time: 'Just now'
        },
        ...state.notifications
      ]
    };

    audioService.playDiversionSound();
    notifyAll();
  },

  // 3. Dynamic OPD Queue Booking
  bookOPDToken: (patientName: string, department: OPDToken['department']) => {
    const existingInDept = state.opdTokens.filter(t => t.department === department);
    const count = existingInDept.length + 1;
    const tokenNumber = `${department.slice(0, 4).toUpperCase()}-${100 + count}`;
    const delayMins = 12 * (count - 1);

    const now = new Date();
    const consultTime = new Date(now.getTime() + delayMins * 60000);
    const leaveHomeTime = new Date(consultTime.getTime() - 20 * 60000); // 20 min commute

    const newToken: OPDToken = {
      id: `tok-${Date.now()}`,
      tokenNumber,
      department,
      patientName,
      doctorName: department === 'Cardiology' ? 'Dr. Sudhir Rao, MD' : 'Dr. Neha Kapoor, MS',
      roomNumber: department === 'Cardiology' ? 'Room 204' : 'Room 108',
      status: count === 1 ? 'in_consultation' : count <= 2 ? 'in_waiting_room' : 'waiting_at_home',
      issuedAt: now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      estimatedConsultationTime: consultTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      recommendedLeaveHomeTime: count <= 2 ? 'Now in Clinic' : `Leave home at ${leaveHomeTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`,
      currentTokenServing: existingInDept[0]?.tokenNumber || tokenNumber,
      peopleAhead: Math.max(0, count - 1),
      dynamicDelayMinutes: 0
    };

    state = {
      ...state,
      opdTokens: [...state.opdTokens, newToken],
      notifications: [
        {
          id: `opd-${Date.now()}`,
          message: `🎫 Token ${tokenNumber} generated for ${patientName}. Dynamic Home Wait active.`,
          type: 'info',
          time: 'Just now'
        },
        ...state.notifications
      ]
    };

    audioService.playTokenChime();
    notifyAll();
    return newToken;
  },

  // 4. Call Next OPD Patient
  callNextOPDToken: (department: OPDToken['department']) => {
    const inDept = state.opdTokens.filter(t => t.department === department && t.status !== 'completed');
    if (inDept.length === 0) return;

    const currentServing = inDept[0];
    const nextServing = inDept[1];

    const updatedTokens = state.opdTokens.map(t => {
      if (t.id === currentServing.id) {
        return { ...t, status: 'completed' as const };
      }
      if (nextServing && t.id === nextServing.id) {
        return { ...t, status: 'in_consultation' as const, peopleAhead: 0 };
      }
      if (t.department === department && t.status !== 'completed') {
        const remainingAhead = Math.max(0, t.peopleAhead - 1);
        return {
          ...t,
          peopleAhead: remainingAhead,
          currentTokenServing: nextServing ? nextServing.tokenNumber : 'All Done',
          status: remainingAhead === 0 ? 'in_consultation' as const : remainingAhead === 1 ? 'in_waiting_room' as const : 'waiting_at_home' as const
        };
      }
      return t;
    });

    state = {
      ...state,
      opdTokens: updatedTokens
    };

    audioService.playTokenChime();
    notifyAll();
  },

  // 5. Broadcast Doctor Delay (Dynamic Rescheduling)
  broadcastDoctorDelay: (department: OPDToken['department'], extraMinutes: number) => {
    const updatedTokens = state.opdTokens.map(t => {
      if (t.department === department && t.status !== 'completed') {
        const newDelay = t.dynamicDelayMinutes + extraMinutes;
        return {
          ...t,
          dynamicDelayMinutes: newDelay,
          recommendedLeaveHomeTime: `Pushed by +${newDelay}m: Consult estimated later`
        };
      }
      return t;
    });

    state = {
      ...state,
      opdTokens: updatedTokens,
      notifications: [
        {
          id: `del-${Date.now()}`,
          message: `⚠️ Dynamic Pacing: ${department} clinic delayed by ${extraMinutes}m. Home-waiting patients notified to stay home longer.`,
          type: 'warning',
          time: 'Just now'
        },
        ...state.notifications
      ]
    };

    notifyAll();
  },

  // 7. SupplyShield: Generate stockout predictions
  generateSupplyPredictions: () => {
    const predictions =
      state.medicineInventory.map(calculateStockoutPrediction);

    state = {
      ...state,
      supplyPredictions: predictions
    };

    notifyAll();
    return predictions;
  },

  // 8. SupplyShield: Simulate a sudden medicine demand spike
  simulateMedicineDemandSpike: (
    medicineId: string = 'med-atorvastatin-apollo',
    multiplier: number = 1.5
  ) => {
    const updatedInventory = state.medicineInventory.map(item => {
      if (item.id !== medicineId) return item;

      const newDailyDemand = Math.ceil(
        item.dailyDemand * multiplier
      );

      return {
        ...item,
        dailyDemand: newDailyDemand,
        weeklyDemand: [
          ...item.weeklyDemand.slice(-6),
          newDailyDemand
        ]
      };
    });

    const predictions =
      updatedInventory.map(calculateStockoutPrediction);

    const recommendations =
      updatedInventory
        .filter(
          item =>
            predictions.find(
              prediction => prediction.medicineId === item.id
            )?.riskLevel === 'critical' ||
            predictions.find(
              prediction => prediction.medicineId === item.id
            )?.riskLevel === 'high'
        )
        .map(item =>
          buildRedistributionRecommendation(
            item,
            updatedInventory
          )
        )
        .filter(
          (recommendation): recommendation is RedistributionRecommendation =>
            recommendation !== null
        );

    state = {
      ...state,
      medicineInventory: updatedInventory,
      supplyPredictions: predictions,
      redistributionRecommendations: recommendations,
      notifications: [
        {
          id: `supply-spike-${Date.now()}`,
          message:
            `📦 SUPPLYSHIELD ALERT: Demand spike detected for ${updatedInventory.find(item => item.id === medicineId)?.medicineName || 'medicine'}. Stockout risk recalculated.`,
          type: 'warning',
          time: 'Just now'
        },
        ...state.notifications
      ]
    };

    notifyAll();
    return {
      predictions,
      recommendations
    };
  },

  // 9. SupplyShield: Reset demo scenario
  resetSupplyShieldDemo: () => {
    const inventory = INITIAL_MEDICINE_INVENTORY.map(item => ({
      ...item,
      weeklyDemand: [...item.weeklyDemand]
    }));

    state = {
      ...state,
      medicineInventory: inventory,
      supplyPredictions: inventory.map(calculateStockoutPrediction),
      redistributionRecommendations: []
    };

    notifyAll();
  },

  // 9. SupplyShield: Generate smart redistribution recommendations
  generateRedistributionRecommendations: () => {
    const recommendations =
      state.medicineInventory
        .map(item =>
          buildRedistributionRecommendation(
            item,
            state.medicineInventory
          )
        )
        .filter(
          (recommendation): recommendation is RedistributionRecommendation =>
            recommendation !== null
        );

    state = {
      ...state,
      redistributionRecommendations: recommendations
    };

    notifyAll();
    return recommendations;
  },

  // 10. SupplyShield: Approve a medicine transfer
  approveRedistribution: (recommendationId: string) => {
    const recommendation =
      state.redistributionRecommendations.find(
        item => item.id === recommendationId
      );

    if (!recommendation) return false;

    const updatedInventory =
      state.medicineInventory.map(item => {
        if (
          item.hospitalId === recommendation.sourceHospitalId &&
          item.medicineName === recommendation.medicineName
        ) {
          return {
            ...item,
            currentStock:
              item.currentStock - recommendation.quantity
          };
        }

        if (
          item.hospitalId === recommendation.destinationHospitalId &&
          item.medicineName === recommendation.medicineName
        ) {
          return {
            ...item,
            currentStock:
              item.currentStock + recommendation.quantity
          };
        }

        return item;
      });

    const predictions =
      updatedInventory.map(calculateStockoutPrediction);

    state = {
      ...state,
      medicineInventory: updatedInventory,
      supplyPredictions: predictions,
      redistributionRecommendations:
        state.redistributionRecommendations.filter(
          item => item.id !== recommendationId
        ),
      notifications: [
        {
          id: `supply-transfer-${Date.now()}`,
          message:
            `✅ SUPPLYSHIELD TRANSFER APPROVED: ${recommendation.quantity} ${recommendation.medicineName} moved between hospitals.`,
          type: 'info',
          time: 'Just now'
        },
        ...state.notifications
      ]
    };

    notifyAll();
    return true;
  },

  // 6. Release or Admit Bed
  admitIncidentPatient: (incidentId: string) => {
    const updatedIncidents = state.incidents.map(inc => {
      if (inc.id === incidentId) {
        return { ...inc, status: 'admitted' as const };
      }
      return inc;
    });

    state = {
      ...state,
      incidents: updatedIncidents,
      notifications: [
        {
          id: `adm-${Date.now()}`,
          message: `✅ Clinical Handoff Complete: Patient admitted to Resuscitation Bay. Bed reservation fulfilled.`,
          type: 'info',
          time: 'Just now'
        },
        ...state.notifications
      ]
    };

    notifyAll();
  }
};

// React hook to access state
export function useHealthEcosystem() {
  const [storeState, setStoreState] = useState<EcosystemState>(state);

  useEffect(() => {
    listeners.add(setStoreState);
    return () => {
      listeners.delete(setStoreState);
    };
  }, []);

  return {
    ...storeState,
    actions: healthStore
  };
}
