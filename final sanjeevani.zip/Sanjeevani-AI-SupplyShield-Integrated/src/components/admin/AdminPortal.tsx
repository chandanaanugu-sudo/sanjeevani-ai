import React, { useState, useEffect, useRef } from 'react';
import { 
  Building2, 
  ShieldAlert, 
  Clock, 
  CheckCircle2, 
  Users, 
  Volume2, 
  VolumeX,
  ChevronRight, 
  AlertTriangle,
  UserPlus,
  Calendar,
  Activity,
  Heart,
  Ambulance,
  Printer,
  Sparkles,
  Lock,
  LogOut,
  ArrowRight,
  Stethoscope,
  Radio,
  FileText,
  BadgeAlert,
  Search,
  BellRing,
  RefreshCw,
  RotateCcw,
  Phone,
  MapPin,
  Package
} from 'lucide-react';
import { MapContainer, TileLayer, Marker, Popup, Polyline } from 'react-leaflet';
import L from 'leaflet';
import { useHealthEcosystem } from '../../store/healthEcosystemStore';
import { CityNetworkMap } from '../city/CityNetworkMap';
import { SupplyShieldDashboard } from './SupplyShieldDashboard';
import { 
  supabase, 
  fetchOpdTokens, 
  insertOpdToken,
  updateTokenStatus, 
  fetchLatestActiveSos, 
  resolveEmergencySos,
  type SupabaseOpdToken 
} from '../../services/supabaseClient';

// ============================================================================
// 🗺️ LEAFLET EMERGENCY GPS MAP ICONS FOR ADMIN TRAUMA ER
// ============================================================================
const adminPatientIcon = L.divIcon({
  className: 'custom-admin-pat',
  html: '<div class="w-10 h-10 rounded-full bg-rose-600 border-2 border-white flex items-center justify-center text-white text-base shadow-2xl shadow-rose-950 animate-bounce font-bold">📍</div>',
  iconSize: [40, 40],
  iconAnchor: [20, 20]
});

const adminHospIcon = L.divIcon({
  className: 'custom-admin-hosp',
  html: '<div class="w-10 h-10 rounded-xl bg-indigo-600 border-2 border-white flex items-center justify-center text-white text-base shadow-2xl shadow-indigo-950 font-bold">🏥</div>',
  iconSize: [40, 40],
  iconAnchor: [20, 20]
});

const adminAmbIcon = L.divIcon({
  className: 'custom-admin-amb',
  html: '<div class="w-11 h-11 rounded-full bg-amber-500 border-2 border-white flex items-center justify-center text-white text-lg shadow-2xl shadow-amber-950 animate-pulse font-bold">🚑</div>',
  iconSize: [44, 44],
  iconAnchor: [22, 22]
});

// ============================================================================
// 🎵 ROBUST 108 AMBULANCE SIREN & AUDIO SYNTHESIZERS
// ============================================================================

// Generate pure 108 ambulance two-tone hi-lo PCM WAV (960Hz <-> 770Hz loop)
function createSirenWavUri(): string {
  try {
    const sampleRate = 22050;
    const duration = 1.8;
    const numSamples = Math.floor(sampleRate * duration);
    const buffer = new ArrayBuffer(44 + numSamples);
    const view = new DataView(buffer);

    view.setUint32(0, 0x52494646, false); // "RIFF"
    view.setUint32(4, 36 + numSamples, true);
    view.setUint32(8, 0x57415645, false); // "WAVE"
    view.setUint32(12, 0x666d7420, false); // "fmt "
    view.setUint32(16, 16, true);
    view.setUint16(20, 1, true); // PCM
    view.setUint16(22, 1, true); // Mono
    view.setUint32(24, sampleRate, true);
    view.setUint32(28, sampleRate, true);
    view.setUint16(32, 1, true);
    view.setUint16(34, 8, true); // 8-bit
    view.setUint32(36, 0x64617461, false); // "data"
    view.setUint32(40, numSamples, true);

    const bytes = new Uint8Array(buffer, 44, numSamples);
    for (let i = 0; i < numSamples; i++) {
      const t = i / sampleRate;
      const cycle = Math.floor(t / 0.45) % 2;
      const freq = cycle === 0 ? 960 : 770;
      const phase = (t * freq) % 1;
      // High-volume square/saw wave
      bytes[i] = phase < 0.5 ? 205 : 50;
    }

    let binary = '';
    const headerBytes = new Uint8Array(buffer, 0, 44);
    for (let i = 0; i < 44; i++) binary += String.fromCharCode(headerBytes[i]);
    for (let i = 0; i < numSamples; i++) binary += String.fromCharCode(bytes[i]);
    return 'data:audio/wav;base64,' + btoa(binary);
  } catch (e) {
    return '';
  }
}

// Multi-Strategy 108 Emergency Siren: Web Audio API Sawtooth + HTML5 Audio WAV Loop + Pre-Warm
class AdminAmbulanceSiren {
  private ctx: AudioContext | null = null;
  private osc: OscillatorNode | null = null;
  private gain: GainNode | null = null;
  private timer: number | null = null;
  private htmlAudio: HTMLAudioElement | null = null;
  public isPlaying: boolean = false;
  private wavUri: string = '';

  constructor() {
    this.wavUri = createSirenWavUri();
  }

  // Pre-warm audio on user touch/click/key/focus
  warmup() {
    try {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!this.ctx && AudioCtx) {
        this.ctx = new AudioCtx();
      }
      if (this.ctx && this.ctx.state === 'suspended') {
        this.ctx.resume().catch(() => {});
      }
    } catch (e) {}
  }

  start() {
    this.isPlaying = true;
    this.startWebAudio();
    this.startHtmlAudio();
  }

  private startWebAudio() {
    try {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) return;

      if (!this.ctx || this.ctx.state === 'closed') {
        this.ctx = new AudioCtx();
      }

      if (this.ctx.state === 'suspended') {
        this.ctx.resume().catch(() => {});
      }

      // Stop previous osc if any to start fresh
      if (this.osc) {
        try { this.osc.stop(); this.osc.disconnect(); } catch (e) {}
        this.osc = null;
      }
      if (this.timer !== null) {
        clearInterval(this.timer);
        this.timer = null;
      }

      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const filter = this.ctx.createBiquadFilter();

      osc.type = 'sawtooth';
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(2400, this.ctx.currentTime);
      gain.gain.setValueAtTime(0.5, this.ctx.currentTime);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start();

      this.osc = osc;
      this.gain = gain;

      let isHigh = true;
      const switchTone = () => {
        if (!this.isPlaying || !this.ctx || !this.osc) return;
        const targetFreq = isHigh ? 960 : 770;
        this.osc.frequency.setTargetAtTime(targetFreq, this.ctx.currentTime, 0.03);
        isHigh = !isHigh;
      };

      switchTone();
      this.timer = window.setInterval(switchTone, 450);
    } catch (e) {
      console.warn('WebAudio siren start error:', e);
    }
  }

  private startHtmlAudio() {
    try {
      if (!this.htmlAudio) {
        this.htmlAudio = new Audio('/ambulance_siren.wav');
        this.htmlAudio.loop = true;
        this.htmlAudio.volume = 1.0;
      }
      this.htmlAudio.currentTime = 0;
      const p = this.htmlAudio.play();
      if (p && typeof p.catch === 'function') {
        p.catch(() => {
          // If relative path blocked, try synthesized data URI fallback
          try {
            if (this.wavUri) {
              const b64 = new Audio(this.wavUri);
              b64.loop = true;
              b64.volume = 1.0;
              b64.play().catch(() => {});
            }
          } catch (e) {}
        });
      }
    } catch (e) {}
  }

  stop() {
    this.isPlaying = false;
    if (this.timer !== null) {
      clearInterval(this.timer);
      this.timer = null;
    }
    if (this.gain && this.ctx) {
      try {
        this.gain.gain.setTargetAtTime(0.0001, this.ctx.currentTime, 0.03);
      } catch (e) {}
    }
    setTimeout(() => {
      try {
        this.osc?.stop();
        this.osc?.disconnect();
      } catch (e) {}
      this.osc = null;
      this.gain = null;
    }, 50);

    if (this.htmlAudio) {
      try {
        this.htmlAudio.pause();
        this.htmlAudio.currentTime = 0;
      } catch (e) {}
    }
  }
}

const adminSiren = new AdminAmbulanceSiren();

// Audio chime for calling patients
function playChimeSound() {
  try {
    const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(523.25, now); // C5
    osc.frequency.setValueAtTime(659.25, now + 0.12); // E5
    osc.frequency.setValueAtTime(783.99, now + 0.24); // G5
    gain.gain.setValueAtTime(0.35, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.6);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.6);
  } catch (e) {
    console.warn('Audio play error:', e);
  }
}

export interface UnifiedPatient {
  token: string;
  name: string;
  age: string | number;
  gender: string;
  problem: string;
  department: string;
  phone: string;
  source: 'online' | 'offline_kiosk';
  status: 'In Consultation' | 'In Waiting Lobby' | 'Safe at Home (Pacing)' | 'Completed';
  etaOrArriveTime: string;
  hospital?: string;
  email?: string;
  consultationTime?: string;
  leaveHomeTime?: string;
  bookingTime?: string;
}

const DEFAULT_INITIAL_PATIENTS: UnifiedPatient[] = [
  {
    token: 'SANJ-104',
    name: 'Kavita Menon',
    age: 48,
    gender: 'F',
    problem: 'Heart Palpitations & High Pulse',
    department: 'Cardiology (Heart Care)',
    hospital: 'Apollo Trauma & Heart Institute (Zone 1)',
    phone: '+91 98450-12841',
    email: 'kavita.m@gmail.com',
    source: 'online',
    status: 'In Consultation',
    etaOrArriveTime: 'Currently with Doctor (Room 204)',
    consultationTime: '09:45 AM',
    leaveHomeTime: '09:25 AM',
    bookingTime: '09:15 AM'
  },
  {
    token: 'SANJ-105',
    name: 'Arjun Das',
    age: 62,
    gender: 'M',
    problem: 'Post-CABG Blood Pressure Review',
    department: 'Cardiology (Heart Care)',
    hospital: 'Apollo Trauma & Heart Institute (Zone 1)',
    phone: '+91 97110-33421',
    email: 'arjun.das@outlook.com',
    source: 'offline_kiosk',
    status: 'In Waiting Lobby',
    etaOrArriveTime: 'Arrived at Counter (Lobby Seat #4)',
    consultationTime: '10:00 AM',
    leaveHomeTime: 'Arrived at Hospital Counter',
    bookingTime: '09:30 AM'
  },
  {
    token: 'SANJ-106',
    name: 'Pooja Iyer',
    age: 39,
    gender: 'F',
    problem: 'Chest Discomfort & Acidity Check',
    department: 'Cardiology (Heart Care)',
    hospital: 'Apollo Trauma & Heart Institute (Zone 1)',
    phone: '+91 94480-87612',
    email: 'pooja.iyer@gmail.com',
    source: 'online',
    status: 'Safe at Home (Pacing)',
    etaOrArriveTime: 'Leave Home at 10:45 AM (15m transit)',
    consultationTime: '10:15 AM',
    leaveHomeTime: '10:45 AM',
    bookingTime: '09:45 AM'
  }
];

export const AdminPortal: React.FC = () => {
  const { actions, ambulances } = useHealthEcosystem();

  // Authentication state (Restores saved staff session or enables demo)
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    return localStorage.getItem('sanjeevani_admin_auth') === 'true';
  });
  const [adminEmail, setAdminEmail] = useState('dr.sudhir.rao@apollo.health');
  const [adminPassword, setAdminPassword] = useState('Apollo#2026');
  const [selectedHospital, setSelectedHospital] = useState('Apollo Trauma & Heart Institute');
  const [authError, setAuthError] = useState('');

  // Active Admin Tab
  const [activeTab, setActiveTab] = useState<'queue' | 'calendar' | 'trauma' | 'map' | 'telemetry' | 'supply'>('queue');

  // Emergency Bed Hold State (30-min countdown)
  const [bedTimerSeconds, setBedTimerSeconds] = useState(24 * 60 + 12);
  const [patientAdmitted, setPatientAdmitted] = useState(false);

  // Active Emergency Alert & Ambulance Siren State
  const [isSirenActive, setIsSirenActive] = useState(false);
  const isSirenActiveRef = useRef<boolean>(false);
  const [showEmergencyModal, setShowEmergencyModal] = useState(false);
  const lastHandledSosTimestampRef = useRef<number>(0);
  const [emergencyAlertInfo, setEmergencyAlertInfo] = useState<{ 
    phone: string; 
    symptom: string; 
    location?: string;
    coords?: { lat: number; lng: number };
    hospitalCoords?: { lat: number; lng: number };
    bloodGroup?: string;
    hospitalName?: string;
    time: string;
    timestamp?: number;
  } | null>(null);

  // OPD Queue Management State (Persistent & Synchronized)
  const [currentServingToken, setCurrentServingToken] = useState<string>(() => {
    return localStorage.getItem('sanjeevani_current_serving') || 'SANJ-104';
  });
  const [delayMessage, setDelayMessage] = useState('');

  // Latest Online Booking State (Direct instantaneous sync across tabs)
  const [latestOnlineBooking, setLatestOnlineBooking] = useState<UnifiedPatient | null>(() => {
    try {
      const saved = localStorage.getItem('sanjeevani_latest_booking');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return null;
  });

  // Unified Patients Queue (Loaded from LocalStorage or Default)
  const [patients, setPatients] = useState<UnifiedPatient[]>(() => {
    try {
      const saved = localStorage.getItem('sanjeevani_unified_queue');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {}
    return DEFAULT_INITIAL_PATIENTS;
  });

  // Offline Walk-in Modal State (Sir / Mentor Requirement)
  const [isWalkInModalOpen, setIsWalkInModalOpen] = useState(false);
  const [walkInName, setWalkInName] = useState('');
  const [walkInAge, setWalkInAge] = useState('');
  const [walkInGender, setWalkInGender] = useState('Male');
  const [walkInPhone, setWalkInPhone] = useState('');
  const [walkInProblem, setWalkInProblem] = useState('Chest Heaviness & Breathing Shortness');
  const [walkInDept, setWalkInDept] = useState('Cardiology (Heart Care)');
  const [walkInPriority, setWalkInPriority] = useState<'Standard' | 'Senior Citizen' | 'Urgent Triaged'>('Standard');
  const [newlyPrintedSlip, setNewlyPrintedSlip] = useState<UnifiedPatient | null>(null);

  // Persistent BroadcastChannel Ref
  const busRef = useRef<BroadcastChannel | null>(null);

  // Bed hold countdown timer
  useEffect(() => {
    const interval = setInterval(() => {
      setBedTimerSeconds(prev => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  // Format timer
  const formatTimer = (s: number) => {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return `${m}:${sec < 10 ? '0' : ''}${sec}`;
  };

  // Helper to trigger Emergency Code Red in Admin
  const triggerEmergencyInAdmin = (payload: {
    phone?: string;
    symptom?: string;
    location?: string;
    coords?: { lat: number; lng: number };
    hospitalCoords?: { lat: number; lng: number };
    bloodGroup?: string;
    hospitalName?: string;
    time?: string;
    timestamp?: number;
  }, shouldSoundSiren: boolean = true) => {
    setActiveTab('trauma');
    setPatientAdmitted(false); // Reset admitted status for incoming emergency
    const pLat = payload.coords?.lat || 17.3850;
    const pLng = payload.coords?.lng || 78.4867;
    const hLat = payload.hospitalCoords?.lat || (pLat + 0.008);
    const hLng = payload.hospitalCoords?.lng || (pLng + 0.006);

    setEmergencyAlertInfo({
      phone: payload.phone || '+91 98450-23491',
      symptom: payload.symptom || 'Acute STEMI (Heart Attack)',
      location: payload.location || 'Metro City Center Area (Live GPS)',
      coords: { lat: pLat, lng: pLng },
      hospitalCoords: { lat: hLat, lng: hLng },
      bloodGroup: payload.bloodGroup || 'O+ (Positive)',
      hospitalName: payload.hospitalName || selectedHospital,
      time: payload.time || new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      timestamp: payload.timestamp || Date.now()
    });

    if (shouldSoundSiren) {
      setIsSirenActive(true);
      isSirenActiveRef.current = true;
      setShowEmergencyModal(true); // Red Alert popup with siren symbol and OK button
      adminSiren.start();
    } else {
      setIsSirenActive(false);
      isSirenActiveRef.current = false;
      setShowEmergencyModal(false);
      adminSiren.stop();
    }
  };

  // 1-Click Dismiss Emergency Siren ("OK" Button clicked by Admin)
  const handleDismissEmergencySiren = () => {
    adminSiren.stop();
    setIsSirenActive(false);
    isSirenActiveRef.current = false;
    setShowEmergencyModal(false);
    if (!isAuthenticated) {
      setIsAuthenticated(true);
      localStorage.setItem('sanjeevani_admin_auth', 'true');
    }
    setActiveTab('trauma');
  };

  // Patient Received Done Button handler ("last ki patient recieve ayyaka done ani kotte laga petesey")
  const handlePatientReceivedDone = () => {
    setPatientAdmitted(true);
    adminSiren.stop();
    setIsSirenActive(false);
    isSirenActiveRef.current = false;
    setShowEmergencyModal(false);
    playChimeSound();
    actions.admitIncidentPatient('inc-demo-cardiac');
    resolveEmergencySos();

    const admissionPayload = {
      status: 'Patient Received & Admitted',
      hospitalName: emergencyAlertInfo?.hospitalName || selectedHospital,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      bed: 'Trauma Bay #2 (Reserved & Locked)',
      doctor: 'Dr. Sudhir Rao, MD (Cardiology & Trauma In-Charge)',
      timestamp: Date.now()
    };

    try {
      localStorage.removeItem('sanjeevani_active_sos');
      localStorage.setItem('sanjeevani_patient_admitted_alert', JSON.stringify(admissionPayload));
      localStorage.setItem('sanjeevani_admission_ping', String(Date.now()));
    } catch (e) {}

    busRef.current?.postMessage({
      type: 'SOS_RESOLVED',
      payload: admissionPayload
    });
  };

  const handleResetEmergency = () => {
    setPatientAdmitted(false);
    setEmergencyAlertInfo(null);
    setIsSirenActive(false);
    isSirenActiveRef.current = false;
    setShowEmergencyModal(false);
    adminSiren.stop();
  };

  // =========================================================================
  // 🔄 HYBRID ENTERPRISE SYNCHRONIZATION: Supabase PostgreSQL Realtime + Local Fallback
  // =========================================================================
  useEffect(() => {
    // ⚡ 1. Initial Load from Supabase Database (MERGE with existing queue so newly booked patients are NEVER lost)
    fetchOpdTokens().then((rows) => {
      if (rows && rows.length > 0) {
        const mapped: UnifiedPatient[] = rows.map(r => ({
          token: r.token_number,
          name: r.patient_name,
          age: r.age,
          gender: r.gender,
          problem: r.problem,
          department: r.department,
          hospital: r.hospital,
          email: r.email,
          phone: r.phone,
          source: (r.token_number.includes('WALK') || r.status.includes('Lobby')) ? 'offline_kiosk' : 'online',
          status: (r.status as any) || 'Safe at Home (Pacing)',
          etaOrArriveTime: r.leave_home_time ? `Leave home at ${r.leave_home_time}` : 'Scheduled',
          consultationTime: r.consultation_time,
          leaveHomeTime: r.leave_home_time,
          bookingTime: r.created_at ? new Date(r.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : undefined
        }));
        
        setPatients(prev => {
          const map = new Map<string, UnifiedPatient>();
          mapped.forEach(p => map.set(p.token, p));
          prev.forEach(p => map.set(p.token, p));
          const merged = Array.from(map.values());
          try {
            localStorage.setItem('sanjeevani_unified_queue', JSON.stringify(merged));
          } catch (e) {}
          return merged;
        });
      }
    });

    // Check latest active SOS from Supabase (Populate dossier silently, DO NOT blast siren on initial page load)
    fetchLatestActiveSos().then((activeSos) => {
      if (activeSos && activeSos.status === 'Ambulance Dispatched') {
        triggerEmergencyInAdmin({
          phone: activeSos.phone,
          symptom: activeSos.symptoms,
          location: activeSos.location,
          bloodGroup: activeSos.blood_group,
          hospitalName: activeSos.hospital_name,
          time: new Date(activeSos.created_at || Date.now()).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }, false); // <--- false means NO SIREN on load!
      }
    });

    // ⚡ 2. Supabase Realtime Subscription (Zero-latency WebSockets)
    const realtimeChannel = supabase
      .channel('admin-dashboard-realtime')
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'opd_tokens' },
        (payload) => {
          const r = payload.new as SupabaseOpdToken;
          if (r) {
            const newEntry: UnifiedPatient = {
              token: r.token_number,
              name: r.patient_name,
              age: r.age,
              gender: r.gender,
              problem: r.problem,
              department: r.department,
              hospital: r.hospital || selectedHospital,
              email: r.email,
              phone: r.phone,
              source: (r.token_number.includes('WALK') || r.status.includes('Lobby')) ? 'offline_kiosk' : 'online',
              status: (r.status as any) || 'Safe at Home (Pacing)',
              etaOrArriveTime: r.leave_home_time ? `Leave home at ${r.leave_home_time}` : 'Scheduled',
              consultationTime: r.consultation_time,
              leaveHomeTime: r.leave_home_time,
              bookingTime: new Date(r.created_at || Date.now()).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
            };
            setLatestOnlineBooking(newEntry);
            setPatients(prev => {
              if (prev.some(p => p.token === r.token_number)) return prev;
              const updated = [...prev, newEntry];
              try {
                localStorage.setItem('sanjeevani_unified_queue', JSON.stringify(updated));
              } catch (e) {}
              return updated;
            });
            playChimeSound();
          }
        }
      )
      .on(
        'postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'opd_tokens' },
        (payload) => {
          const r = payload.new as SupabaseOpdToken;
          if (r) {
            setPatients(prev => prev.map(p => p.token === r.token_number ? { ...p, status: r.status as any } : p));
          }
        }
      )
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'emergency_sos' },
        (payload) => {
          const s = payload.new as any;
          if (s && s.status === 'Ambulance Dispatched') {
            triggerEmergencyInAdmin({
              phone: s.phone,
              symptom: s.symptoms,
              location: s.location,
              bloodGroup: s.blood_group,
              hospitalName: s.hospital_name,
              time: new Date(s.created_at || Date.now()).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
            });
          }
        }
      )
      .subscribe();

    try {
      const bus = new BroadcastChannel('sanjeevani_live_bus');
      busRef.current = bus;

      bus.onmessage = (e) => {
        // Event 1: New Patient Booked in Patient Portal
        if (e.data?.type === 'PATIENT_BOOKED' && e.data.payload) {
          const d = e.data.payload;
          const assignedToken = d.tokenNumber || d.token;
          const newEntry: UnifiedPatient = {
            token: assignedToken,
            name: d.name,
            age: d.age,
            gender: d.gender,
            problem: d.problem,
            department: d.department || 'Cardiology (Heart Care)',
            hospital: d.hospital || selectedHospital,
            phone: d.phone,
            email: d.email || '',
            source: 'online',
            status: 'Safe at Home (Pacing)',
            etaOrArriveTime: d.etaOrArriveTime || `Leave home at ${d.leaveHomeTime || '10:30 AM'} (${d.commuteMinutes || 20}m transit)`,
            consultationTime: d.consultationTime,
            leaveHomeTime: d.leaveHomeTime,
            bookingTime: d.bookingTime || new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
          };
          setLatestOnlineBooking(newEntry);
          setPatients(prev => {
            const exists = prev.some(p => p.token === assignedToken);
            const updated = exists 
              ? prev.map(p => p.token === assignedToken ? { ...p, ...newEntry } : p)
              : [...prev, newEntry];
            try {
              localStorage.setItem('sanjeevani_unified_queue', JSON.stringify(updated));
            } catch (err) {}
            return updated;
          });
          playChimeSound();
        }

        // Event 2: Emergency SOS Dispatched Live
        if (e.data?.type === 'SOS_DISPATCHED' && e.data.payload) {
          const ts = e.data.payload.timestamp || Date.now();
          lastHandledSosTimestampRef.current = ts;
          triggerEmergencyInAdmin(e.data.payload, true);
        }
      };
    } catch (err) {
      console.warn('BroadcastChannel error:', err);
    }

    // Storage Event Listener (Guaranteed cross-tab fallback)
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === 'sanjeevani_unified_queue' && e.newValue) {
        try {
          const parsed = JSON.parse(e.newValue);
          if (Array.isArray(parsed)) setPatients(parsed);
        } catch (err) {}
      }
      if (e.key === 'sanjeevani_latest_booking' && e.newValue) {
        try {
          const parsed = JSON.parse(e.newValue);
          if (parsed && parsed.token) {
            setLatestOnlineBooking(parsed);
            playChimeSound();
          }
        } catch (err) {}
      }
      if (e.key === 'sanjeevani_current_serving' && e.newValue) {
        setCurrentServingToken(e.newValue);
      }
      if (e.key === 'sanjeevani_active_sos' || e.key === 'sanjeevani_sos_ping') {
        const raw = localStorage.getItem('sanjeevani_active_sos');
        if (raw) {
          try {
            const parsed = JSON.parse(raw);
            if (parsed?.active) {
              lastHandledSosTimestampRef.current = parsed.timestamp || Date.now();
              triggerEmergencyInAdmin(parsed, true);
            }
          } catch (err) {}
        } else if (e.key === 'sanjeevani_active_sos' && !e.newValue) {
          // SOS cleared / resolved
          setEmergencyAlertInfo(null);
          setIsSirenActive(false);
          isSirenActiveRef.current = false;
          setShowEmergencyModal(false);
          adminSiren.stop();
        }
      }
    };

    window.addEventListener('storage', handleStorageChange);

    // Initial check for any active SOS in storage (Load data silently into dossier, DO NOT sound siren on initial page load!)
    try {
      const activeSos = localStorage.getItem('sanjeevani_active_sos');
      if (activeSos) {
        const parsed = JSON.parse(activeSos);
        if (parsed?.active) {
          lastHandledSosTimestampRef.current = parsed.timestamp || Date.now();
          triggerEmergencyInAdmin(parsed, false);
        }
      }
    } catch (err) {}

    // ⚡ 250ms FAST STORAGE POLLING: Guaranteed sync even if tabs background or cross-origin
    const pollInterval = window.setInterval(() => {
      // 1. Sync Queue
      try {
        const saved = localStorage.getItem('sanjeevani_unified_queue');
        if (saved) {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed) && parsed.length > 0) {
            setPatients(prev => {
              if (parsed.length !== prev.length || JSON.stringify(parsed) !== JSON.stringify(prev)) {
                return parsed;
              }
              return prev;
            });
          }
        }
      } catch (err) {}

      // 2. Sync Serving Token
      try {
        const savedServing = localStorage.getItem('sanjeevani_current_serving');
        if (savedServing) {
          setCurrentServingToken(prev => (prev !== savedServing ? savedServing : prev));
        }
      } catch (err) {}

      // 3. Sync Latest Online Booking
      try {
        const savedLatest = localStorage.getItem('sanjeevani_latest_booking');
        if (savedLatest) {
          const parsed = JSON.parse(savedLatest);
          if (parsed && parsed.token) {
            setLatestOnlineBooking(prev => {
              if (!prev || prev.token !== parsed.token || prev.status !== parsed.status) {
                return parsed;
              }
              return prev;
            });
          }
        }
      } catch (err) {}

      // 4. Sync Active SOS (Only blast siren if fresh dispatch from patient portal)
      try {
        const savedSos = localStorage.getItem('sanjeevani_active_sos');
        if (savedSos) {
          const parsed = JSON.parse(savedSos);
          if (parsed?.active) {
            const ts = parsed.timestamp || 0;
            const isRecent = (Date.now() - ts) < 180000;
            if (isRecent && ts > lastHandledSosTimestampRef.current) {
              lastHandledSosTimestampRef.current = ts;
              triggerEmergencyInAdmin(parsed, true);
            }
          }
        }
      } catch (err) {}
    }, 250);

    // ⚡ INSTANT UNMUTE ON ANY ACTION: Click, pointerdown, keydown, focus, tab visibility change
    const triggerAudioResume = () => {
      adminSiren.warmup();
      if (isSirenActiveRef.current) {
        adminSiren.start();
      }
    };

    window.addEventListener('pointerdown', triggerAudioResume);
    window.addEventListener('click', triggerAudioResume);
    window.addEventListener('keydown', triggerAudioResume);
    window.addEventListener('focus', triggerAudioResume);
    const handleVis = () => {
      if (document.visibilityState === 'visible') {
        triggerAudioResume();
      }
    };
    document.addEventListener('visibilitychange', handleVis);

    return () => {
      busRef.current?.close();
      supabase.removeChannel(realtimeChannel);
      window.removeEventListener('storage', handleStorageChange);
      window.removeEventListener('pointerdown', triggerAudioResume);
      window.removeEventListener('click', triggerAudioResume);
      window.removeEventListener('keydown', triggerAudioResume);
      window.removeEventListener('focus', triggerAudioResume);
      document.removeEventListener('visibilitychange', handleVis);
      window.clearInterval(pollInterval);
      adminSiren.stop();
    };
  }, []);

  // Handle Login
  const handleLogin = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!adminEmail.includes('@') || adminPassword.length < 4) {
      setAuthError('Please enter valid staff credentials');
      return;
    }
    setAuthError('');
    setIsAuthenticated(true);
    localStorage.setItem('sanjeevani_admin_auth', 'true');
    playChimeSound();
  };

  // 1-Click Demo Login
  const handleQuickDemoLogin = () => {
    setAdminEmail('dr.sudhir.rao@apollo.health');
    setAdminPassword('Apollo#2026');
    setSelectedHospital('Apollo Trauma & Heart Institute');
    setIsAuthenticated(true);
    localStorage.setItem('sanjeevani_admin_auth', 'true');
    playChimeSound();
  };

  // Handle Logout
  const handleLogout = () => {
    setIsAuthenticated(false);
    localStorage.removeItem('sanjeevani_admin_auth');
    adminSiren.stop();
    setIsSirenActive(false);
  };

  // Call Next Patient in Queue
  const handleCallNextPatient = () => {
    playChimeSound();
    const currentIdx = patients.findIndex(p => p.status === 'In Consultation');
    
    if (currentIdx !== -1 && currentIdx < patients.length - 1) {
      const nextPat = patients[currentIdx + 1];
      const nextToken = nextPat.token;
      setCurrentServingToken(nextToken);

      const updated = patients.map((p, idx) => {
        if (idx === currentIdx) {
          return { ...p, status: 'Completed' as const, etaOrArriveTime: 'Consultation Done' };
        }
        if (idx === currentIdx + 1) {
          return { ...p, status: 'In Consultation' as const, etaOrArriveTime: 'Currently with Doctor (Room 204)' };
        }
        if (idx === currentIdx + 2) {
          return { ...p, status: 'In Waiting Lobby' as const, etaOrArriveTime: 'In Waiting Lobby (Please step inside)' };
        }
        return p;
      });

      setPatients(updated);

      // Save to LocalStorage
      try {
        localStorage.setItem('sanjeevani_unified_queue', JSON.stringify(updated));
        localStorage.setItem('sanjeevani_current_serving', nextToken);
      } catch (e) {}

      // Broadcast to Patient Portal window
      const tokenInt = parseInt(nextToken.replace('SANJ-', '')) || 105;
      busRef.current?.postMessage({
        type: 'CALL_NEXT',
        payload: {
          currentServingToken: nextToken,
          tokenNumberInt: tokenInt
        }
      });

      // Also trigger store action
      actions.callNextOPDToken('Cardiology');

      // ⚡ Direct Update to Supabase Realtime Database
      try {
        const curPat = patients[currentIdx];
        if (curPat) updateTokenStatus(curPat.token, 'Completed');
        updateTokenStatus(nextToken, 'In Consultation');
        if (patients[currentIdx + 2]) {
          updateTokenStatus(patients[currentIdx + 2].token, 'In Waiting Lobby');
        }
      } catch (e) {}
    }
  };

  // Direct Instant Consultation Desk Admission (for any patient, including newly booked online patients)
  const handleDirectConsult = (targetPatient: UnifiedPatient) => {
    playChimeSound();
    setCurrentServingToken(targetPatient.token);

    const updated = patients.map((p) => {
      if (p.token === targetPatient.token) {
        return {
          ...p,
          status: 'In Consultation' as const,
          etaOrArriveTime: 'Currently with Doctor (Room 204)'
        };
      }
      if (p.status === 'In Consultation') {
        return {
          ...p,
          status: 'Completed' as const,
          etaOrArriveTime: 'Consultation Done'
        };
      }
      return p;
    });

    setPatients(updated);

    if (latestOnlineBooking && latestOnlineBooking.token === targetPatient.token) {
      setLatestOnlineBooking({
        ...latestOnlineBooking,
        status: 'In Consultation',
        etaOrArriveTime: 'Currently with Doctor (Room 204)'
      });
    }

    try {
      localStorage.setItem('sanjeevani_unified_queue', JSON.stringify(updated));
      localStorage.setItem('sanjeevani_current_serving', targetPatient.token);
    } catch (e) {}

    // Broadcast to Patient Portal window
    const tokenInt = parseInt(targetPatient.token.replace('SANJ-', '')) || 105;
    busRef.current?.postMessage({
      type: 'CALL_NEXT',
      payload: {
        currentServingToken: targetPatient.token,
        tokenNumberInt: tokenInt
      }
    });

    actions.callNextOPDToken('Cardiology');

    try {
      updateTokenStatus(targetPatient.token, 'In Consultation');
    } catch (e) {}
  };

  // Broadcast Delay to Home Patients
  const handleBroadcastDelay = (mins: number) => {
    playChimeSound();
    setDelayMessage(`⚠️ Broadcast Sent: +${mins}m Delay pushed to all home-waiting patients. Their departure times updated!`);
    actions.broadcastDoctorDelay('Cardiology', mins);

    busRef.current?.postMessage({
      type: 'BROADCAST_DELAY',
      payload: { delayMins: mins }
    });

    setTimeout(() => setDelayMessage(''), 6000);
  };

  // Register Offline Walk-In Patient (Hospital Reception / Kiosk)
  const handleRegisterOfflineWalkIn = (e: React.FormEvent) => {
    e.preventDefault();
    if (!walkInName.trim()) return;

    // Calculate next token number sequentially
    const lastNum = patients.reduce((max, p) => {
      const num = parseInt(p.token.replace('SANJ-', '')) || 100;
      return num > max ? num : max;
    }, 107);
    const assignedToken = `SANJ-${lastNum + 1}`;

    const newPatient: UnifiedPatient = {
      token: assignedToken,
      name: walkInName.trim(),
      age: walkInAge || '50',
      gender: walkInGender,
      problem: walkInProblem,
      department: walkInDept,
      phone: walkInPhone || 'Walk-In (No Mobile)',
      source: 'offline_kiosk',
      status: 'In Waiting Lobby',
      etaOrArriveTime: 'Counter Issued (Waiting in Clinic Lobby)'
    };

    const updated = [...patients, newPatient];
    setPatients(updated);
    setNewlyPrintedSlip(newPatient);
    playChimeSound();

    // Persist to LocalStorage and Broadcast
    try {
      localStorage.setItem('sanjeevani_unified_queue', JSON.stringify(updated));
    } catch (err) {}

    // ⚡ Direct Insert to Supabase Database
    try {
      insertOpdToken({
        token_number: assignedToken,
        patient_name: walkInName.trim(),
        age: walkInAge || '50',
        gender: walkInGender,
        phone: walkInPhone || 'Walk-In Counter',
        problem: walkInProblem,
        department: walkInDept,
        hospital: selectedHospital,
        status: 'In Waiting Lobby',
        leave_home_time: 'Arrived at Hospital Counter',
        consultation_time: 'Next in Queue'
      });
    } catch (e) {}

    busRef.current?.postMessage({
      type: 'OFFLINE_WALKIN',
      payload: newPatient
    });

    // Reset form fields
    setWalkInName('');
    setWalkInAge('');
    setWalkInPhone('');
  };

  // Admit Emergency Patient
  const handleAdmitEmergencyPatient = () => {
    setPatientAdmitted(true);
    adminSiren.stop();
    setIsSirenActive(false);
    isSirenActiveRef.current = false;
    setShowEmergencyModal(false);
    playChimeSound();
    actions.admitIncidentPatient('inc-demo-cardiac');
    resolveEmergencySos();

    const admissionPayload = {
      status: 'Patient Received & Admitted',
      hospitalName: emergencyAlertInfo?.hospitalName || selectedHospital,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      bed: 'Trauma Bay #2 (Reserved & Locked)',
      doctor: 'Dr. Sudhir Rao, MD (Cardiology & Trauma In-Charge)',
      timestamp: Date.now()
    };

    try {
      localStorage.removeItem('sanjeevani_active_sos');
      localStorage.setItem('sanjeevani_patient_admitted_alert', JSON.stringify(admissionPayload));
      localStorage.setItem('sanjeevani_admission_ping', String(Date.now()));
    } catch (e) {}

    busRef.current?.postMessage({
      type: 'SOS_RESOLVED',
      payload: admissionPayload
    });
  };

  // 🚨 RENDER RED ALERT MODAL (Usable on both Login Screen and Command Dashboard)
  const renderEmergencyModal = () => {
    if (!showEmergencyModal || !emergencyAlertInfo) return null;

    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 animate-in fade-in">
        {/* Native HTML5 Audio Siren Player */}
        <audio autoPlay loop src="/ambulance_siren.wav" className="hidden" />
        <div className="bg-slate-900 border-4 border-rose-600 rounded-3xl p-6 sm:p-8 max-w-lg w-full shadow-[0_0_60px_rgba(225,29,72,0.85)] text-center space-y-5 relative">
          
          {/* Pulsing Siren & Ambulance Symbol */}
          <div className="relative w-24 h-24 mx-auto flex items-center justify-center">
            <div className="absolute inset-0 rounded-full bg-rose-600/30 animate-ping"></div>
            <div className="w-20 h-20 rounded-2xl bg-gradient-to-tr from-rose-600 via-red-600 to-rose-700 border-2 border-white flex items-center justify-center text-4xl shadow-xl shadow-rose-950 animate-bounce">
              🚨
            </div>
          </div>

          <div>
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-rose-950 border border-rose-500 text-xs font-black text-rose-300 uppercase tracking-widest animate-pulse">
              <span>🚑 108 AMBULANCE DISPATCHED • CODE RED</span>
            </div>
            <h3 className="text-2xl font-black text-white mt-2">
              Emergency Alert Incoming!
            </h3>
            <p className="text-xs text-rose-200 mt-1">
              Patient SOS emergency signal received live. Ambulance en-route to <strong>{emergencyAlertInfo.hospitalName || selectedHospital}</strong>.
            </p>
          </div>

          {/* Sound Unblock Helper Banner (Just in case browser paused audio in background) */}
          <div 
            onClick={() => { adminSiren.warmup(); adminSiren.start(); }}
            className="cursor-pointer px-3 py-2 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 border border-rose-500/50 text-[11px] font-bold text-rose-200 flex items-center justify-center space-x-2 animate-pulse transition"
          >
            <Volume2 className="w-4 h-4 text-amber-300 shrink-0 animate-bounce" />
            <span>🔊 108 Siren Active • (Click anywhere or tap here if audio paused)</span>
          </div>

          {/* Patient Incident Quick Summary */}
          <div className="p-4 rounded-2xl bg-slate-950 border border-rose-700/60 text-left space-y-2.5 text-xs">
            <div className="flex justify-between border-b border-slate-800 pb-2">
              <span className="text-slate-400 font-bold">Caller Phone:</span>
              <span className="font-mono font-black text-white text-sm">{emergencyAlertInfo.phone}</span>
            </div>
            <div className="flex justify-between border-b border-slate-800 pb-2">
              <span className="text-slate-400 font-bold">Reported Problem:</span>
              <span className="font-bold text-rose-300 truncate max-w-[240px]">{emergencyAlertInfo.symptom}</span>
            </div>
            <div className="flex justify-between border-b border-slate-800 pb-2">
              <span className="text-slate-400 font-bold">Patient GPS Area:</span>
              <span className="font-medium text-slate-300 truncate max-w-[240px]">{emergencyAlertInfo.location || 'Metro City Center'}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400 font-bold">Blood Group:</span>
              <span className="font-black text-rose-400">{emergencyAlertInfo.bloodGroup || 'O+'}</span>
            </div>
          </div>

          {/* OK Button - Clicking immediately mutes/stops the siren and enters Trauma desk! */}
          <button
            type="button"
            onClick={handleDismissEmergencySiren}
            className="w-full py-4 bg-gradient-to-r from-rose-600 via-red-600 to-rose-700 hover:from-rose-500 hover:to-red-500 text-white font-black rounded-2xl text-base sm:text-lg transition flex items-center justify-center space-x-3 shadow-2xl shadow-rose-950 border-2 border-white transform active:scale-95 animate-pulse"
          >
            <VolumeX className="w-6 h-6 text-amber-300" />
            <span>🚨 OK (ACKNOWLEDGE & STOP SIREN)</span>
          </button>
          
          <p className="text-[11px] text-slate-400">
            Clicking OK will silence the siren and open the live Patient GPS Map & Trauma Desk.
          </p>
        </div>
      </div>
    );
  };

  // =========================================================================
  // VIEW 1: GLASSMORPHIC LOGIN GATE (If not authenticated)
  // =========================================================================
  if (!isAuthenticated) {
    return (
      <div className="min-h-[80vh] flex items-center justify-center px-4 py-12 relative">
        {/* Render Red Alert Modal even on login screen so emergency is NEVER missed! */}
        {renderEmergencyModal()}
        <div className="w-full max-w-md relative">
          {/* Subtle Ambient Glow */}
          <div className="absolute -top-10 -left-10 w-72 h-72 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none"></div>
          <div className="absolute -bottom-10 -right-10 w-72 h-72 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none"></div>

          {/* Glass Card Container */}
          <div className="relative rounded-3xl bg-slate-900/70 backdrop-blur-2xl border border-slate-700/60 p-8 shadow-[0_8px_32px_0_rgba(0,0,0,0.45)] space-y-6">
            
            {/* Header / Brand */}
            <div className="text-center space-y-2">
              <div className="w-14 h-14 mx-auto rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-500 flex items-center justify-center shadow-lg shadow-emerald-950/50 ring-1 ring-white/20">
                <Building2 className="w-7 h-7 text-white" />
              </div>
              <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-indigo-950/70 border border-indigo-700/50 text-[11px] font-bold text-indigo-300">
                <Lock className="w-3 h-3 text-indigo-400" />
                <span>RESTRICTED HOSPITAL STAFF PORTAL</span>
              </div>
              <h2 className="text-2xl font-black text-white tracking-tight">Sanjeevani AI Admin</h2>
              <p className="text-xs text-slate-400">
                Hospital Command Center, OPD Queue & Trauma ER Operations
              </p>
            </div>

            {/* Error notice */}
            {authError && (
              <div className="p-3 rounded-xl bg-rose-950/60 border border-rose-600 text-rose-300 text-xs font-semibold text-center">
                {authError}
              </div>
            )}

            {/* Login Form */}
            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  Select Hospital Branch
                </label>
                <select
                  value={selectedHospital}
                  onChange={(e) => setSelectedHospital(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-slate-950/80 border border-slate-700 text-white text-xs font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="Apollo Trauma & Heart Institute">Apollo Trauma & Heart Institute (Zone 1)</option>
                  <option value="City Care Stroke & Neuro">City Care Comprehensive Stroke & Neuro (Sector 4)</option>
                  <option value="Fortis Pediatric & ER">Fortis Pediatric & Emergency Center (Hub 9)</option>
                  <option value="Metro General Regional Hospital">Metro General Regional Hospital (Block C)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  Staff Email / Doctor ID
                </label>
                <input
                  type="email"
                  value={adminEmail}
                  onChange={(e) => setAdminEmail(e.target.value)}
                  placeholder="doctor@hospital.health"
                  className="w-full px-4 py-2.5 rounded-xl bg-slate-950/80 border border-slate-700 text-white text-xs font-medium placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  Password
                </label>
                <input
                  type="password"
                  value={adminPassword}
                  onChange={(e) => setAdminPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full px-4 py-2.5 rounded-xl bg-slate-950/80 border border-slate-700 text-white text-xs font-medium placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  required
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl text-xs sm:text-sm transition flex items-center justify-center space-x-2 shadow-lg shadow-indigo-950"
              >
                <span>Authorize & Enter Command Center</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>

            {/* 1-Click Hackathon Demo Shortcut */}
            <div className="pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={handleQuickDemoLogin}
                className="w-full py-3 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold rounded-xl text-xs sm:text-sm transition flex items-center justify-center space-x-2 shadow-lg shadow-emerald-950/50"
              >
                <Sparkles className="w-4 h-4 text-amber-300 animate-pulse" />
                <span>⚡ 1-Click Instant Demo Login (Dr. Sudhir Rao)</span>
              </button>
              <p className="text-[10px] text-slate-400 text-center mt-2">
                Simulates pre-authenticated Cardiology HOD & Trauma In-Charge
              </p>
            </div>

            {/* Compliance Badge */}
            <div className="text-center pt-2 text-[10px] text-slate-500">
              🔒 NABH & HIPAA Compliant Clinical Command Infrastructure
            </div>
          </div>
        </div>
      </div>
    );
  }

  // =========================================================================
  // VIEW 2: LOGGED IN ADMIN COMMAND DASHBOARD
  // =========================================================================
  const activeAmbulance = ambulances[0];

  return (
    <div className="space-y-6 pb-12">
      {/* 🚨 RED ALERT POPUP MODAL WITH AMBULANCE SIREN SYMBOL (Auto-opens on SOS dispatch) */}
      {renderEmergencyModal()}

      {/* 🚨 HIGH-PRIORITY AMBULANCE SIREN ALERT BANNER (Active when SOS dispatched) */}
      {isSirenActive && (
        <div className="p-4 sm:p-5 rounded-3xl bg-gradient-to-r from-rose-600 via-red-600 to-rose-700 border-2 border-white shadow-[0_0_35px_rgba(225,29,72,0.85)] text-white flex flex-col sm:flex-row items-center justify-between gap-4 animate-pulse">
          <div className="flex items-center space-x-3.5">
            <div className="w-12 h-12 rounded-2xl bg-white text-rose-600 flex items-center justify-center font-black text-2xl shadow-lg shrink-0">
              🚨
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-[10px] font-black uppercase tracking-widest bg-white/20 px-2.5 py-0.5 rounded-full">
                  108 AMBULANCE DISPATCHED • CODE RED
                </span>
                <span className="text-xs font-bold text-rose-100">
                  {emergencyAlertInfo?.time || 'Just now'}
                </span>
              </div>
              <h3 className="text-base sm:text-lg font-black mt-0.5">
                Incoming Emergency: {emergencyAlertInfo?.symptom || 'Acute STEMI / Severe Distress'}
              </h3>
              <p className="text-xs text-rose-100">
                Patient Contact: <strong>{emergencyAlertInfo?.phone || '+91 98450-23491'}</strong> • Trauma Resus Bay #2 Locked (Hold: {formatTimer(bedTimerSeconds)})
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <button
              onClick={handleDismissEmergencySiren}
              className="px-5 py-3 bg-white hover:bg-rose-50 text-rose-700 rounded-2xl text-xs font-black transition flex items-center space-x-2 shadow-2xl border-2 border-white transform active:scale-95"
            >
              <VolumeX className="w-5 h-5 text-rose-600" />
              <span>🚨 OK (STOP SIREN)</span>
            </button>
          </div>
        </div>
      )}

      {/* 🏥 GLASSMORPHIC HEADER & DOCTOR PROFILE BAR */}
      <div className="p-6 rounded-3xl bg-slate-900/70 backdrop-blur-2xl border border-slate-700/60 shadow-[0_8px_32px_0_rgba(0,0,0,0.4)] flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center space-x-4">
          <div className="w-14 h-14 rounded-2xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/40 flex items-center justify-center shadow-inner">
            <Building2 className="w-7 h-7" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h1 className="text-xl font-black text-white">{selectedHospital}</h1>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-950 text-emerald-300 border border-emerald-700/50">
                ACTIVE DESK
              </span>
            </div>
            <p className="text-xs text-slate-300 flex items-center space-x-1.5 mt-0.5">
              <Stethoscope className="w-3.5 h-3.5 text-indigo-400" />
              <span>Attending Doctor: <strong className="text-white">Dr. Sudhir Rao, MD (Cardiology & Trauma In-Charge)</strong></span>
            </p>
          </div>
        </div>

        {/* Live Status Indicators */}
        <div className="flex flex-wrap items-center gap-2.5">
          <div className="px-3 py-1.5 rounded-xl bg-slate-950/80 border border-slate-800 text-center">
            <span className="text-[9px] text-slate-400 font-bold uppercase block">ER Beds</span>
            <span className="text-sm font-black text-white">4 / 16 Free</span>
          </div>
          <div className="px-3 py-1.5 rounded-xl bg-slate-950/80 border border-slate-800 text-center">
            <span className="text-[9px] text-slate-400 font-bold uppercase block">ICU Beds</span>
            <span className="text-sm font-black text-emerald-400">2 / 8 Free</span>
          </div>
          <div className="px-3 py-1.5 rounded-xl bg-slate-950/80 border border-slate-800 text-center">
            <span className="text-[9px] text-slate-400 font-bold uppercase block">OPD Active</span>
            <span className="text-sm font-black text-indigo-300">{patients.filter(p => p.status !== 'Completed').length} Patients</span>
          </div>

          <button
            onClick={handleLogout}
            className="p-2 rounded-xl bg-slate-950/80 border border-slate-800 text-slate-400 hover:text-rose-400 hover:border-rose-800 transition"
            title="Logout"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* 🧭 NAVIGATION TABS */}
      <div className="flex flex-wrap gap-2 p-1.5 rounded-2xl bg-slate-900/60 backdrop-blur-xl border border-slate-800">
        <button
          onClick={() => setActiveTab('queue')}
          className={`flex items-center space-x-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'queue'
              ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-950'
              : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>OPD Queue & Walk-In Desk</span>
          <span className="px-1.5 py-0.5 rounded-full text-[10px] bg-indigo-950 text-indigo-200 border border-indigo-700">
            {patients.filter(p => p.status !== 'Completed').length}
          </span>
        </button>

        <button
          onClick={() => setActiveTab('calendar')}
          className={`flex items-center space-x-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'calendar'
              ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-950'
              : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
          }`}
        >
          <Calendar className="w-4 h-4" />
          <span>Doctor Daily Schedule & Slots</span>
        </button>

        <button
          onClick={() => setActiveTab('trauma')}
          className={`flex items-center space-x-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'trauma'
              ? 'bg-rose-600 text-white shadow-lg shadow-rose-950'
              : 'text-rose-400 hover:text-white hover:bg-rose-950/30'
          }`}
        >
          <ShieldAlert className={`w-4 h-4 ${isSirenActive ? 'animate-bounce' : ''}`} />
          <span>Trauma ER Ward (Code Red)</span>
          <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping"></span>
        </button>

        <button
          onClick={() => setActiveTab('map')}
          className={`flex items-center space-x-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'map'
              ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-950'
              : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
          }`}
        >
          <MapPin className="w-4 h-4 text-emerald-400" />
          <span>🗺️ City Network Live Map</span>
        </button>

        <button
          onClick={() => setActiveTab('telemetry')}
          className={`flex items-center space-x-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'telemetry'
              ? 'bg-amber-600 text-white shadow-lg shadow-amber-950'
              : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
          }`}
        >
          <Radio className="w-4 h-4" />
          <span>Ambulance Telemetry</span>
          <span className="px-1.5 py-0.5 rounded-full text-[10px] bg-amber-950 text-amber-200 border border-amber-700">
            Medic-01 Live
          </span>
        </button>

        <button
          onClick={() => setActiveTab('supply')}
          className={`flex items-center space-x-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'supply'
              ? 'bg-cyan-600 text-white shadow-lg shadow-cyan-950'
              : 'text-cyan-300 hover:text-white hover:bg-cyan-950/30'
          }`}
        >
          <Package className="w-4 h-4" />
          <span>SupplyShield</span>
          <span className="px-1.5 py-0.5 rounded-full text-[10px] bg-cyan-950 text-cyan-200 border border-cyan-700">
            AI
          </span>
        </button>
      </div>

      {/* ===================================================================== */}
      {/* TAB 1: OPD QUEUE CONTROLLER & OFFLINE WALK-IN COUNTER                   */}
      {/* ===================================================================== */}
      {/* ===================================================================== */}
      {/* TAB 1: OPD QUEUE CONTROLLER & ACTIVE CONSULTATION DESK                 */}
      {/* ===================================================================== */}
      {activeTab === 'queue' && (
        <div className="space-y-6">
          {/* Top Quick Actions Bar */}
          <div className="p-6 rounded-3xl bg-slate-900/70 backdrop-blur-2xl border border-slate-700/60 shadow-xl space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
              <div>
                <span className="text-[10px] font-black uppercase tracking-wider text-indigo-400 block">
                  ACTIVE CONSULTATION DESK (ROOM 204)
                </span>
                <div className="flex items-center space-x-3 mt-1">
                  <h2 className="text-xl font-black text-white">
                    Currently Serving Token: <span className="font-mono text-emerald-400">{currentServingToken}</span>
                  </h2>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center gap-2">
                <button
                  onClick={() => setIsWalkInModalOpen(true)}
                  className="px-4 py-2.5 bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 text-white rounded-xl text-xs font-bold transition flex items-center space-x-2 shadow-md shadow-emerald-950"
                >
                  <UserPlus className="w-4 h-4" />
                  <span>➕ Register Walk-In (Kiosk Slip)</span>
                </button>

                <button
                  onClick={() => handleBroadcastDelay(15)}
                  className="px-3.5 py-2.5 bg-amber-600/20 hover:bg-amber-600/30 text-amber-300 border border-amber-500/40 rounded-xl text-xs font-bold transition flex items-center space-x-1.5"
                >
                  <Clock className="w-3.5 h-3.5" />
                  <span>Broadcast +15m Delay</span>
                </button>

                <button
                  onClick={handleCallNextPatient}
                  className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold transition flex items-center space-x-1.5 shadow-md shadow-indigo-950"
                >
                  <Volume2 className="w-4 h-4" />
                  <span>Call Next Patient</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Delay notice banner */}
            {delayMessage && (
              <div className="p-3.5 rounded-2xl bg-amber-950/70 border border-amber-600 text-amber-200 text-xs font-semibold animate-fade-in flex items-center justify-between">
                <span>{delayMessage}</span>
                <span className="text-[10px] text-amber-400 font-mono">PUSHED TO CLIENTS VIA BROADCAST BUS</span>
              </div>
            )}

            {/* 🩺 ACTIVE PATIENT CLINICAL DOSSIER (ROOM 204 LIVE CONSULTATION) */}
            {(() => {
              const currentConsultingPatient = patients.find(p => p.token === currentServingToken || p.status === 'In Consultation') || patients[0];
              if (!currentConsultingPatient) return null;

              return (
                <div className="p-5 rounded-2xl bg-gradient-to-br from-indigo-950/40 via-slate-950 to-slate-900/80 border-2 border-indigo-500/60 shadow-lg shadow-indigo-950/40 space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
                    <div className="flex items-center space-x-3">
                      <div className="w-11 h-11 rounded-xl bg-indigo-600 text-white flex items-center justify-center font-mono font-black text-lg shadow-md shadow-indigo-950 shrink-0">
                        {currentConsultingPatient.token}
                      </div>
                      <div>
                        <div className="flex items-center space-x-2">
                          <span className="text-base font-black text-white">{currentConsultingPatient.name}</span>
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-emerald-600 text-white flex items-center space-x-1 animate-pulse">
                            <span className="w-1.5 h-1.5 rounded-full bg-white animate-ping"></span>
                            <span>IN CONSULTATION (ROOM 204)</span>
                          </span>
                        </div>
                        <div className="text-xs text-slate-400 mt-0.5">
                          {currentConsultingPatient.age} yrs • {currentConsultingPatient.gender} • <a href={`tel:${currentConsultingPatient.phone}`} className="hover:text-emerald-400 text-slate-300 font-medium">{currentConsultingPatient.phone}</a>
                          {currentConsultingPatient.email && <span> • {currentConsultingPatient.email}</span>}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center space-x-2">
                      <span className="text-[11px] font-bold text-slate-400">Source:</span>
                      {currentConsultingPatient.source === 'online' ? (
                        <span className="px-2.5 py-1 rounded-lg text-[10px] font-black bg-blue-950 text-blue-300 border border-blue-700/60">
                          📱 Online Mobile App
                        </span>
                      ) : (
                        <span className="px-2.5 py-1 rounded-lg text-[10px] font-black bg-teal-950 text-teal-300 border border-teal-700/60">
                          🎫 Kiosk Counter Walk-In
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
                    {/* Chief Complaint / Symptoms */}
                    <div className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800 space-y-1">
                      <span className="text-[10px] font-black uppercase text-slate-400 block tracking-wider">
                        CHIEF MEDICAL COMPLAINT / SYMPTOMS
                      </span>
                      <p className="font-bold text-indigo-200 text-sm">
                        {currentConsultingPatient.problem}
                      </p>
                    </div>

                    {/* Department & Hospital Branch */}
                    <div className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800 space-y-1">
                      <span className="text-[10px] font-black uppercase text-slate-400 block tracking-wider">
                        CLINICAL DEPARTMENT & HOSPITAL
                      </span>
                      <p className="font-bold text-white">
                        {currentConsultingPatient.department}
                      </p>
                      <p className="text-[11px] text-slate-400">
                        {currentConsultingPatient.hospital || selectedHospital}
                      </p>
                    </div>

                    {/* Timings & Pacing Schedule */}
                    <div className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800 space-y-1">
                      <span className="text-[10px] font-black uppercase text-slate-400 block tracking-wider">
                        CONSULTATION TIMINGS & STATUS
                      </span>
                      <p className="font-bold text-emerald-400">
                        Slot: {currentConsultingPatient.consultationTime || '09:45 AM - 10:00 AM'}
                      </p>
                      <p className="text-[11px] text-slate-400">
                        {currentConsultingPatient.etaOrArriveTime}
                      </p>
                    </div>
                  </div>

                  {/* Doctor Desk Action Bar */}
                  <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-800/80">
                    <div className="text-[11px] text-slate-400 flex items-center space-x-1.5">
                      <Stethoscope className="w-3.5 h-3.5 text-indigo-400" />
                      <span>Doctor notes synced real-time to Electronic Health Record (EHR)</span>
                    </div>

                    <div className="flex flex-wrap items-center gap-2">
                      <button
                        onClick={() => handleCallNextPatient()}
                        className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition flex items-center space-x-1.5 shadow-md shadow-emerald-950"
                      >
                        <CheckCircle2 className="w-4 h-4" />
                        <span>Finish Consultation & Call Next</span>
                      </button>
                      <button
                        onClick={() => alert(`Prescription printed for ${currentConsultingPatient.name} (Token ${currentConsultingPatient.token})`)}
                        className="px-3.5 py-2 bg-slate-950 hover:bg-slate-900 text-slate-300 hover:text-white border border-slate-800 rounded-xl text-xs font-bold transition flex items-center space-x-1.5"
                      >
                        <Printer className="w-3.5 h-3.5" />
                        <span>Print Rx Slip</span>
                      </button>
                    </div>
                  </div>
                </div>
              );
            })()}

            {/* ⚡ LIVE INCOMING ONLINE OPD BOOKING ALERT BANNER */}
            {latestOnlineBooking && (
              <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-emerald-950/80 via-teal-950/60 to-slate-950 border-2 border-emerald-500/70 shadow-[0_0_25px_rgba(16,185,129,0.25)] space-y-3 animate-fade-in">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-emerald-900/50 pb-2.5">
                  <div className="flex items-center space-x-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping"></span>
                    <span className="text-[10px] font-black uppercase tracking-wider text-emerald-400">
                      ⚡ LIVE ONLINE BOOKING RECEIVED • IMMEDIATE SYNC
                    </span>
                  </div>
                  <span className="text-[11px] font-mono text-emerald-300">
                    Booked at: <strong>{latestOnlineBooking.bookingTime || 'Just now'}</strong>
                  </span>
                </div>

                <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 text-xs flex-1">
                    <div>
                      <span className="text-[10px] text-slate-400 block font-bold uppercase">Patient & Token</span>
                      <div className="text-white font-black text-sm">
                        {latestOnlineBooking.name} <span className="text-emerald-400 font-mono">({latestOnlineBooking.token})</span>
                      </div>
                      <div className="text-[11px] text-slate-400">
                        {latestOnlineBooking.age} yrs • {latestOnlineBooking.gender}
                      </div>
                    </div>

                    <div>
                      <span className="text-[10px] text-slate-400 block font-bold uppercase">Contact & Email</span>
                      <div className="text-white font-mono font-bold">
                        {latestOnlineBooking.phone}
                      </div>
                      <div className="text-[11px] text-slate-400 truncate max-w-[150px]">
                        {latestOnlineBooking.email || 'N/A'}
                      </div>
                    </div>

                    <div>
                      <span className="text-[10px] text-slate-400 block font-bold uppercase">Chief Symptoms</span>
                      <div className="text-emerald-200 font-bold line-clamp-2">
                        {latestOnlineBooking.problem}
                      </div>
                    </div>

                    <div>
                      <span className="text-[10px] text-slate-400 block font-bold uppercase">Pacing & Timing</span>
                      <div className="text-white font-bold">
                        Turn: {latestOnlineBooking.consultationTime || '10:15 AM'}
                      </div>
                      <div className="text-[11px] text-slate-400">
                        Leave Home: {latestOnlineBooking.leaveHomeTime || '10:00 AM'}
                      </div>
                    </div>
                  </div>

                  <div className="shrink-0 flex items-center space-x-2">
                    {latestOnlineBooking.status === 'In Consultation' ? (
                      <span className="px-3.5 py-2 rounded-xl bg-emerald-600 text-white font-bold text-xs flex items-center space-x-1.5 animate-pulse">
                        <CheckCircle2 className="w-4 h-4" />
                        <span>Currently in Room 204</span>
                      </span>
                    ) : (
                      <button
                        onClick={() => handleDirectConsult(latestOnlineBooking)}
                        className="px-4 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold rounded-xl text-xs flex items-center space-x-2 shadow-lg shadow-emerald-950 transition transform active:scale-95"
                      >
                        <Sparkles className="w-4 h-4 text-amber-300 animate-pulse" />
                        <span>👨‍⚕️ Admit to Consultation Desk Now ➔</span>
                      </button>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* UNIFIED PATIENT QUEUE TABLE */}
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-400">
                    <th className="pb-2.5 font-bold">TOKEN</th>
                    <th className="pb-2.5 font-bold">PATIENT & CONTACT</th>
                    <th className="pb-2.5 font-bold">DEPT & HOSPITAL</th>
                    <th className="pb-2.5 font-bold">CHIEF SYMPTOMS</th>
                    <th className="pb-2.5 font-bold">SOURCE</th>
                    <th className="pb-2.5 font-bold">STATUS & PACING</th>
                    <th className="pb-2.5 font-bold text-right">ACTIONS</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {patients.map((p) => {
                    const isServing = p.status === 'In Consultation';
                    const isLobby = p.status === 'In Waiting Lobby';
                    const isHome = p.status === 'Safe at Home (Pacing)';
                    const isDone = p.status === 'Completed';

                    return (
                      <tr 
                        key={p.token} 
                        className={`transition ${
                          isServing 
                            ? 'bg-indigo-950/40 font-semibold text-white' 
                            : isDone
                            ? 'opacity-40'
                            : 'hover:bg-slate-800/30 text-slate-300'
                        }`}
                      >
                        <td className="py-3.5 font-mono font-bold text-sm">
                          <span className={isServing ? 'text-emerald-400 font-black' : 'text-indigo-400'}>
                            {p.token}
                          </span>
                          {p.consultationTime && (
                            <div className="text-[10px] font-sans text-slate-500 font-normal mt-0.5">
                              {p.consultationTime}
                            </div>
                          )}
                        </td>
                        <td className="py-3.5">
                          <div className="font-bold text-white text-xs sm:text-sm">{p.name}</div>
                          <div className="text-[10px] text-slate-400">
                            {p.age}y • {p.gender} • <a href={`tel:${p.phone}`} className="hover:text-emerald-400 text-slate-300">{p.phone}</a>
                          </div>
                          {p.email && (
                            <div className="text-[10px] text-slate-500 truncate max-w-[150px]">{p.email}</div>
                          )}
                        </td>
                        <td className="py-3.5">
                          <div className="font-bold text-slate-200">{p.department}</div>
                          <div className="text-[10px] text-slate-500 truncate max-w-[170px]">{p.hospital || selectedHospital}</div>
                        </td>
                        <td className="py-3.5 max-w-xs text-slate-300 font-medium">
                          <span className="line-clamp-2">{p.problem}</span>
                        </td>
                        <td className="py-3.5">
                          {p.source === 'online' ? (
                            <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-blue-950 text-blue-300 border border-blue-800/60">
                              📱 Online App
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-teal-950 text-teal-300 border border-teal-800/60">
                              🎫 Kiosk Walk-in
                            </span>
                          )}
                        </td>
                        <td className="py-3.5">
                          <div>
                            <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold inline-flex items-center space-x-1 ${
                              isServing
                                ? 'bg-emerald-600 text-white animate-pulse'
                                : isLobby
                                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                                : isHome
                                ? 'bg-slate-800 text-slate-300 border border-slate-700'
                                : 'bg-slate-900 text-slate-500 line-through'
                            }`}>
                              <span>{p.status}</span>
                            </span>
                            <div className="text-[10px] text-slate-400 mt-1">
                              {p.etaOrArriveTime}
                            </div>
                          </div>
                        </td>
                        <td className="py-3.5 text-right">
                          {isServing ? (
                            <span className="px-2.5 py-1 rounded-lg text-[10px] font-black bg-emerald-600/30 text-emerald-300 border border-emerald-500/50">
                              Consulting 🩺
                            </span>
                          ) : isDone ? (
                            <span className="text-[11px] text-slate-500 font-bold">Done ✅</span>
                          ) : (
                            <button
                              onClick={() => handleDirectConsult(p)}
                              className="px-3 py-1.5 bg-indigo-600/30 hover:bg-indigo-600 text-indigo-200 hover:text-white border border-indigo-500/50 rounded-lg text-[10px] font-black transition inline-flex items-center space-x-1 shadow-sm"
                            >
                              <span>Consult Now</span>
                              <ArrowRight className="w-3 h-3" />
                            </button>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* TAB 2: DOCTOR DAILY SCHEDULE & CALENDAR                               */}
      {/* ===================================================================== */}
      {activeTab === 'calendar' && (
        <div className="space-y-6">
          <div className="p-6 rounded-3xl bg-slate-900/70 backdrop-blur-2xl border border-slate-700/60 shadow-xl space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
              <div>
                <div className="flex items-center space-x-2">
                  <Calendar className="w-5 h-5 text-indigo-400" />
                  <h2 className="text-xl font-black text-white">Daily Clinical Schedule & Timeline</h2>
                </div>
                <p className="text-xs text-slate-400 mt-1">
                  Physician: Dr. Sudhir Rao, MD • Shift: 09:00 AM – 05:00 PM (Room 204 OPD + Trauma On-Call)
                </p>
              </div>

              <div className="flex items-center space-x-2">
                <button
                  onClick={() => alert('Calendar synced with Hospital HIS / Google Calendar!')}
                  className="px-3.5 py-2 bg-slate-950 border border-slate-700 text-slate-300 hover:text-white rounded-xl text-xs font-bold transition flex items-center space-x-1.5"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Sync HIS Calendar</span>
                </button>

                <div className="px-3 py-2 bg-emerald-950 border border-emerald-700/60 text-emerald-300 rounded-xl text-xs font-bold">
                  🟢 ACTIVE ON-DUTY
                </div>
              </div>
            </div>

            {/* Time Slot Timeline Grid (Dynamically maps the actual synchronized patients!) */}
            <div className="space-y-3">
              <div className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                Morning OPD Consultation Slots (15-Minute Dynamic Pacing)
              </div>

              {patients.map((p, idx) => {
                const startMins = 9 * 60 + idx * 15;
                const endMins = startMins + 15;
                const formatSlotTime = (totalMins: number) => {
                  const h = Math.floor(totalMins / 60);
                  const m = totalMins % 60;
                  const ampm = h >= 12 ? 'PM' : 'AM';
                  const displayH = h > 12 ? h - 12 : h;
                  return `${displayH < 10 ? '0' : ''}${displayH}:${m < 10 ? '0' : ''}${m} ${ampm}`;
                };

                const slotTimeStr = `${formatSlotTime(startMins)} - ${formatSlotTime(endMins)}`;
                const isServing = p.status === 'In Consultation';
                const isDone = p.status === 'Completed';
                const isLobby = p.status === 'In Waiting Lobby';

                return (
                  <div 
                    key={p.token}
                    className={`p-4 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs transition ${
                      isServing
                        ? 'bg-indigo-950/50 border-2 border-indigo-500 shadow-lg shadow-indigo-950/50'
                        : isDone
                        ? 'bg-slate-950/50 border border-slate-800 opacity-60'
                        : 'bg-slate-950/80 border border-slate-800'
                    }`}
                  >
                    <div className="flex items-center space-x-3">
                      <span className="font-mono text-slate-400 font-bold w-32">{slotTimeStr}</span>
                      <span className="font-mono text-indigo-400 font-bold">{p.token}</span>
                      <span className="text-white font-bold">{p.name}</span>
                      <span className="text-slate-400 hidden md:inline truncate max-w-xs">({p.problem})</span>
                    </div>

                    <div>
                      {isServing ? (
                        <span className="px-3 py-1 rounded-full text-[10px] font-black bg-indigo-600 text-white animate-pulse">
                          IN CONSULTATION NOW 🩺
                        </span>
                      ) : isDone ? (
                        <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-slate-800 text-slate-400 border border-slate-700">
                          COMPLETED ✅
                        </span>
                      ) : isLobby ? (
                        <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40">
                          IN WAITING LOBBY
                        </span>
                      ) : (
                        <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-slate-800 text-slate-300 border border-slate-700">
                          WAITING AT HOME (Pacing)
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}

              {/* CRITICAL EMERGENCY BUFFER (LOCKED) */}
              <div className="p-4 rounded-2xl bg-rose-950/40 border-2 border-rose-600/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs shadow-lg shadow-rose-950">
                <div className="flex items-center space-x-3">
                  <span className="font-mono text-rose-400 font-bold w-32">10:00 AM - 10:30 AM</span>
                  <BadgeAlert className="w-5 h-5 text-rose-400 animate-bounce" />
                  <div>
                    <span className="text-rose-200 font-bold text-sm block">
                      ⚡ EMERGENCY RESERVE BUFFER (Locked for Code Red / Trauma)
                    </span>
                    <span className="text-[11px] text-rose-300">
                      Reserved for Code Red Trauma / Cath Lab immediate coronary intervention
                    </span>
                  </div>
                </div>
                <span className="px-3 py-1 rounded-full text-[10px] font-black bg-rose-600 text-white uppercase tracking-wider">
                  BAY #2 LOCKED (Hold: {formatTimer(bedTimerSeconds)})
                </span>
              </div>

              {/* Next OPD Slot */}
              <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                <div className="flex items-center space-x-3">
                  <span className="font-mono text-slate-400 font-bold w-32">10:30 AM - 11:00 AM</span>
                  <span className="font-mono text-slate-500 font-bold">SLOT-OPEN</span>
                  <span className="text-slate-300 font-bold">Post-Cath Review & Subsequent Consultations</span>
                </div>
                <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-slate-900 text-slate-400 border border-slate-800">
                  RESERVED QUEUE
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* TAB 3: TRAUMA ER CODE RED WARD & BED HOLD                             */}
      {/* ===================================================================== */}
      {activeTab === 'trauma' && (
        <div className="space-y-6">
          <div className="p-6 rounded-3xl bg-slate-900/80 backdrop-blur-2xl border-2 border-rose-600/80 shadow-[0_8px_32px_0_rgba(225,29,72,0.3)] space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
              <div className="flex items-center space-x-3">
                <div className="p-3 bg-rose-600 text-white rounded-2xl animate-bounce shadow-lg shadow-rose-950">
                  <ShieldAlert className="w-7 h-7" />
                </div>
                <div>
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-rose-600 text-white">
                    LEVEL 1 TRAUMA • CODE RED INCOMING
                  </span>
                  <h2 className="text-xl font-black text-white mt-1">
                    Incoming Critical: {emergencyAlertInfo?.symptom || '52/M, Acute STEMI (Heart Attack)'}
                  </h2>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    if (isSirenActive) {
                      adminSiren.stop();
                      setIsSirenActive(false);
                      isSirenActiveRef.current = false;
                    } else {
                      adminSiren.warmup();
                      adminSiren.start();
                      setIsSirenActive(true);
                      isSirenActiveRef.current = true;
                    }
                  }}
                  className={`px-4 py-2.5 rounded-2xl text-xs font-black transition flex items-center space-x-2 shadow-lg ${
                    isSirenActive
                      ? 'bg-rose-600 hover:bg-rose-500 text-white animate-pulse ring-2 ring-white'
                      : 'bg-emerald-700 hover:bg-emerald-600 text-white border border-emerald-500'
                  }`}
                >
                  {isSirenActive ? (
                    <>
                      <VolumeX className="w-4 h-4 text-amber-300" />
                      <span>🔕 MUTE EMERGENCY SIREN</span>
                    </>
                  ) : (
                    <>
                      <Volume2 className="w-4 h-4 text-emerald-300" />
                      <span>🔊 TEST / UNMUTE SIREN</span>
                    </>
                  )}
                </button>

                <div className="text-right bg-slate-950 px-5 py-3 rounded-2xl border border-rose-700/60 shadow-inner">
                  <span className="text-[10px] text-rose-400 uppercase font-bold block">30-Min Bed Reservation Hold</span>
                  <div className="text-2xl font-mono font-black text-white">
                    {patientAdmitted ? 'ADMITTED ✅' : `Hold: ${formatTimer(bedTimerSeconds)}`}
                  </div>
                </div>
              </div>
            </div>

            {/* 🚨 COMPREHENSIVE EMERGENCY PATIENT DOSSIER & CALLER RECORD */}
            <div className="p-5 rounded-2xl bg-slate-950 border border-rose-600/50 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
                <div className="flex items-center space-x-2.5">
                  <span className="w-3 h-3 rounded-full bg-rose-500 animate-ping"></span>
                  <h3 className="text-sm font-black text-rose-400 uppercase tracking-wider">
                    LIVE PATIENT INCIDENT DOSSIER & DISPATCH RECORD
                  </h3>
                </div>
                <span className="px-2.5 py-1 rounded-full text-[10px] font-mono font-black bg-rose-950 text-rose-300 border border-rose-800 self-start sm:self-auto">
                  CALL LOGGED: {emergencyAlertInfo?.time || 'Just Now'}
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 text-xs">
                {/* Contact Number */}
                <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800">
                  <span className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                    Caller / Patient Phone
                  </span>
                  <div className="text-base font-mono font-black text-white">
                    {emergencyAlertInfo?.phone || '+91 98450-23491'}
                  </div>
                  <a 
                    href={`tel:${emergencyAlertInfo?.phone || '9845023491'}`} 
                    className="mt-2 inline-flex items-center space-x-1 text-[10px] font-bold text-emerald-400 hover:text-emerald-300"
                  >
                    <Phone className="w-3 h-3" />
                    <span>Direct Dial Caller 📞</span>
                  </a>
                </div>

                {/* Blood Group */}
                <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800">
                  <span className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                    Patient Blood Group
                  </span>
                  <div className="text-xl font-black text-rose-400">
                    {emergencyAlertInfo?.bloodGroup || 'O+ (Positive)'}
                  </div>
                  <span className="text-[10px] text-emerald-400 block mt-1 font-medium">
                    Blood Bank Pre-Held (2 Units PRBC)
                  </span>
                </div>

                {/* Chief Medical Complaint */}
                <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 sm:col-span-2">
                  <span className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                    Reported Symptoms / Chief Complaint
                  </span>
                  <div className="text-sm font-bold text-amber-200">
                    {emergencyAlertInfo?.symptom || 'Acute Chest Heaviness radiating to left arm & severe breathlessness'}
                  </div>
                  <span className="text-[10px] text-slate-400 block mt-1">
                    Triage Classification: Level 1 Critical (Immediate Cath Lab Mobilization)
                  </span>
                </div>
              </div>

              {/* GPS Location & Live Navigation Strip */}
              <div className="p-3.5 rounded-xl bg-indigo-950/40 border border-indigo-700/50 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
                <div className="flex items-center space-x-2 text-indigo-300">
                  <MapPin className="w-4 h-4 text-rose-400 shrink-0 animate-bounce" />
                  <div>
                    <span className="font-bold text-white block">
                      Incident Location: {emergencyAlertInfo?.location || 'Metro City Center Area'}
                    </span>
                    <span className="text-[10px] text-slate-400">
                      Destination Hospital: {emergencyAlertInfo?.hospitalName || selectedHospital}
                    </span>
                  </div>
                </div>
                <span className="px-3 py-1 rounded-lg bg-indigo-600 text-white font-bold text-[10px] self-start sm:self-auto shrink-0 shadow-md">
                  Live Route Active • ETA 5-6 mins
                </span>
              </div>
            </div>

            {/* Incident Hospital Capacity Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
              <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800">
                <span className="text-slate-400 block font-semibold mb-1">Locked Resus Bay:</span>
                <strong className="text-rose-300 text-base font-black">Trauma Resus Bay #2</strong>
                <span className="text-[10px] text-emerald-400 block mt-1">Sterile & Defibrillator Online</span>
              </div>

              <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800">
                <span className="text-slate-400 block font-semibold mb-1">Dispatched Ambulance:</span>
                <strong className="text-white text-base font-black">{activeAmbulance?.callSign || 'Medic-01 (ALS)'}</strong>
                <span className="text-[10px] text-amber-300 block mt-1">ETA: {activeAmbulance?.etaMinutes || 6} mins (Golden Hour)</span>
              </div>

              <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800">
                <span className="text-slate-400 block font-semibold mb-1">Required Capabilities:</span>
                <strong className="text-emerald-400 text-base font-black">Cath Lab & Cardiac ICU</strong>
                <span className="text-[10px] text-emerald-300 block mt-1">On-Duty Interventional Team Alerted</span>
              </div>
            </div>

            {/* 🗺️ LIVE PATIENT EMERGENCY GPS INTERCEPT & CORRIDOR MAP */}
            <div className="p-5 rounded-3xl bg-slate-950 border border-rose-900/60 space-y-3 shadow-2xl">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
                <div className="flex items-center space-x-2.5">
                  <div className="p-2 rounded-xl bg-rose-600/20 text-rose-400 border border-rose-500/30">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-sm font-black text-white flex items-center gap-2">
                      <span>LIVE PATIENT EMERGENCY GPS & AMBULANCE CORRIDOR MAP</span>
                      <span className="inline-block w-2.5 h-2.5 rounded-full bg-rose-500 animate-ping"></span>
                    </h4>
                    <p className="text-[11px] text-slate-400">
                      Tracking Patient: <span className="text-rose-300 font-bold">{emergencyAlertInfo?.phone || '+91 98450-23491'}</span> • Destination: <span className="text-indigo-300 font-bold">{emergencyAlertInfo?.hospitalName || selectedHospital}</span>
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] text-rose-400 font-mono font-bold bg-rose-950/80 px-2.5 py-1 rounded-full border border-rose-800">
                    🔴 GPS LIVE TRACKING ACTIVE
                  </span>
                </div>
              </div>

              {/* Leaflet Map showing Patient, Destination Hospital, and Ambulance en route */}
              <div className="h-[360px] rounded-2xl overflow-hidden border border-slate-800 relative z-0">
                {(() => {
                  const patLat = emergencyAlertInfo?.coords?.lat || 17.3850;
                  const patLng = emergencyAlertInfo?.coords?.lng || 78.4867;
                  const hospLat = emergencyAlertInfo?.hospitalCoords?.lat || (patLat + 0.008);
                  const hospLng = emergencyAlertInfo?.hospitalCoords?.lng || (patLng + 0.006);
                  const ambLat = patLat * 0.45 + hospLat * 0.55;
                  const ambLng = patLng * 0.45 + hospLng * 0.55;
                  const centerLat = (patLat + hospLat) / 2;
                  const centerLng = (patLng + hospLng) / 2;

                  return (
                    <MapContainer
                      center={[centerLat, centerLng]}
                      zoom={14}
                      scrollWheelZoom={false}
                      className="w-full h-full"
                    >
                      <TileLayer
                        attribution='&copy; <a href="https://carto.com/">CARTO</a>'
                        url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
                      />

                      {/* Route Polyline connecting Patient -> Ambulance -> Hospital */}
                      <Polyline
                        positions={[
                          [patLat, patLng],
                          [ambLat, ambLng],
                          [hospLat, hospLng]
                        ]}
                        pathOptions={{
                          color: '#f43f5e',
                          weight: 5,
                          dashArray: '8, 8',
                          opacity: 0.9
                        }}
                      />

                      {/* 1. Patient Marker */}
                      <Marker position={[patLat, patLng]} icon={adminPatientIcon}>
                        <Popup className="custom-popup">
                          <div className="text-slate-900 p-1 text-xs">
                            <strong className="block text-rose-600 font-black text-sm">🚨 Emergency Patient Location</strong>
                            <div className="mt-1">Phone: <b>{emergencyAlertInfo?.phone || '+91 98450-23491'}</b></div>
                            <div>Symptoms: <b>{emergencyAlertInfo?.symptom || 'Cardiac Emergency'}</b></div>
                            <div>Blood Group: <b>{emergencyAlertInfo?.bloodGroup || 'O+'}</b></div>
                            <div className="text-slate-600 text-[10px] mt-0.5">{emergencyAlertInfo?.location || 'GPS Location'}</div>
                          </div>
                        </Popup>
                      </Marker>

                      {/* 2. Ambulance En Route Marker */}
                      <Marker position={[ambLat, ambLng]} icon={adminAmbIcon}>
                        <Popup className="custom-popup">
                          <div className="text-slate-900 p-1 text-xs">
                            <strong className="block text-amber-600 font-black text-sm">🚑 ALS Ambulance 108 (En Route)</strong>
                            <div>Speed: <b>62 km/h • Siren Active</b></div>
                            <div>Status: <b>Golden Hour Transit (ETA ~4 mins)</b></div>
                          </div>
                        </Popup>
                      </Marker>

                      {/* 3. Destination Hospital Marker */}
                      <Marker position={[hospLat, hospLng]} icon={adminHospIcon}>
                        <Popup className="custom-popup">
                          <div className="text-slate-900 p-1 text-xs">
                            <strong className="block text-indigo-600 font-black text-sm">🏥 {emergencyAlertInfo?.hospitalName || selectedHospital}</strong>
                            <div>Status: <b>Trauma Bay #2 & Cath Lab Reserved</b></div>
                            <div className="text-[10px] text-emerald-600 font-bold mt-1">Ready for Patient Arrival</div>
                          </div>
                        </Popup>
                      </Marker>
                    </MapContainer>
                  );
                })()}
              </div>

              {/* Map Legend */}
              <div className="flex flex-wrap items-center justify-between gap-2 pt-1 text-[11px] text-slate-400">
                <div className="flex items-center space-x-4">
                  <span className="flex items-center space-x-1.5">
                    <span className="text-base">📍</span>
                    <span className="text-white font-medium">Patient Location</span>
                  </span>
                  <span className="flex items-center space-x-1.5">
                    <span className="text-base">🚑</span>
                    <span className="text-amber-400 font-medium">108 Ambulance en route</span>
                  </span>
                  <span className="flex items-center space-x-1.5">
                    <span className="text-base">🏥</span>
                    <span className="text-indigo-400 font-medium">Destination Hospital</span>
                  </span>
                </div>
                <span className="text-[10px] text-emerald-400 font-mono">Green Corridor Priority Active</span>
              </div>
            </div>

            {/* Admission Trigger: Patient Received (Done) Button */}
            <div className="pt-2">
              {!patientAdmitted ? (
                <button
                  type="button"
                  onClick={handlePatientReceivedDone}
                  className="w-full py-4 sm:py-5 bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-500 hover:from-emerald-500 hover:to-teal-400 text-white font-black rounded-2xl text-base sm:text-lg transition flex items-center justify-center space-x-3 shadow-2xl shadow-emerald-950 border-2 border-emerald-400/50 transform active:scale-95"
                >
                  <CheckCircle2 className="w-6 h-6 text-white" />
                  <span>✅ PATIENT RECEIVED AT HOSPITAL (DONE) • ADMIT TO BAY #2</span>
                </button>
              ) : (
                <div className="p-6 bg-gradient-to-r from-emerald-950/90 via-teal-950/80 to-slate-900 border-2 border-emerald-500 text-emerald-200 rounded-3xl shadow-2xl space-y-3 text-center">
                  <div className="w-12 h-12 mx-auto rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/40 text-2xl font-bold">
                    🎉
                  </div>
                  <div>
                    <h4 className="text-lg font-black text-white">
                      PATIENT SAFELY RECEIVED & ADMITTED (INCIDENT RESOLVED ✅)
                    </h4>
                    <p className="text-xs text-emerald-300 mt-1 max-w-md mx-auto">
                      Clinical handoff complete. Patient admitted to Resuscitation Bay #2. Cath Lab active. Patient Portal & City Grid state cleared.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={handleResetEmergency}
                    className="px-5 py-2.5 bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white rounded-xl text-xs font-bold transition border border-slate-700 inline-flex items-center space-x-2"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>Reset / Acknowledge Next Emergency</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* TAB: DEDICATED CITY NETWORK LIVE MAP                                  */}
      {/* ===================================================================== */}
      {activeTab === 'map' && (
        <div className="space-y-4">
          <div className="p-6 rounded-3xl bg-slate-900/70 backdrop-blur-2xl border border-slate-700/60 shadow-xl flex items-center justify-between">
            <div>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                PULSEGRID LIVE CITY TELEMETRY
              </span>
              <h2 className="text-xl font-black text-white mt-1">Live City Hospital Network & Ambulance Fleet</h2>
              <p className="text-xs text-slate-400 mt-0.5">Real-time hospital network capacity, traffic corridors, and active ambulance dispatch routes.</p>
            </div>
          </div>
          <CityNetworkMap />
        </div>
      )}

      {/* ===================================================================== */}
      {/* TAB 4: AMBULANCE TELEMETRY & LIVE ALS STREAM                          */}
      {/* ===================================================================== */}
      {activeTab === 'telemetry' && (
        <div className="space-y-6">
          <div className="p-6 rounded-3xl bg-slate-900/70 backdrop-blur-2xl border border-slate-700/60 shadow-xl space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
              <div className="flex items-center space-x-3">
                <div className="p-3 bg-amber-500 text-slate-950 rounded-2xl font-bold shadow-lg shadow-amber-950">
                  <Ambulance className="w-7 h-7" />
                </div>
                <div>
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-amber-500 text-slate-950">
                    LIVE ALS TELEMETRY STREAM
                  </span>
                  <h2 className="text-xl font-black text-white mt-1">
                    {activeAmbulance?.callSign || 'Medic-01 (Advanced Life Support)'}
                  </h2>
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <button
                  onClick={() => activeAmbulance && actions.triggerMidTransitAutoDiversion(activeAmbulance.id)}
                  className="px-4 py-2.5 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-bold transition flex items-center space-x-1.5 shadow-md shadow-rose-950"
                >
                  <AlertTriangle className="w-4 h-4" />
                  <span>⚡ Simulate Sudden Surge & Auto-Diversion</span>
                </button>
              </div>
            </div>

            {/* Vitals Cards */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 text-center">
                <span className="text-[10px] text-slate-400 font-bold uppercase block">Heart Rate</span>
                <div className="text-2xl font-mono font-black text-rose-400 mt-1 flex items-center justify-center space-x-1">
                  <Heart className="w-5 h-5 text-rose-500 animate-pulse" />
                  <span>{activeAmbulance?.patientVitals?.heartRate || 118} BPM</span>
                </div>
                <span className="text-[9px] text-rose-300 block mt-1 font-bold">ST-Elevation STEMI</span>
              </div>

              <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 text-center">
                <span className="text-[10px] text-slate-400 font-bold uppercase block">Blood Pressure</span>
                <div className="text-2xl font-mono font-black text-amber-300 mt-1">
                  {activeAmbulance?.patientVitals?.bloodPressure || '88/56'}
                </div>
                <span className="text-[9px] text-amber-400 block mt-1">Hypotensive (IV running)</span>
              </div>

              <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 text-center">
                <span className="text-[10px] text-slate-400 font-bold uppercase block">SpO2 Oxygen</span>
                <div className="text-2xl font-mono font-black text-cyan-300 mt-1">
                  {activeAmbulance?.patientVitals?.spo2 || 91}%
                </div>
                <span className="text-[9px] text-cyan-400 block mt-1">High-Flow O2 Active</span>
              </div>

              <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 text-center">
                <span className="text-[10px] text-slate-400 font-bold uppercase block">Estimated Transit</span>
                <div className="text-2xl font-mono font-black text-emerald-400 mt-1">
                  {activeAmbulance?.etaMinutes || 6} MINS
                </div>
                <span className="text-[9px] text-emerald-300 block mt-1">Corridor Clearance 100%</span>
              </div>
            </div>

            {/* Crew Details */}
            <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
              <div>
                <span className="text-slate-400 block">Lead Paramedic:</span>
                <span className="text-white font-bold">{activeAmbulance?.paramedicName || 'Sr. Paramedic Anjali Sharma'}</span>
              </div>
              <div>
                <span className="text-slate-400 block">Emergency Pilot:</span>
                <span className="text-white font-bold">{activeAmbulance?.driverName || 'Rajesh Kumar'}</span>
              </div>
              <div>
                <span className="text-slate-400 block">Telemetry Transmission:</span>
                <span className="text-emerald-400 font-mono font-bold">256-bit Encrypted WebRTC Bus</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* TAB 6: SUPPLYSHIELD MEDICINE SUPPLY INTELLIGENCE                     */}
      {/* ===================================================================== */}
      {activeTab === 'supply' && (
        <SupplyShieldDashboard />
      )}

      {/* ===================================================================== */}
      {/* MODAL: REGISTER OFFLINE WALK-IN PATIENT (Counter Slip)                */}
      {/* ===================================================================== */}
      {isWalkInModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
          <div className="w-full max-w-lg rounded-3xl bg-slate-900 border border-slate-700 p-6 shadow-2xl space-y-5">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center space-x-2.5">
                <div className="w-9 h-9 rounded-xl bg-teal-500/20 text-teal-400 flex items-center justify-center">
                  <UserPlus className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black text-white">Register Offline Walk-In Patient</h3>
                  <p className="text-[11px] text-slate-400">Hospital Reception Kiosk • Unified Queue Integration</p>
                </div>
              </div>
              <button
                onClick={() => setIsWalkInModalOpen(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleRegisterOfflineWalkIn} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-300 mb-1">Patient Full Name *</label>
                <input
                  type="text"
                  value={walkInName}
                  onChange={(e) => setWalkInName(e.target.value)}
                  placeholder="e.g. Anand Sharma"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-teal-500"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-300 mb-1">Age</label>
                  <input
                    type="number"
                    value={walkInAge}
                    onChange={(e) => setWalkInAge(e.target.value)}
                    placeholder="e.g. 52"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-teal-500"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-300 mb-1">Gender</label>
                  <select
                    value={walkInGender}
                    onChange={(e) => setWalkInGender(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white focus:outline-none focus:ring-2 focus:ring-teal-500"
                  >
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-300 mb-1">Phone Number (Optional for SMS)</label>
                <input
                  type="tel"
                  value={walkInPhone}
                  onChange={(e) => setWalkInPhone(e.target.value)}
                  placeholder="+91 98450 00000"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-teal-500"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-300 mb-1">Chief Medical Symptoms *</label>
                <input
                  type="text"
                  value={walkInProblem}
                  onChange={(e) => setWalkInProblem(e.target.value)}
                  placeholder="e.g. Severe chest pain, shortness of breath"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-teal-500"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-300 mb-1">Department</label>
                  <select
                    value={walkInDept}
                    onChange={(e) => setWalkInDept(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white focus:outline-none focus:ring-2 focus:ring-teal-500"
                  >
                    <option value="Cardiology (Heart Care)">Cardiology (Heart Care)</option>
                    <option value="Orthopedics (Bone & Joint)">Orthopedics (Bone & Joint)</option>
                    <option value="General Internal Medicine">General Internal Medicine</option>
                    <option value="Pediatrics (Child Health)">Pediatrics (Child Health)</option>
                  </select>
                </div>
                <div>
                  <label className="block font-bold text-slate-300 mb-1">Priority Category</label>
                  <select
                    value={walkInPriority}
                    onChange={(e) => setWalkInPriority(e.target.value as any)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white focus:outline-none focus:ring-2 focus:ring-teal-500"
                  >
                    <option value="Standard">Standard Walk-In</option>
                    <option value="Senior Citizen">Senior Citizen Priority</option>
                    <option value="Urgent Triaged">Urgent Clinical Triage</option>
                  </select>
                </div>
              </div>

              <div className="pt-2 flex items-center space-x-3">
                <button
                  type="button"
                  onClick={() => setIsWalkInModalOpen(false)}
                  className="flex-1 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-bold transition flex items-center justify-center space-x-1.5 shadow-lg shadow-teal-950"
                >
                  <Printer className="w-4 h-4" />
                  <span>Issue & Print Kiosk Slip</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* MODAL: PRINTED PHYSICAL KIOSK SLIP PREVIEW                            */}
      {/* ===================================================================== */}
      {newlyPrintedSlip && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md">
          <div className="w-full max-w-sm rounded-3xl bg-white text-slate-900 p-6 shadow-2xl space-y-4 font-mono">
            <div className="text-center border-b border-dashed border-slate-400 pb-3">
              <h4 className="text-sm font-black uppercase tracking-wider">{selectedHospital}</h4>
              <p className="text-[10px] text-slate-600">OFFLINE OPD COUNTER TOKEN SLIP</p>
              <div className="text-3xl font-black text-indigo-900 mt-2">
                {newlyPrintedSlip.token}
              </div>
            </div>

            <div className="space-y-1.5 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-600">Patient:</span>
                <span className="font-bold">{newlyPrintedSlip.name} ({newlyPrintedSlip.age}y/{newlyPrintedSlip.gender[0]})</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-600">Department:</span>
                <span className="font-bold">{newlyPrintedSlip.department}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-600">Doctor:</span>
                <span className="font-bold">Dr. Sudhir Rao, MD (Room 204)</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-600">Issued At:</span>
                <span className="font-bold">{new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
              </div>
              <div className="flex justify-between border-t border-dashed border-slate-300 pt-1.5">
                <span className="text-slate-600">Current Queue:</span>
                <span className="font-bold text-indigo-700">Unified with Online App</span>
              </div>
            </div>

            <div className="p-2.5 rounded-xl bg-slate-100 text-center text-[10px] text-slate-700">
              Please take a seat in OPD Waiting Lobby. You will be called by audio announcement when your token appears on screen.
            </div>

            <button
              onClick={() => {
                setNewlyPrintedSlip(null);
                setIsWalkInModalOpen(false);
              }}
              className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-xl text-xs transition"
            >
              Done / Close Slip Preview
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminPortal;
