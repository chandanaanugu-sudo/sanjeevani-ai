import React from 'react';
import {
  Activity,
  AlertTriangle,
  ArrowRight,
  ArrowRightLeft,
  CheckCircle2,
  Clock3,
  Package,
  RefreshCw,
  ShieldCheck,
  Truck,
  TrendingUp,
  Zap
} from 'lucide-react';
import { useHealthEcosystem } from '../../store/healthEcosystemStore';

const riskStyles = {
  safe: {
    badge: 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30',
    bar: 'bg-emerald-500',
    label: 'SAFE'
  },
  moderate: {
    badge: 'bg-amber-500/10 text-amber-300 border-amber-500/30',
    bar: 'bg-amber-500',
    label: 'MODERATE'
  },
  high: {
    badge: 'bg-orange-500/10 text-orange-300 border-orange-500/30',
    bar: 'bg-orange-500',
    label: 'HIGH'
  },
  critical: {
    badge: 'bg-rose-500/10 text-rose-300 border-rose-500/30',
    bar: 'bg-rose-500',
    label: 'CRITICAL'
  }
};

const deliveryStyles = {
  low: 'text-emerald-300',
  medium: 'text-amber-300',
  high: 'text-rose-300'
};

export const SupplyShieldDashboard: React.FC = () => {
  const {
    medicineInventory,
    medicineSuppliers,
    supplyPredictions,
    redistributionRecommendations,
    hospitals,
    actions
  } = useHealthEcosystem();

  const hospitalName = (hospitalId: string) =>
    hospitals.find(h => h.id === hospitalId)?.shortCode ||
    hospitals.find(h => h.id === hospitalId)?.name ||
    hospitalId;

  const supplierFor = (supplierId: string) =>
    medicineSuppliers.find(supplier => supplier.id === supplierId);

  const criticalCount = supplyPredictions.filter(
    prediction => prediction.riskLevel === 'critical'
  ).length;

  const highCount = supplyPredictions.filter(
    prediction => prediction.riskLevel === 'high'
  ).length;

  const supplierCount = medicineSuppliers.length;

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="rounded-3xl border border-cyan-500/20 bg-slate-900/80 p-5 shadow-xl">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div className="flex items-start gap-3">
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl border border-cyan-500/30 bg-cyan-500/10 text-cyan-300">
              <ShieldCheck className="h-6 w-6" />
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h2 className="text-xl font-black text-white">
                  SupplyShield
                </h2>
                <span className="rounded-full border border-cyan-500/30 bg-cyan-500/10 px-2 py-0.5 text-[9px] font-black uppercase tracking-wider text-cyan-300">
                  Medicine Supply Intelligence
                </span>
              </div>
              <p className="mt-1 text-xs text-slate-400">
                Predict medicine shortages before patients face them.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            <button
              onClick={() =>
                actions.simulateMedicineDemandSpike(
                  'med-atorvastatin-apollo',
                  1.5
                )
              }
              className="flex items-center gap-2 rounded-xl bg-cyan-600 px-3.5 py-2.5 text-xs font-black text-white shadow-lg shadow-cyan-950 transition hover:bg-cyan-500"
            >
              <Zap className="h-4 w-4" />
              Simulate Demand Spike
            </button>

            <button
              onClick={() =>
                actions.generateRedistributionRecommendations()
              }
              className="flex items-center gap-2 rounded-xl border border-slate-700 bg-slate-950/70 px-3.5 py-2.5 text-xs font-bold text-slate-200 transition hover:border-cyan-500/50 hover:bg-slate-900"
            >
              <RefreshCw className="h-4 w-4" />
              Recalculate
            </button>

            <button
              onClick={() => actions.resetSupplyShieldDemo()}
              className="rounded-xl border border-slate-800 bg-slate-950/50 px-3 py-2.5 text-xs font-bold text-slate-500 transition hover:text-white"
            >
              Reset Demo
            </button>
          </div>
        </div>
      </div>

      {/* KPI cards */}
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <div className="rounded-2xl border border-slate-800 bg-slate-900/70 p-4">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-black uppercase tracking-wider text-slate-500">
              Medicines Tracked
            </span>
            <Package className="h-4 w-4 text-cyan-400" />
          </div>
          <div className="mt-2 text-2xl font-black text-white">
            {medicineInventory.length}
          </div>
          <div className="mt-1 text-[10px] text-slate-500">
            Across connected hospitals
          </div>
        </div>

        <div className="rounded-2xl border border-rose-500/20 bg-rose-500/5 p-4">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-black uppercase tracking-wider text-rose-300">
              Critical Risk
            </span>
            <AlertTriangle className="h-4 w-4 text-rose-400" />
          </div>
          <div className="mt-2 text-2xl font-black text-rose-300">
            {criticalCount}
          </div>
          <div className="mt-1 text-[10px] text-slate-500">
            Immediate action required
          </div>
        </div>

        <div className="rounded-2xl border border-orange-500/20 bg-orange-500/5 p-4">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-black uppercase tracking-wider text-orange-300">
              High Risk
            </span>
            <TrendingUp className="h-4 w-4 text-orange-400" />
          </div>
          <div className="mt-2 text-2xl font-black text-orange-300">
            {highCount}
          </div>
          <div className="mt-1 text-[10px] text-slate-500">
            Replenishment planning
          </div>
        </div>

        <div className="rounded-2xl border border-emerald-500/20 bg-emerald-500/5 p-4">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-black uppercase tracking-wider text-emerald-300">
              Supplier Network
            </span>
            <Truck className="h-4 w-4 text-emerald-400" />
          </div>
          <div className="mt-2 text-2xl font-black text-emerald-300">
            {supplierCount}
          </div>
          <div className="mt-1 text-[10px] text-slate-500">
            Connected suppliers
          </div>
        </div>
      </div>

      {/* Main inventory table */}
      <div className="overflow-hidden rounded-3xl border border-slate-800 bg-slate-900/70">
        <div className="flex items-center justify-between border-b border-slate-800 px-5 py-4">
          <div>
            <h3 className="text-sm font-black text-white">
              Medicine Inventory & Risk Forecast
            </h3>
            <p className="mt-0.5 text-[10px] text-slate-500">
              Forecast uses recent demand trend and current stock.
            </p>
          </div>
          <Activity className="h-5 w-5 text-cyan-400" />
        </div>

        <div className="overflow-x-auto">
          <table className="w-full min-w-[900px] text-left">
            <thead className="bg-slate-950/70 text-[9px] uppercase tracking-wider text-slate-500">
              <tr>
                <th className="px-5 py-3">Medicine</th>
                <th className="px-4 py-3">Hospital</th>
                <th className="px-4 py-3">Stock</th>
                <th className="px-4 py-3">Forecast / Day</th>
                <th className="px-4 py-3">Stockout</th>
                <th className="px-4 py-3">Demand Trend</th>
                <th className="px-4 py-3">Risk</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {medicineInventory.map(item => {
                const prediction = supplyPredictions.find(
                  value => value.medicineId === item.id
                );

                if (!prediction) return null;

                const style = riskStyles[prediction.riskLevel];
                const supplier = supplierFor(item.supplierId);

                return (
                  <tr
                    key={item.id}
                    className="transition hover:bg-slate-800/30"
                  >
                    <td className="px-5 py-4">
                      <div className="font-bold text-white">
                        {item.medicineName}
                      </div>
                      <div className="mt-1 text-[9px] text-slate-500">
                        {item.category} • {item.unit}
                      </div>
                    </td>

                    <td className="px-4 py-4">
                      <div className="text-xs font-bold text-slate-200">
                        {hospitalName(item.hospitalId)}
                      </div>
                      <div className="mt-1 text-[9px] text-slate-500">
                        Supplier: {supplier?.name || 'Unknown'}
                      </div>
                    </td>

                    <td className="px-4 py-4">
                      <div className="text-sm font-black text-white">
                        {item.currentStock}
                      </div>
                      <div className="mt-1 text-[9px] text-slate-500">
                        Min: {item.minimumStock}
                      </div>
                    </td>

                    <td className="px-4 py-4">
                      <div className="text-sm font-black text-cyan-300">
                        {prediction.forecastDailyDemand}
                      </div>
                      <div className="mt-1 text-[9px] text-slate-500">
                        {item.unit}/day
                      </div>
                    </td>

                    <td className="px-4 py-4">
                      <div className="text-sm font-black text-white">
                        {prediction.daysUntilStockout} days
                      </div>
                      <div className="mt-1 flex items-center gap-1 text-[9px] text-slate-500">
                        <Clock3 className="h-3 w-3" />
                        {prediction.daysUntilMinimumStock} days to minimum
                      </div>
                    </td>

                    <td className="px-4 py-4">
                      <div className="flex items-center gap-2">
                        <TrendingUp className="h-3.5 w-3.5 text-cyan-400" />
                        <span
                          className={
                            prediction.demandGrowthPercent > 20
                              ? 'text-xs font-black text-rose-300'
                              : 'text-xs font-bold text-slate-300'
                          }
                        >
                          +{prediction.demandGrowthPercent}%
                        </span>
                      </div>
                    </td>

                    <td className="px-4 py-4">
                      <span
                        className={`inline-flex rounded-full border px-2 py-1 text-[9px] font-black ${style.badge}`}
                      >
                        {style.label}
                      </span>
                      <div className="mt-2 h-1.5 w-20 overflow-hidden rounded-full bg-slate-800">
                        <div
                          className={`h-full ${style.bar}`}
                          style={{
                            width:
                              prediction.riskLevel === 'critical'
                                ? '100%'
                                : prediction.riskLevel === 'high'
                                  ? '75%'
                                  : prediction.riskLevel === 'moderate'
                                    ? '50%'
                                    : '25%'
                          }}
                        />
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Demo explanation */}
      <div className="grid gap-4 lg:grid-cols-2">
        <div className="rounded-3xl border border-cyan-500/20 bg-cyan-500/5 p-5">
          <div className="flex items-center gap-2">
            <Zap className="h-5 w-5 text-cyan-300" />
            <h3 className="text-sm font-black text-white">
              Predictive Demo
            </h3>
          </div>

          <div className="mt-4 space-y-3 text-xs">
            <div className="flex items-center gap-3">
              <div className="rounded-lg bg-slate-900 px-2.5 py-2 font-black text-white">
                120
              </div>
              <ArrowRight className="h-4 w-4 text-cyan-400" />
              <div className="text-slate-300">
                Atorvastatin tablets at Apollo
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="rounded-lg bg-rose-500/10 px-2.5 py-2 font-black text-rose-300">
                +50% demand
              </div>
              <ArrowRight className="h-4 w-4 text-cyan-400" />
              <div className="text-slate-300">
                SupplyShield recalculates stockout horizon
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="rounded-lg bg-emerald-500/10 px-2.5 py-2 font-black text-emerald-300">
                City Care
              </div>
              <ArrowRight className="h-4 w-4 text-cyan-400" />
              <div className="text-slate-300">
                Surplus inventory identified
              </div>
            </div>
          </div>
        </div>

        {/* Supplier cards */}
        <div className="rounded-3xl border border-slate-800 bg-slate-900/70 p-5">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-black text-white">
                Supplier Network
              </h3>
              <p className="mt-1 text-[10px] text-slate-500">
                Delivery reliability and lead-time intelligence.
              </p>
            </div>
            <Truck className="h-5 w-5 text-emerald-400" />
          </div>

          <div className="mt-4 space-y-3">
            {medicineSuppliers.map(supplier => (
              <div
                key={supplier.id}
                className="rounded-2xl border border-slate-800 bg-slate-950/50 p-3"
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black text-white">
                    {supplier.name}
                  </span>
                  <span className="text-xs font-black text-emerald-300">
                    {supplier.reliabilityScore}%
                  </span>
                </div>

                <div className="mt-2 flex flex-wrap gap-2 text-[9px] text-slate-500">
                  <span>{supplier.location}</span>
                  <span>•</span>
                  <span>{supplier.averageDeliveryHours}h avg delivery</span>
                </div>

                <div className="mt-2 flex flex-wrap gap-1.5">
                  {supplier.availableMedicines.map(medicine => (
                    <span
                      key={medicine}
                      className="rounded-md border border-slate-700 bg-slate-900 px-2 py-1 text-[8px] font-bold text-slate-400"
                    >
                      {medicine}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Redistribution */}
      <div className="rounded-3xl border border-emerald-500/20 bg-slate-900/70">
        <div className="flex flex-col gap-3 border-b border-slate-800 px-5 py-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h3 className="text-sm font-black text-white">
              Smart Redistribution
            </h3>
            <p className="mt-1 text-[10px] text-slate-500">
              SupplyShield identifies protected surplus and recommends an inter-hospital transfer.
            </p>
          </div>

          <span className="rounded-full border border-emerald-500/30 bg-emerald-500/10 px-2.5 py-1 text-[9px] font-black text-emerald-300">
            {redistributionRecommendations.length} recommendation(s)
          </span>
        </div>

        <div className="p-5">
          {redistributionRecommendations.length === 0 ? (
            <div className="rounded-2xl border border-dashed border-slate-700 bg-slate-950/40 p-6 text-center">
              <ArrowRightLeft className="mx-auto h-7 w-7 text-slate-600" />
              <p className="mt-2 text-xs font-bold text-slate-400">
                No transfer recommendation yet.
              </p>
              <p className="mt-1 text-[10px] text-slate-600">
                Click “Simulate Demand Spike” to trigger the hackathon demo.
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {redistributionRecommendations.map(recommendation => (
                <div
                  key={recommendation.id}
                  className="rounded-2xl border border-emerald-500/20 bg-emerald-500/5 p-4"
                >
                  <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
                    <div>
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="text-sm font-black text-white">
                          {recommendation.medicineName}
                        </span>
                        <span className="rounded-full bg-emerald-500/10 px-2 py-1 text-[9px] font-black text-emerald-300">
                          {recommendation.quantity} units
                        </span>
                      </div>

                      <div className="mt-3 flex flex-wrap items-center gap-2 text-xs">
                        <span className="rounded-lg border border-slate-700 bg-slate-950 px-2.5 py-2 font-bold text-slate-200">
                          {hospitalName(
                            recommendation.sourceHospitalId
                          )}
                        </span>

                        <ArrowRight className="h-4 w-4 text-emerald-400" />

                        <span className="rounded-lg border border-slate-700 bg-slate-950 px-2.5 py-2 font-bold text-slate-200">
                          {hospitalName(
                            recommendation.destinationHospitalId
                          )}
                        </span>
                      </div>

                      <p className="mt-3 max-w-2xl text-[10px] leading-relaxed text-slate-400">
                        {recommendation.reason}
                      </p>
                    </div>

                    <div className="flex shrink-0 flex-col gap-2">
                      <div className="flex items-center justify-between gap-5 text-[9px] text-slate-500">
                        <span>
                          Source after transfer:{' '}
                          <strong className="text-slate-300">
                            {recommendation.sourceRemainingStock}
                          </strong>
                        </span>
                        <span>
                          Destination:{' '}
                          <strong className="text-emerald-300">
                            {recommendation.destinationProjectedStock}
                          </strong>
                        </span>
                      </div>

                      <button
                        onClick={() =>
                          actions.approveRedistribution(
                            recommendation.id
                          )
                        }
                        className="flex items-center justify-center gap-2 rounded-xl bg-emerald-600 px-4 py-2.5 text-xs font-black text-white shadow-lg shadow-emerald-950 transition hover:bg-emerald-500"
                      >
                        <CheckCircle2 className="h-4 w-4" />
                        Approve Transfer
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Delivery risk note */}
      <div className="rounded-2xl border border-slate-800 bg-slate-950/50 p-4">
        <div className="flex items-start gap-3">
          <Truck className="mt-0.5 h-4 w-4 shrink-0 text-cyan-400" />
          <div>
            <p className="text-xs font-black text-slate-200">
              Delivery Risk Intelligence
            </p>
            <p className="mt-1 text-[10px] leading-relaxed text-slate-500">
              SupplyShield compares supplier lead time against the predicted stockout horizon.
              A supplier delivery that arrives after the predicted shortage is flagged as high delivery risk.
            </p>
            <div className="mt-2 flex flex-wrap gap-3 text-[9px] font-bold">
              <span className={deliveryStyles.low}>● LOW</span>
              <span className={deliveryStyles.medium}>● MEDIUM</span>
              <span className={deliveryStyles.high}>● HIGH</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SupplyShieldDashboard;
