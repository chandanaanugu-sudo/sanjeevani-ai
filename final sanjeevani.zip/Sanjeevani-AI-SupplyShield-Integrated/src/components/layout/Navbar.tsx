import React, { useState } from 'react';
import { useHealthEcosystem } from '../../store/healthEcosystemStore';
import { 
  Activity, 
  Ambulance, 
  Building2, 
  Globe2, 
  AlertTriangle, 
  Sparkles, 
  Volume2, 
  VolumeX, 
  RefreshCw,
  Clock,
  ShieldAlert,
  Phone
} from 'lucide-react';
import { CLINICAL_PRESETS } from '../../services/geminiTriage';

interface NavbarProps {
  isAdmin?: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({ isAdmin }) => {
  const { activeRole, notifications, ambulances, actions } = useHealthEcosystem();
  const [soundEnabled, setSoundEnabled] = useState(true);
  const isHospital = isAdmin ?? (activeRole !== 'patient');
  const activeAmbulance = ambulances[0];

  const handleSimulateSOS = () => {
    actions.createEmergencySOS(
      'Kailash Nath',
      CLINICAL_PRESETS.cardiac.chiefComplaint,
      CLINICAL_PRESETS.cardiac,
      {
        lat: 12.9645,
        lng: 77.5840,
        addressText: '4th Cross, Gandhi Nagar, Metro Hub'
      }
    );
  };

  const handleSimulateDiversion = () => {
    if (activeAmbulance) {
      actions.triggerMidTransitAutoDiversion(activeAmbulance.id);
    }
  };

  const latestNotification = notifications[0];

  return (
    <header className="sticky top-0 z-50 border-b border-slate-800 bg-slate-950/90 backdrop-blur-md">
      {/* Top Banner: Real-time Emergency Ticker */}
      {latestNotification && (
        <div className={`px-4 py-1.5 text-xs font-medium flex items-center justify-between border-b ${
          latestNotification.type === 'diversion'
            ? 'bg-amber-950/80 border-amber-800 text-amber-200'
            : latestNotification.type === 'alert'
            ? 'bg-rose-950/80 border-rose-800 text-rose-200'
            : 'bg-slate-900 border-slate-800 text-slate-300'
        }`}>
          <div className="flex items-center space-x-2 truncate">
            {latestNotification.type === 'diversion' ? (
              <RefreshCw className="w-3.5 h-3.5 animate-spin text-amber-400" />
            ) : latestNotification.type === 'alert' ? (
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-rose-500"></span>
              </span>
            ) : (
              <ShieldAlert className="w-3.5 h-3.5 text-cyan-400" />
            )}
            <span className="font-semibold uppercase tracking-wider text-[10px]">
              {latestNotification.type === 'diversion' ? 'MID-TRANSIT AUTO-DIVERSION' : 'PULSEGRID REALTIME DISPATCH'}:
            </span>
            <span className="truncate">{latestNotification.message}</span>
          </div>
          <span className="text-[10px] text-slate-400 ml-4 shrink-0">{latestNotification.time}</span>
        </div>
      )}

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Brand Logo */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-500 flex items-center justify-center shadow-lg shadow-emerald-950/40 ring-1 ring-white/20">
              <span className="text-xl">🌿</span>
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-lg font-bold tracking-tight text-white">Sanjeevani <span className="text-emerald-400 font-black">AI</span></span>
                <span className="px-2 py-0.5 text-[10px] font-bold bg-emerald-950 text-emerald-400 border border-emerald-800/80 rounded-full">
                  {!isHospital ? 'PATIENT PORTAL' : 'HOSPITAL ADMIN DESK'}
                </span>
              </div>
              <p className="text-[11px] text-slate-400 hidden sm:block">
                {!isHospital ? 'Smart OPD Queue & Rapid Emergency Life-Line' : 'Emergency Trauma Command & Ward Management'}
              </p>
            </div>
          </div>

          {/* Center Navigation: Patient vs Staff Mode */}
          {!isHospital ? (
            <div className="hidden md:flex items-center space-x-3 bg-slate-900/80 px-4 py-2 rounded-2xl border border-slate-800 text-xs">
              <span className="flex items-center space-x-1.5 text-emerald-400 font-semibold">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                <span>4 Emergency Hospitals Live</span>
              </span>
              <span className="text-slate-700">|</span>
              <span className="text-slate-300">
                ⚡ Just-in-Time Home Waiting Active
              </span>
            </div>
          ) : (
            <div className="flex items-center space-x-2 bg-slate-900/80 px-4 py-2 rounded-2xl border border-slate-800 text-xs font-semibold text-indigo-300">
              <Building2 className="w-4 h-4 text-indigo-400" />
              <span>Apollo Hospital Command Network • Live</span>
            </div>
          )}

          {/* Right Header Controls */}
          <div className="flex items-center space-x-2">
            {!isHospital ? (
              <a
                href="tel:108"
                className="flex items-center space-x-1.5 px-3.5 py-1.5 rounded-xl bg-rose-950/80 hover:bg-rose-900 border border-rose-700/60 text-rose-300 text-xs font-bold transition shadow-sm"
              >
                <Phone className="w-3.5 h-3.5 text-rose-400" />
                <span>24x7 Helpline: 108</span>
              </a>
            ) : (
              <a
                href="/"
                className="px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition shadow-md flex items-center space-x-1.5"
              >
                <Activity className="w-3.5 h-3.5" />
                <span>← Exit to Patient Portal</span>
              </a>
            )}

            <button
              onClick={() => setSoundEnabled(!soundEnabled)}
              title={soundEnabled ? 'Mute Audio' : 'Unmute Audio'}
              className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white transition"
            >
              {soundEnabled ? <Volume2 className="w-4 h-4 text-emerald-400" /> : <VolumeX className="w-4 h-4 text-slate-500" />}
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
