import React, { useState, useEffect } from 'react';
import { useHealthEcosystem } from '../../store/healthEcosystemStore';
import { MapContainer, TileLayer, Marker, Popup, Polyline } from 'react-leaflet';
import L from 'leaflet';
import { 
  Building2, 
  Activity, 
  MapPin, 
  Compass,
  CheckCircle2
} from 'lucide-react';

const createHospitalIcon = (status: string) => {
  const bgClass = 
    status === 'saturated' ? 'bg-rose-600' :
    status === 'busy' ? 'bg-amber-500' : 'bg-indigo-600';

  return L.divIcon({
    className: 'custom-hosp-icon',
    html: `<div class="${bgClass} w-8 h-8 rounded-xl flex items-center justify-center text-white shadow-lg border-2 border-white font-bold text-xs">
            🏥
           </div>`,
    iconSize: [32, 32],
    iconAnchor: [16, 16]
  });
};

const createAmbulanceIcon = (isDiverted: boolean) => {
  const bgClass = isDiverted ? 'bg-amber-500' : 'bg-rose-600';
  return L.divIcon({
    className: 'custom-amb-icon',
    html: `<div class="${bgClass} w-9 h-9 rounded-full flex items-center justify-center text-white shadow-xl border-2 border-white animate-pulse text-sm">
            🚑
           </div>`,
    iconSize: [36, 36],
    iconAnchor: [18, 18]
  });
};

const createPatientIcon = () => {
  return L.divIcon({
    className: 'custom-patient-icon',
    html: `<div class="bg-rose-600 w-8 h-8 rounded-full flex items-center justify-center text-white shadow-xl border-2 border-white animate-bounce text-xs">
            📍
           </div>`,
    iconSize: [32, 32],
    iconAnchor: [16, 16]
  });
};

export const CityNetworkMap: React.FC = () => {
  const { ambulances } = useHealthEcosystem();
  const [centerCoords, setCenterCoords] = useState<[number, number]>([17.3850, 78.4867]);
  const [locationName, setLocationName] = useState('Detecting matching location...');

  const [cityHospitals, setCityHospitals] = useState([
    { id: 'h1', name: 'Apollo Emergency & Multi-Speciality', lat: 17.3850 + 0.008, lng: 78.4867 + 0.006, distance: '1.8 km', status: 'optimal', icu: 3, er: 8, address: 'Health Hub Way' },
    { id: 'h2', name: 'City Care Trauma & Stroke Center', lat: 17.3850 - 0.009, lng: 78.4867 + 0.012, distance: '2.5 km', status: 'optimal', icu: 2, er: 6, address: 'Metro West Corridor' },
    { id: 'h3', name: 'Metro Regional Super-Speciality Hospital', lat: 17.3850 + 0.015, lng: 78.4867 - 0.008, distance: '3.9 km', status: 'busy', icu: 4, er: 12, address: 'Sector 4 Emergency Line' },
    { id: 'h4', name: 'Government General Hospital (GGH)', lat: 17.3850 - 0.012, lng: 78.4867 - 0.015, distance: '4.7 km', status: 'optimal', icu: 1, er: 14, address: 'Civil Hospital Road' }
  ]);

  // Sync with user's real GPS location (Same as Patient Booking)
  useEffect(() => {
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition((pos) => {
        const lat = pos.coords.latitude;
        const lng = pos.coords.longitude;
        setCenterCoords([lat, lng]);
        setLocationName(`Same GPS Surroundings: Lat ${lat.toFixed(3)}, Lng ${lng.toFixed(3)}`);

        setCityHospitals([
          { id: 'h1', name: 'Apollo Emergency & Multi-Speciality', lat: lat + 0.008, lng: lng + 0.006, distance: '1.8 km', status: 'optimal', icu: 3, er: 8, address: 'Main Ring Road, Health Hub 1' },
          { id: 'h2', name: 'City Care Trauma & Stroke Center', lat: lat - 0.009, lng: lng + 0.012, distance: '2.5 km', status: 'optimal', icu: 2, er: 6, address: 'Metro West Corridor' },
          { id: 'h3', name: 'Metro Regional Super-Speciality Hospital', lat: lat + 0.015, lng: lng - 0.008, distance: '3.9 km', status: 'busy', icu: 4, er: 12, address: 'Sector 4 Emergency Zone' },
          { id: 'h4', name: 'Government General Hospital (GGH)', lat: lat - 0.012, lng: lng - 0.015, distance: '4.7 km', status: 'optimal', icu: 1, er: 14, address: 'Civil Hospital Road' }
        ]);
      }, () => {
        setLocationName('City Center Emergency Zone (Synchronized Default GPS)');
      });
    }
  }, []);

  const totalER = cityHospitals.reduce((acc, h) => acc + h.er, 0);
  const totalICU = cityHospitals.reduce((acc, h) => acc + h.icu, 0);

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Top Synchronized Location Header */}
      <div className="p-5 bg-slate-900 border border-slate-800 rounded-3xl flex flex-col sm:flex-row items-center justify-between gap-4 shadow-xl">
        <div className="flex items-center space-x-3">
          <div className="p-3 bg-cyan-600/20 text-cyan-400 rounded-2xl border border-cyan-500/30">
            <Compass className="w-6 h-6 animate-spin" />
          </div>
          <div>
            <h2 className="text-xl font-black text-white">City Emergency Grid Radar</h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Synchronized with Patient Location: <strong className="text-cyan-400">{locationName}</strong>
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-3">
          <div className="px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-center">
            <span className="text-slate-400 block text-[10px] uppercase font-bold">Total Free ER Beds</span>
            <span className="text-lg font-black text-white">{totalER}</span>
          </div>
          <div className="px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-center">
            <span className="text-slate-400 block text-[10px] uppercase font-bold">Total ICU Reserve</span>
            <span className="text-lg font-black text-emerald-400">{totalICU}</span>
          </div>
        </div>
      </div>

      {/* Main Map + Facility Ledger */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Map Container */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-3xl p-4 shadow-xl h-[540px] flex flex-col">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-2 text-xs">
            <span className="text-slate-300 font-bold">Live GPS Synchronized Surroundings</span>
            <div className="flex space-x-3">
              <span className="flex items-center space-x-1">
                <span className="w-2.5 h-2.5 rounded-full bg-indigo-600"></span>
                <span className="text-slate-400">Hospital</span>
              </span>
              <span className="flex items-center space-x-1">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-600"></span>
                <span className="text-slate-400">Patient Pin</span>
              </span>
            </div>
          </div>

          <div className="flex-1 rounded-2xl overflow-hidden">
            <MapContainer
              center={centerCoords}
              zoom={13}
              style={{ height: '100%', width: '100%' }}
              scrollWheelZoom={false}
            >
              <TileLayer
                attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              />

              {/* Patient Pin */}
              <Marker position={centerCoords} icon={createPatientIcon()}>
                <Popup>Patient Exact GPS Spot</Popup>
              </Marker>

              {/* Hospitals */}
              {cityHospitals.map(h => (
                <Marker key={h.id} position={[h.lat, h.lng]} icon={createHospitalIcon(h.status)}>
                  <Popup>
                    <div className="text-xs p-1">
                      <strong className="text-sm font-bold text-slate-900 block">{h.name}</strong>
                      <p className="text-slate-600">{h.address}</p>
                      <div className="mt-1 font-bold text-indigo-700">Distance: {h.distance} • ICU: {h.icu} Beds</div>
                    </div>
                  </Popup>
                </Marker>
              ))}

              {/* Active Ambulance */}
              <Marker position={[centerCoords[0] + 0.005, centerCoords[1] + 0.005]} icon={createAmbulanceIcon(false)}>
                <Popup>Ambulance KA-04-1234 (En Route to Apollo)</Popup>
              </Marker>

              {/* Route Line */}
              <Polyline
                positions={[
                  [centerCoords[0] + 0.005, centerCoords[1] + 0.005],
                  [centerCoords[0], centerCoords[1]]
                ]}
                pathOptions={{ color: '#ef4444', weight: 4, dashArray: '6, 6' }}
              />
            </MapContainer>
          </div>
        </div>

        {/* Right Ledger */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-xl space-y-3">
          <h3 className="text-sm font-bold text-white border-b border-slate-800 pb-2">
            Surroundings Facilities Ledger
          </h3>
          <div className="space-y-2.5 overflow-y-auto max-h-[440px]">
            {cityHospitals.map(h => (
              <div key={h.id} className="p-3 bg-slate-950/80 border border-slate-800 rounded-2xl text-xs space-y-1">
                <div className="flex justify-between items-center font-bold text-white">
                  <span className="truncate">{h.name}</span>
                  <span className="text-rose-400 shrink-0 font-black">{h.distance}</span>
                </div>
                <div className="text-[11px] text-slate-400">{h.address}</div>
                <div className="flex justify-between text-[11px] pt-1">
                  <span className="text-emerald-400 font-semibold">{h.icu} ICU Beds Available</span>
                  <span className="text-indigo-300 font-semibold">{h.er} ER Beds</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default CityNetworkMap;
