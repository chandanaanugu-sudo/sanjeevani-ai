import React, { useState, useEffect } from 'react';
import { audioService } from '../../services/audioService';
import { Heart, Volume2, VolumeX, AlertCircle, ShieldAlert, CheckCircle2 } from 'lucide-react';

interface BystanderCPRCopilotProps {
  onClose?: () => void;
  etaMinutes?: number;
}

export const BystanderCPRCopilot: React.FC<BystanderCPRCopilotProps> = ({ onClose, etaMinutes = 6 }) => {
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [beatCount, setBeatCount] = useState(0);

  useEffect(() => {
    // Start audio metronome automatically when opened
    audioService.startCPRMetronome((count) => {
      setBeatCount(count);
    });
    setIsPlayingAudio(true);

    return () => {
      audioService.stopCPRMetronome();
    };
  }, []);

  const toggleMetronomeAudio = () => {
    if (isPlayingAudio) {
      audioService.stopCPRMetronome();
      setIsPlayingAudio(false);
    } else {
      audioService.startCPRMetronome((count) => {
        setBeatCount(count);
      });
      setIsPlayingAudio(true);
    }
  };

  const compressionInCycle = (beatCount % 30) + 1;
  const cycleCount = Math.floor(beatCount / 30) + 1;

  return (
    <div className="bg-slate-900 border-2 border-rose-600/80 rounded-2xl p-6 shadow-2xl shadow-rose-950/50 relative overflow-hidden">
      {/* Background Pulse Glow */}
      <div className="absolute -right-20 -top-20 w-64 h-64 bg-rose-600/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-5">
        <div className="flex items-center space-x-3">
          <div className="p-2 rounded-xl bg-rose-600/20 text-rose-400 border border-rose-500/30">
            <ShieldAlert className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <h3 className="text-lg font-black text-white flex items-center space-x-2">
              <span>BYSTANDER FIRST-AID COPILOT</span>
              <span className="px-2 py-0.5 bg-rose-600 text-white text-[10px] uppercase font-black tracking-widest rounded-full">
                110 BPM RHYTHM
              </span>
            </h3>
            <p className="text-xs text-rose-300/80 font-medium">
              Ambulance en route (ETA ~{etaMinutes} mins) • Continuous CPR preserves brain perfusion
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={toggleMetronomeAudio}
            className={`flex items-center space-x-1 px-3 py-1.5 rounded-lg text-xs font-semibold border transition ${
              isPlayingAudio
                ? 'bg-rose-600 text-white border-rose-500 shadow-md shadow-rose-900/40'
                : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
            }`}
          >
            {isPlayingAudio ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            <span>{isPlayingAudio ? 'Audio Click ON' : 'Unmute Click'}</span>
          </button>
          {onClose && (
            <button
              onClick={onClose}
              className="text-slate-400 hover:text-white p-1 text-sm font-bold ml-2"
            >
              ✕
            </button>
          )}
        </div>
      </div>

      {/* Metronome Beat Center Stage */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
        {/* Visual Pulsing Heart Counter */}
        <div className="flex flex-col items-center justify-center p-6 bg-slate-950/80 rounded-2xl border border-slate-800 relative">
          <div className="relative flex items-center justify-center my-4">
            {/* Outer concentric pulsing ring */}
            <div className="w-36 h-36 rounded-full bg-rose-600/20 absolute animate-cpr-beat" />
            <div className="w-28 h-28 rounded-full bg-rose-700/30 absolute animate-ping" />
            
            {/* Center compression button representation */}
            <div className="w-24 h-24 rounded-full bg-gradient-to-tr from-rose-600 to-red-500 flex flex-col items-center justify-center shadow-lg shadow-rose-950 z-10 border-2 border-white/20">
              <Heart className="w-8 h-8 text-white fill-white animate-bounce" />
              <span className="text-[10px] font-black text-rose-100 tracking-wider">PUSH NOW</span>
            </div>
          </div>

          <div className="text-center mt-2">
            <div className="text-3xl font-black text-white tracking-tight">
              Compression #{compressionInCycle} <span className="text-slate-500 text-sm font-normal">/ 30</span>
            </div>
            <div className="text-xs text-rose-400 font-bold uppercase tracking-widest mt-1">
              Cycle #{cycleCount} • Push 2 inches (5cm) deep
            </div>
          </div>
        </div>

        {/* Life-Saving Action Instructions */}
        <div className="space-y-3">
          <div className="p-3 bg-slate-950/60 rounded-xl border border-slate-800 flex items-start space-x-3">
            <div className="p-1 rounded-full bg-rose-600/20 text-rose-400 shrink-0 mt-0.5">
              <CheckCircle2 className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-slate-100 uppercase tracking-wide">1. Hand Placement</h4>
              <p className="text-xs text-slate-300 mt-0.5">
                Place the heel of one hand in the center of the chest. Interlock the other hand on top. Keep elbows straight.
              </p>
            </div>
          </div>

          <div className="p-3 bg-slate-950/60 rounded-xl border border-slate-800 flex items-start space-x-3">
            <div className="p-1 rounded-full bg-rose-600/20 text-rose-400 shrink-0 mt-0.5">
              <CheckCircle2 className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-slate-100 uppercase tracking-wide">2. Rate & Recoil</h4>
              <p className="text-xs text-slate-300 mt-0.5">
                Compress firmly at this 110 BPM beep. Allow complete chest rise between each push. Do not stop until paramedics enter.
              </p>
            </div>
          </div>

          <div className="p-3 bg-slate-950/60 rounded-xl border border-slate-800 flex items-start space-x-3">
            <div className="p-1 rounded-full bg-amber-600/20 text-amber-400 shrink-0 mt-0.5">
              <AlertCircle className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-amber-300 uppercase tracking-wide">3. AED Voice Guidance</h4>
              <p className="text-xs text-slate-300 mt-0.5">
                If an Automated External Defibrillator (AED) is nearby, ask a bystander to bring it, turn on the power, and follow its spoken instructions.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
