import React, { useState, useEffect, useRef } from 'react';
import { 
  Heart, 
  Calendar, 
  MapPin, 
  Clock, 
  Phone, 
  Share2, 
  Mic, 
  AlertTriangle, 
  Sparkles, 
  ArrowRight, 
  Leaf,
  Building2, 
  CheckCircle2, 
  X, 
  Compass,
  Ambulance as AmbulanceIcon,
  Timer,
  Volume2,
  VolumeX,
  RotateCcw
} from 'lucide-react';
import { MapContainer, TileLayer, Marker, Popup, Polyline } from 'react-leaflet';
import L from 'leaflet';
import { useHealthEcosystem } from '../../store/healthEcosystemStore';
import { 
  supabase, 
  insertOpdToken, 
  insertEmergencySos 
} from '../../services/supabaseClient';

// ==========================================
// 🎵 CLEAN PREVIOUS NOTIFICATION SOUND (Classic Booking Confirmation Chime)
// ==========================================
function playSuccessDing() {
  try {
    const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();

    const triggerChime = () => {
      const now = ctx.currentTime;
      // High-clarity 4-note celebration chime (C5 -> E5 -> G5 -> C6)
      const notes = [
        { freq: 523.25, time: 0, dur: 0.22, vol: 0.45 },     // C5
        { freq: 659.25, time: 0.12, dur: 0.25, vol: 0.5 },   // E5
        { freq: 783.99, time: 0.24, dur: 0.3, vol: 0.55 },   // G5
        { freq: 1046.50, time: 0.38, dur: 0.7, vol: 0.65 },  // C6 (High Bell Finish)
      ];

      notes.forEach(({ freq, time, dur, vol }) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'triangle'; // Warm, crisp, and clearly audible through speakers
        osc.frequency.setValueAtTime(freq, now + time);
        gain.gain.setValueAtTime(vol, now + time);
        gain.gain.exponentialRampToValueAtTime(0.001, now + time + dur);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now + time);
        osc.stop(now + time + dur);
      });
    };

    if (ctx.state === 'suspended') {
      ctx.resume().then(triggerChime).catch(() => triggerChime());
    } else {
      triggerChime();
    }
  } catch (e) {
    console.warn('Audio chime error:', e);
  }
}

// ==========================================
// 🚨 AUTHENTIC 108 AMBULANCE SIREN SYNTHESIZER FOR PATIENT PORTAL
// ==========================================
function createSirenWavUri(): string {
  try {
    const sampleRate = 22050;
    const duration = 1.8;
    const numSamples = Math.floor(sampleRate * duration);
    const buffer = new ArrayBuffer(44 + numSamples);
    const view = new DataView(buffer);

    view.setUint32(0, 0x52494646, false); // "RIFF"
    view.setUint32(4, 36 + numSamples, true);
    view.setUint32(8, 0x57415645, false); // "WAVE"
    view.setUint32(12, 0x666d7420, false); // "fmt "
    view.setUint16(16, 16, true);
    view.setUint16(20, 1, true); // PCM
    view.setUint16(22, 1, true); // Mono
    view.setUint32(24, sampleRate, true);
    view.setUint32(28, sampleRate, true);
    view.setUint16(32, 1, true);
    view.setUint16(34, 8, true); // 8-bit
    view.setUint32(36, 0x64617461, false); // "data"
    view.setUint32(40, numSamples, true);

    const bytes = new Uint8Array(buffer, 44, numSamples);
    for (let i = 0; i < numSamples; i++) {
      const t = i / sampleRate;
      const cycle = Math.floor(t / 0.45) % 2;
      const freq = cycle === 0 ? 960 : 770;
      const phase = (t * freq) % 1;
      bytes[i] = phase < 0.5 ? 205 : 50;
    }

    let binary = '';
    const headerBytes = new Uint8Array(buffer, 0, 44);
    for (let i = 0; i < 44; i++) binary += String.fromCharCode(headerBytes[i]);
    for (let i = 0; i < numSamples; i++) binary += String.fromCharCode(bytes[i]);
    return 'data:audio/wav;base64,' + btoa(binary);
  } catch (e) {
    return '';
  }
}

class PatientAmbulanceSiren {
  private ctx: AudioContext | null = null;
  private osc: OscillatorNode | null = null;
  private gain: GainNode | null = null;
  private timer: number | null = null;
  private htmlAudio: HTMLAudioElement | null = null;
  public isPlaying: boolean = false;
  private wavUri: string = '';

  constructor() {
    this.wavUri = createSirenWavUri();
  }

  warmup() {
    try {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!this.ctx && AudioCtx) {
        this.ctx = new AudioCtx();
      }
      if (this.ctx && this.ctx.state === 'suspended') {
        this.ctx.resume().catch(() => {});
      }
    } catch (e) {}
  }

  start() {
    this.isPlaying = true;
    this.startWebAudio();
    this.startHtmlAudio();
  }

  private startWebAudio() {
    try {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) return;

      if (!this.ctx || this.ctx.state === 'closed') {
        this.ctx = new AudioCtx();
      }

      if (this.ctx.state === 'suspended') {
        this.ctx.resume().catch(() => {});
      }

      if (this.osc) {
        try { this.osc.stop(); this.osc.disconnect(); } catch (e) {}
        this.osc = null;
      }
      if (this.timer !== null) {
        clearInterval(this.timer);
        this.timer = null;
      }

      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const filter = this.ctx.createBiquadFilter();

      osc.type = 'sawtooth';
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(2400, this.ctx.currentTime);
      gain.gain.setValueAtTime(0.55, this.ctx.currentTime);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start();

      this.osc = osc;
      this.gain = gain;

      let isHigh = true;
      const switchTone = () => {
        if (!this.isPlaying || !this.ctx || !this.osc) return;
        const targetFreq = isHigh ? 960 : 770;
        this.osc.frequency.setTargetAtTime(targetFreq, this.ctx.currentTime, 0.03);
        isHigh = !isHigh;
      };

      switchTone();
      this.timer = window.setInterval(switchTone, 450);
    } catch (e) {
      console.warn('Patient WebAudio siren error:', e);
    }
  }

  private startHtmlAudio() {
    try {
      if (!this.htmlAudio) {
        this.htmlAudio = new Audio('/ambulance_siren.wav');
        this.htmlAudio.loop = true;
        this.htmlAudio.volume = 1.0;
      }
      this.htmlAudio.currentTime = 0;
      const p = this.htmlAudio.play();
      if (p && typeof p.catch === 'function') {
        p.catch(() => {
          try {
            if (this.wavUri) {
              const b64 = new Audio(this.wavUri);
              b64.loop = true;
              b64.volume = 1.0;
              b64.play().catch(() => {});
            }
          } catch (e) {}
        });
      }
    } catch (e) {}
  }

  stop() {
    this.isPlaying = false;
    if (this.timer !== null) {
      clearInterval(this.timer);
      this.timer = null;
    }
    if (this.gain && this.ctx) {
      try {
        this.gain.gain.setTargetAtTime(0.0001, this.ctx.currentTime, 0.03);
      } catch (e) {}
    }
    setTimeout(() => {
      try {
        this.osc?.stop();
        this.osc?.disconnect();
      } catch (e) {}
      this.osc = null;
      this.gain = null;
    }, 50);

    if (this.htmlAudio) {
      try {
        this.htmlAudio.pause();
        this.htmlAudio.currentTime = 0;
      } catch (e) {}
    }
  }
}

const patientSiren = new PatientAmbulanceSiren();

// 🎙️ Multilingual Medical Voice Intelligence & Clinical Symptom Enhancer
// Rapid prefix-matched: Catches words in under 150ms as user speaks!
function enhanceMedicalSpeech(rawText: string, _lang?: 'te-IN' | 'en-IN' | 'hi-IN'): string {
  const text = rawText.trim().toLowerCase();
  if (!text) return '';

  // 1. Road Accident / Severe Trauma
  // Instant prefix & phonetic catches: "acci", "axid", "ayind", "aind", "crash", "hit", "fall", "bike", etc.
  if (
    text.includes('acci') ||
    text.includes('axid') ||
    text.includes('ayind') ||
    text.includes('ayyind') ||
    text.includes('aind') ||
    text.includes('aipoin') ||
    text.includes('యాక్సి') ||
    text.includes('ప్రమాద') ||
    text.includes('ఎక్సి') ||
    text.includes('एक्सीडेंट') ||
    text.includes('हादसा') ||
    text.includes('crash') ||
    text.includes('hit') ||
    text.includes('dhee') ||
    text.includes('gudd') ||
    text.includes('fall') ||
    text.includes('bike') ||
    text.includes('vehicle') ||
    text.includes('trauma')
  ) {
    return 'Road Accident & Severe Trauma (Accident Ayyindi - Urgent Ambulance Requested)';
  }

  // 2. Chest Pain / Suspected Heart Attack / Cardiac STEMI
  // Instant prefix & phonetic catches: "gund", "nopp", "potu", "chest", "heart", "chati", "dard", "cardiac"
  if (
    text.includes('gund') ||
    text.includes('nopp') ||
    text.includes('potu') ||
    text.includes('chest') ||
    text.includes('heart') ||
    text.includes('chati') ||
    text.includes('గుండె') ||
    text.includes('ఛాతీ') ||
    text.includes('seene') ||
    text.includes('dard') ||
    text.includes('cardiac') ||
    text.includes('attack') ||
    text.includes('angina')
  ) {
    return 'Severe Acute Chest Pain & Suspected STEMI / Heart Attack (Gunde Noppi)';
  }

  // 3. Breathlessness / Asthma / Respiratory Failure
  // Instant prefix & phonetic catches: "aaya", "damm", "oopi", "swas", "breath", "asth", "saans"
  if (
    text.includes('aaya') ||
    text.includes('damm') ||
    text.includes('oopi') ||
    text.includes('swas') ||
    text.includes('ఆయా') ||
    text.includes('ఊపి') ||
    text.includes('శ్వా') ||
    text.includes('saans') ||
    text.includes('breath') ||
    text.includes('asthm') ||
    text.includes('gasp') ||
    text.includes('suffocat')
  ) {
    return 'Acute Respiratory Distress & Severe Breathlessness (Aayasam - High Oxygen Priority)';
  }

  // 4. Bleeding / Hemorrhage
  // Instant prefix & phonetic catches: "rakth", "bleed", "blood", "khoon", "karuth"
  if (
    text.includes('rakth') ||
    text.includes('blood') ||
    text.includes('bleed') ||
    text.includes('రక్తం') ||
    text.includes('khoon') ||
    text.includes('karuth') ||
    text.includes('cut')
  ) {
    return 'Severe External Hemorrhage & Active Bleeding (Emergency Pressure Bandage Needed)';
  }

  // 5. Stroke / Paralysis / Unconscious / Fainted
  // Instant prefix & phonetic catches: "strok", "paral", "spruh", "moothi", "lakwa", "behosh", "unconsc", "faint", "padip"
  if (
    text.includes('strok') ||
    text.includes('paral') ||
    text.includes('moothi') ||
    text.includes('spruh') ||
    text.includes('పక్ష') ||
    text.includes('స్పృ') ||
    text.includes('lakwa') ||
    text.includes('behosh') ||
    text.includes('unconsc') ||
    text.includes('faint') ||
    text.includes('padip') ||
    text.includes('collapse')
  ) {
    return 'Suspected Acute Stroke / FAST Positive (Altered Sensorium - Golden Hour Emergency)';
  }

  // 6. Bone Fracture / Orthopedic Trauma
  // Instant prefix catches: "virig", "fract", "kaalu", "cheyy", "emuk", "hadd", "bone"
  if (
    text.includes('virig') ||
    text.includes('fract') ||
    text.includes('kaalu') ||
    text.includes('cheyy') ||
    text.includes('విరి') ||
    text.includes('hadd') ||
    text.includes('bone') ||
    text.includes('leg') ||
    text.includes('hand')
  ) {
    return 'Compound Bone Fracture & Orthopedic Trauma (Splint Immobilization Required)';
  }

  // 7. Seizures / Fits / Convulsions
  if (
    text.includes('fit') ||
    text.includes('murch') ||
    text.includes('seiz') ||
    text.includes('convuls') ||
    text.includes('ఫిట్స్') ||
    text.includes('మూర్ఛ') ||
    text.includes('doure') ||
    text.includes('mirgi')
  ) {
    return 'Acute Epileptic Seizure & Convulsions (Airway Clearance Protocol)';
  }

  // 8. Snakebite / Toxic Ingestion / Poison
  if (
    text.includes('paam') ||
    text.includes('snak') ||
    text.includes('vish') ||
    text.includes('pois') ||
    text.includes('పాము') ||
    text.includes('విషం') ||
    text.includes('saamp') ||
    text.includes('zehar') ||
    text.includes('bite')
  ) {
    return 'Venomous Snakebite & Acute Toxicity (Immediate Anti-Venom Protocol)';
  }

  // 9. Thermal Burns / Fire
  if (
    text.includes('kaalip') ||
    text.includes('burn') ||
    text.includes('fire') ||
    text.includes('కాలి') ||
    text.includes('jal') ||
    text.includes('aag')
  ) {
    return 'Third-Degree Thermal Burn Injury (Sterile Dressing & Fluid Resus Bay)';
  }

  // 10. Maternity / Active Labor Pain
  if (
    text.includes('prasav') ||
    text.includes('deliv') ||
    text.includes('labor') ||
    text.includes('labour') ||
    text.includes('నొప్పు') ||
    text.includes('garbh') ||
    text.includes('pregnan')
  ) {
    return 'Active Labor Contractions & Obstetric Emergency (Immediate Maternity Bay)';
  }

  // 11. Stomach Pain / Gastric / Severe Vomiting
  if (
    text.includes('kadup') ||
    text.includes('stomach') ||
    text.includes('vomit') ||
    text.includes('pet dard') ||
    text.includes('gastric')
  ) {
    return 'Acute Severe Abdominal Distress & Gastric Emergency (Kadupu Noppi)';
  }

  // Fallback: If no emergency keyword matched, return cleaned capitalized speech
  const cleaned = rawText.trim();
  return cleaned.charAt(0).toUpperCase() + cleaned.slice(1);
}

class CPRPlayer {
  private interval: number | null = null;
  start(onBeat: (c: number) => void) {
    let count = 0;
    const tick = () => {
      try {
        const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        const ctx = new AudioCtx();
        ctx.resume().then(() => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = 'sine';
          osc.frequency.setValueAtTime(count % 30 === 0 ? 1046.5 : 850, ctx.currentTime);
          gain.gain.setValueAtTime(0.3, ctx.currentTime);
          gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.08);
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start();
          osc.stop(ctx.currentTime + 0.08);
          count++;
          onBeat(count);
        });
      } catch (e) {
        console.warn(e);
      }
    };
    tick();
    this.interval = window.setInterval(tick, (60 / 110) * 1000);
  }
  stop() {
    if (this.interval) {
      clearInterval(this.interval);
      this.interval = null;
    }
  }
}

const cprPlayer = new CPRPlayer();

// Leaflet map icons
const hospIcon = L.divIcon({
  className: 'custom-hosp',
  html: '<div class="w-8 h-8 rounded-xl bg-indigo-600 border-2 border-white flex items-center justify-center text-white text-xs shadow-lg font-bold">🏥</div>',
  iconSize: [32, 32],
  iconAnchor: [16, 16]
});

const patientIcon = L.divIcon({
  className: 'custom-pat',
  html: '<div class="w-8 h-8 rounded-full bg-rose-600 border-2 border-white flex items-center justify-center text-white text-xs shadow-lg animate-bounce font-bold">📍</div>',
  iconSize: [32, 32],
  iconAnchor: [16, 16]
});

const ambIcon = L.divIcon({
  className: 'custom-amb',
  html: '<div class="w-9 h-9 rounded-full bg-amber-500 border-2 border-white flex items-center justify-center text-white text-sm shadow-xl animate-pulse font-bold">🚑</div>',
  iconSize: [36, 36],
  iconAnchor: [18, 18]
});

const COMMON_OPD_SYMPTOMS = [
  { label: '🫀 Chest Pain / BP', dept: 'Cardiology (Heart Care)' },
  { label: '🦴 Knee / Joint Pain', dept: 'Orthopedics (Bone & Joint)' },
  { label: '🤒 High Fever & Chills', dept: 'General Medicine' },
  { label: '👶 Child Cough / Fever', dept: 'Pediatrics (Child Health)' },
  { label: '🧠 Severe Headache / Stroke', dept: 'Neurology (Brain & Spine)' },
  { label: '🤢 Stomach Ache / Acidity', dept: 'Gastroenterology' },
  { label: '🩺 Routine Full Checkup', dept: 'General Health' }
];

export const PatientPortal: React.FC = () => {
  const { actions } = useHealthEcosystem();
  const [activeTab, setActiveTab] = useState<'opd' | 'emergency'>('opd');

  // --- OPD FORM STATE ---
  const [patientName, setPatientName] = useState('');
  const [age, setAge] = useState('');
  const [gender, setGender] = useState('M');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [locationName, setLocationName] = useState('Detecting current GPS location...');
  const [userCoords, setUserCoords] = useState<{ lat: number; lng: number }>({ lat: 17.3850, lng: 78.4867 });
  const [hospital, setHospital] = useState('');
  const [medicalProblem, setMedicalProblem] = useState('');
  const [commuteTime, setCommuteTime] = useState('20');

  // Validation & Duplicate State
  const [phoneError, setPhoneError] = useState('');
  const [emailError, setEmailError] = useState('');
  const [symptomError, setSymptomError] = useState('');
  const [opdDuplicateError, setOpdDuplicateError] = useState('');
  const [sosPhoneError, setSosPhoneError] = useState('');
  const [sosDuplicateError, setSosDuplicateError] = useState('');

  // Real-time Queue Tracking (Sequential & Consistent)
  const [currentServingNumber, setCurrentServingNumber] = useState(104);
  const [nextTokenNumber, setNextTokenNumber] = useState(107);

  const [bookedPhones, setBookedPhones] = useState<string[]>([]);
  const [bookedEmails, setBookedEmails] = useState<string[]>([]);
  const [activeSosPhones, setActiveSosPhones] = useState<string[]>([]);

  // Confirmed Token & Modal
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [generatedToken, setGeneratedToken] = useState<any | null>(null);

  // --- EMERGENCY SOS STATE ---
  const [sosPhone, setSosPhone] = useState('');
  const [sosSymptom, setSosSymptom] = useState('');
  const [bloodGroup, setBloodGroup] = useState('O+');
  const [selectedSosHospitalId, setSelectedSosHospitalId] = useState('h1');
  const [isSosActive, setIsSosActive] = useState(false);
  const [isPatientSirenPlaying, setIsPatientSirenPlaying] = useState(false);
  const [sosEta, setSosEta] = useState(5);
  const [isCprRunning, setIsCprRunning] = useState(false);
  const [cprBeat, setCprBeat] = useState(0);
  const [isListeningVoice, setIsListeningVoice] = useState(false);
  const [voiceLang, setVoiceLang] = useState<'en-IN' | 'te-IN' | 'hi-IN'>('en-IN');
  const [interimSpokenText, setInterimSpokenText] = useState('');
  const [micError, setMicError] = useState('');
  const recognitionRef = useRef<any>(null);

  // 🏥 Emergency Patient Admitted Successfully Modal State (Admin Triggered)
  const [admissionAlert, setAdmissionAlert] = useState<{
    hospitalName: string;
    time: string;
    bed?: string;
    doctor?: string;
  } | null>(null);
  const lastAdmissionTimestampRef = useRef<number>(0);

  // 3-MINUTE AUTO-DISPATCH COUNTDOWN (Starts ONLY after user clicks Dispatch)
  const [isSelectingHospital, setIsSelectingHospital] = useState(false);
  const [autoDispatchSeconds, setAutoDispatchSeconds] = useState(180);
  const autoDispatchTimerRef = useRef<number | null>(null);

  // Surroundings Hospitals List
  const [nearbyHospitals, setNearbyHospitals] = useState<Array<{ id: string; name: string; distance: string; lat: number; lng: number; icu: number; address: string }>>([]);

  // Cross-Window Split Screen Broadcast Synchronization
  const [adminDelayNotice, setAdminDelayNotice] = useState<string>('');
  const liveBusRef = useRef<BroadcastChannel | null>(null);

  useEffect(() => {
    // Initial sync of current serving token and queue length from LocalStorage
    try {
      const savedServing = localStorage.getItem('sanjeevani_current_serving');
      if (savedServing) {
        const num = parseInt(savedServing.replace('SANJ-', '')) || 104;
        setCurrentServingNumber(num);
      }
      const savedQueue = localStorage.getItem('sanjeevani_unified_queue');
      if (savedQueue) {
        const parsed = JSON.parse(savedQueue);
        if (Array.isArray(parsed) && parsed.length > 0) {
          const maxNum = parsed.reduce((max: number, p: any) => {
            const n = parseInt(p.token?.replace('SANJ-', '')) || 100;
            return n > max ? n : max;
          }, 106);
          setNextTokenNumber(maxNum + 1);
        }
      }
    } catch (e) {}

    try {
      const bus = new BroadcastChannel('sanjeevani_live_bus');
      liveBusRef.current = bus;

      bus.onmessage = (e) => {
        if (e.data?.type === 'CALL_NEXT' && e.data.payload) {
          const num = e.data.payload.tokenNumberInt;
          if (num) {
            setCurrentServingNumber(num);
            setGeneratedToken((prev: any) => {
              if (!prev) return prev;
              const assignedNum = parseInt(prev.tokenNumber.replace('SANJ-', '')) || 107;
              const newPeopleAhead = Math.max(0, assignedNum - num);
              return {
                ...prev,
                currentlyServing: `SANJ-${num}`,
                peopleAhead: newPeopleAhead
              };
            });
            playSuccessDing();
          }
        }
        if (e.data?.type === 'BROADCAST_DELAY' && e.data.payload) {
          setAdminDelayNotice(`🔔 Doctor Notice: Clinic delayed by +${e.data.payload.delayMins} mins. Dynamic pacing updated!`);
          setTimeout(() => setAdminDelayNotice(''), 8000);
        }
        if (e.data?.type === 'SOS_RESOLVED') {
          patientSiren.stop();
          setIsPatientSirenPlaying(false);
          setIsSosActive(false);
          setIsSelectingHospital(false);
          setSosEta(0);
          if (e.data.payload) {
            setAdmissionAlert({
              hospitalName: e.data.payload.hospitalName || 'Apollo Trauma & Heart Institute',
              time: e.data.payload.time || new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
              bed: e.data.payload.bed || 'Trauma Bay #2 (Reserved)',
              doctor: e.data.payload.doctor || 'Dr. Sudhir Rao, MD (Trauma In-Charge)'
            });
            playSuccessDing();
          }
        }
      };
    } catch (err) {
      console.warn('BroadcastChannel error:', err);
    }

    // Storage Event Listener (Guaranteed cross-tab fallback)
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === 'sanjeevani_current_serving' && e.newValue) {
        const num = parseInt(e.newValue.replace('SANJ-', '')) || 104;
        setCurrentServingNumber(num);
        setGeneratedToken((prev: any) => {
          if (!prev) return prev;
          const assignedNum = parseInt(prev.tokenNumber.replace('SANJ-', '')) || 107;
          const newPeopleAhead = Math.max(0, assignedNum - num);
          return {
            ...prev,
            currentlyServing: `SANJ-${num}`,
            peopleAhead: newPeopleAhead
          };
        });
        playSuccessDing();
      }
      if (e.key === 'sanjeevani_patient_admitted_alert' && e.newValue) {
        try {
          const parsed = JSON.parse(e.newValue);
          if (parsed) {
            patientSiren.stop();
            setIsPatientSirenPlaying(false);
            setIsSosActive(false);
            setIsSelectingHospital(false);
            setSosEta(0);
            setAdmissionAlert(parsed);
            playSuccessDing();
          }
        } catch (err) {}
      }
      if (e.key === 'sanjeevani_active_sos' && !e.newValue) {
        patientSiren.stop();
        setIsPatientSirenPlaying(false);
        setIsSosActive(false);
        setIsSelectingHospital(false);
      }
    };

    window.addEventListener('storage', handleStorageChange);

    // ⚡ 500ms FAST STORAGE POLLING: Guaranteed live update for current serving token
    const pollInterval = window.setInterval(() => {
      try {
        const savedServing = localStorage.getItem('sanjeevani_current_serving');
        if (savedServing) {
          const num = parseInt(savedServing.replace('SANJ-', '')) || 104;
          setCurrentServingNumber(prev => {
            if (prev !== num) {
              setGeneratedToken((tPrev: any) => {
                if (!tPrev) return tPrev;
                const assignedNum = parseInt(tPrev.tokenNumber?.replace('SANJ-', '')) || 107;
                const newPeopleAhead = Math.max(0, assignedNum - num);
                return {
                  ...tPrev,
                  currentlyServing: `SANJ-${num}`,
                  peopleAhead: newPeopleAhead
                };
              });
              playSuccessDing();
              return num;
            }
            return prev;
          });
        }
      } catch (e) {}

      // Sync Patient Admitted Alert (Triggered when Admin marks Patient Received / Admitted)
      try {
        const admittedRaw = localStorage.getItem('sanjeevani_patient_admitted_alert');
        if (admittedRaw) {
          const parsed = JSON.parse(admittedRaw);
          const ts = parsed?.timestamp || 0;
          if (ts > lastAdmissionTimestampRef.current && (Date.now() - ts) < 300000) {
            lastAdmissionTimestampRef.current = ts;
            patientSiren.stop();
            setIsPatientSirenPlaying(false);
            setIsSosActive(false);
            setIsSelectingHospital(false);
            setSosEta(0);
            setAdmissionAlert(parsed);
            playSuccessDing();
          }
        }
      } catch (e) {}
    }, 500);

    // ⚡ Supabase Cloud Realtime WebSockets Listener
    const patientChannel = supabase
      .channel('patient-portal-realtime')
      .on(
        'postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'opd_tokens' },
        (payload) => {
          const updated = payload.new as any;
          if (updated && updated.status === 'In Consultation') {
            const num = parseInt(updated.token_number?.replace('SANJ-', '')) || 104;
            setCurrentServingNumber(num);
            setGeneratedToken((prev: any) => {
              if (!prev) return prev;
              const assignedNum = parseInt(prev.tokenNumber?.replace('SANJ-', '')) || 107;
              const newPeopleAhead = Math.max(0, assignedNum - num);
              return {
                ...prev,
                currentlyServing: `SANJ-${num}`,
                peopleAhead: newPeopleAhead
              };
            });
            playSuccessDing();
          }
        }
      )
      .subscribe();

    return () => {
      liveBusRef.current?.close();
      supabase.removeChannel(patientChannel);
      window.removeEventListener('storage', handleStorageChange);
      window.clearInterval(pollInterval);
      patientSiren.stop();
    };
  }, []);

  // Auto-detect real device location and sync
  useEffect(() => {
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const lat = pos.coords.latitude;
          const lng = pos.coords.longitude;
          setUserCoords({ lat, lng });
          setLocationName(`GPS Area: Lat ${lat.toFixed(3)}, Lng ${lng.toFixed(3)}`);

          const list = [
            { id: 'h1', name: 'Apollo Trauma & Heart Institute (Zone 1)', distance: '1.8 km', lat: lat + 0.008, lng: lng + 0.006, icu: 3, address: 'Zone 1, Central Health Corridor' },
            { id: 'h2', name: 'City Care Trauma & Stroke Institute (Sector 4)', distance: '2.5 km', lat: lat - 0.009, lng: lng + 0.012, icu: 2, address: 'Sector 4, Metro West Corridor' },
            { id: 'h3', name: 'Fortis Pediatric & ER (Hub 9)', distance: '3.9 km', lat: lat + 0.015, lng: lng - 0.008, icu: 4, address: 'Hub 9, South Park Avenue' },
            { id: 'h4', name: 'Metro General Regional Hospital (Block C)', distance: '4.7 km', lat: lat - 0.012, lng: lng - 0.015, icu: 1, address: 'Block C, East Ring Road' }
          ];
          setNearbyHospitals(list);
          setHospital(list[0].name);
          setSelectedSosHospitalId(list[0].id);
        },
        () => {
          // Fallback coords (Metro area)
          const fallbackLat = 17.3850;
          const fallbackLng = 78.4867;
          setLocationName('Metro City Center (GPS Default)');
          const list = [
            { id: 'h1', name: 'Apollo Trauma & Heart Institute (Zone 1)', distance: '1.8 km', lat: fallbackLat + 0.01, lng: fallbackLng + 0.01, icu: 3, address: 'Zone 1, Central Health Corridor' },
            { id: 'h2', name: 'City Care Trauma & Stroke Institute (Sector 4)', distance: '2.5 km', lat: fallbackLat - 0.01, lng: fallbackLng + 0.015, icu: 2, address: 'Sector 4, Metro West Corridor' },
            { id: 'h3', name: 'Fortis Pediatric & ER (Hub 9)', distance: '3.9 km', lat: fallbackLat + 0.018, lng: fallbackLng - 0.01, icu: 4, address: 'Hub 9, South Park Avenue' }
          ];
          setNearbyHospitals(list);
          setHospital(list[0].name);
          setSelectedSosHospitalId(list[0].id);
        }
      );
    }
  }, []);

  // 3-Minute Hospital Selection Countdown (Runs ONLY after user clicks Dispatch Emergency SOS)
  useEffect(() => {
    if (isSelectingHospital && !isSosActive) {
      autoDispatchTimerRef.current = window.setInterval(() => {
        setAutoDispatchSeconds((prev) => {
          if (prev <= 1) {
            // 3 minutes expired! Auto-lock to #1 nearest hospital!
            if (autoDispatchTimerRef.current) clearInterval(autoDispatchTimerRef.current);
            const defaultHosp = nearbyHospitals[0];
            confirmEmergencyDispatch(defaultHosp ? defaultHosp.id : 'h1', true);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      if (autoDispatchTimerRef.current) clearInterval(autoDispatchTimerRef.current);
    }
    return () => {
      if (autoDispatchTimerRef.current) clearInterval(autoDispatchTimerRef.current);
    };
  }, [isSelectingHospital, isSosActive, nearbyHospitals]);

  // Confirm Dispatch helper (called when user clicks hospital OR when 3-min timer expires)
  const confirmEmergencyDispatch = (hospId: string, isAutoDefault = false) => {
    if (autoDispatchTimerRef.current) clearInterval(autoDispatchTimerRef.current);
    setSelectedSosHospitalId(hospId);
    setIsSelectingHospital(false);
    setIsSosActive(true);
    setSosEta(5);
    setActiveSosPhones(prev => [...prev, sosPhone.trim() || 'Emergency-Contact']);
    playSuccessDing();

    // 🚨 BLARE 108 AMBULANCE SIREN IMMEDIATELY ON BOOKING CONFIRMATION!
    patientSiren.warmup();
    patientSiren.start();
    setIsPatientSirenPlaying(true);

    // Broadcast SOS event across windows to Admin Portal with FULL patient details and GPS coordinates
    try {
      const selectedHosp = nearbyHospitals.find(h => h.id === hospId) || nearbyHospitals[0];
      const hCoords = {
        lat: selectedHosp?.lat || (userCoords.lat + 0.008),
        lng: selectedHosp?.lng || (userCoords.lng + 0.006)
      };
      const sosData = {
        active: true,
        phone: sosPhone.trim() || '+91 98450-23491',
        symptom: sosSymptom.trim() || 'Acute STEMI / Severe Emergency',
        location: locationName,
        coords: userCoords,
        bloodGroup: bloodGroup,
        hospitalName: selectedHosp?.name || 'Apollo Trauma & Heart Institute (Zone 1)',
        hospitalId: hospId,
        hospitalCoords: hCoords,
        hospitalAddress: selectedHosp?.address || 'Zone 1, Central Health Corridor',
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        timestamp: Date.now()
      };
      localStorage.setItem('sanjeevani_active_sos', JSON.stringify(sosData));
      localStorage.setItem('sanjeevani_sos_ping', String(Date.now()));
      liveBusRef.current?.postMessage({
        type: 'SOS_DISPATCHED',
        payload: sosData
      });

      // ⚡ Direct Insert to Supabase Cloud Database
      insertEmergencySos({
        phone: sosData.phone,
        symptoms: sosData.symptom,
        blood_group: bloodGroup,
        location: locationName,
        hospital_name: sosData.hospitalName,
        status: 'Ambulance Dispatched'
      });
    } catch (e) {}
  };

  // Strict Phone Validation (No 0 start, 10 digits)
  const validatePhone = (num: string) => {
    const cleaned = num.trim();
    if (cleaned.startsWith('0')) {
      return { valid: false, message: 'Mobile number cannot start with 0! Must start with 6, 7, 8, or 9.' };
    }
    if (!/^[6-9]\d{9}$/.test(cleaned)) {
      return { valid: false, message: 'Must be exactly 10 digits starting with 6, 7, 8, or 9.' };
    }
    return { valid: true, message: '' };
  };

  const validateEmail = (mail: string) => {
    if (!mail.trim()) return { valid: true, message: '' };
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(mail.trim())) {
      return { valid: false, message: 'Please enter a valid email format (e.g. name@gmail.com)!' };
    }
    return { valid: true, message: '' };
  };

  const getAutoDepartment = (problem: string) => {
    const p = problem.toLowerCase();
    if (p.includes('heart') || p.includes('chest') || p.includes('gunde') || p.includes('bp')) return 'Cardiology (Heart Care)';
    if (p.includes('bone') || p.includes('knee') || p.includes('joint') || p.includes('fracture') || p.includes('kaalu')) return 'Orthopedics (Bone & Joint)';
    if (p.includes('baby') || p.includes('child') || p.includes('pillalu')) return 'Pediatrics (Child Health)';
    if (p.includes('brain') || p.includes('head') || p.includes('stroke') || p.includes('nerve')) return 'Neurology (Brain & Spine)';
    if (p.includes('stomach') || p.includes('gastric') || p.includes('vomit')) return 'Gastroenterology';
    return 'General Internal Medicine';
  };

  // Multilingual Web Speech API (Telugu / English / Hindi with Smart Medical AI Enhancement)
  const stopVoiceMic = () => {
    if (recognitionRef.current) {
      try {
        recognitionRef.current.onresult = null;
        recognitionRef.current.onerror = null;
        recognitionRef.current.onend = null;
        recognitionRef.current.stop();
      } catch (e) {}
      recognitionRef.current = null;
    }
    setIsListeningVoice(false);
  };

  const startVoiceMic = (targetLanguage?: 'te-IN' | 'en-IN' | 'hi-IN') => {
    const chosenLang = targetLanguage || voiceLang;
    setMicError('');
    setInterimSpokenText('');

    // Toggle off if currently listening
    if (isListeningVoice) {
      stopVoiceMic();
      return;
    }

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      setMicError('Speech Recognition is not supported by your browser. Please use Microsoft Edge or Chrome, or tap the 1-tap quick buttons below.');
      return;
    }

    // Stop any previous dangling instance
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch (e) {}
      recognitionRef.current = null;
    }

    try {
      const recognition = new SpeechRecognition();
      recognitionRef.current = recognition;
      recognition.lang = chosenLang;
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.maxAlternatives = 1; // ⚡ Ultra-fast single hypothesis emission (eliminates beam search lag)

      // ⚡ Zero-lag UI responsiveness: Activate listening state immediately
      setIsListeningVoice(true);
      setMicError('');

      recognition.onstart = () => {
        setIsListeningVoice(true);
        setMicError('');
      };

      recognition.onresult = (event: any) => {
        let interimTranscript = '';
        let finalTranscript = '';

        for (let i = 0; i < event.results.length; i++) {
          const item = event.results[i];
          if (item[0]?.transcript) {
            if (item.isFinal) {
              finalTranscript += item[0].transcript + ' ';
            } else {
              interimTranscript += item[0].transcript;
            }
          }
        }

        const rawSpoken = (finalTranscript + interimTranscript).trim();
        if (rawSpoken) {
          setInterimSpokenText(rawSpoken);
          const enhanced = enhanceMedicalSpeech(rawSpoken, chosenLang);
          setSosSymptom(enhanced);
        }
      };

      recognition.onerror = (err: any) => {
        console.warn('Speech Recognition error event:', err?.error, err);
        const errType = err?.error || '';

        if (errType === 'no-speech') {
          // Normal silence, keep listening
          return;
        }

        if (errType === 'not-allowed' || errType === 'service-not-allowed') {
          setMicError('⚠️ Microphone access blocked! Please click the Lock 🔒 or Camera icon in your browser URL bar and click "Allow Microphone".');
          stopVoiceMic();
        } else if (errType === 'language-not-supported') {
          setMicError(`Language pack for ${chosenLang} not installed in browser. Switched to Indian English (recognizes Telugu/Hindi terms).`);
          setVoiceLang('en-IN');
          stopVoiceMic();
          setTimeout(() => startVoiceMic('en-IN'), 300);
        } else if (errType === 'audio-capture') {
          setMicError('⚠️ No microphone hardware detected or mic is muted in Windows sound settings.');
          stopVoiceMic();
        } else if (errType === 'network') {
          setMicError('⚠️ Speech recognition network timeout. Please tap the 1-tap quick buttons below.');
          stopVoiceMic();
        } else {
          stopVoiceMic();
        }
      };

      recognition.onend = () => {
        setIsListeningVoice(false);
      };

      recognition.start();
    } catch (e: any) {
      console.warn('startVoiceMic exception:', e);
      setIsListeningVoice(false);
      setMicError('Could not start microphone. Please check browser permissions or select a quick condition below.');
    }
  };

  // Handle OPD Submit (Uses REAL-TIME current clock & Sequential Queue)
  const handleBookToken = (e: React.FormEvent) => {
    e.preventDefault();
    setPhoneError('');
    setEmailError('');
    setSymptomError('');
    setOpdDuplicateError('');

    const phoneVal = validatePhone(phone);
    if (!phoneVal.valid) {
      setPhoneError(phoneVal.message);
      return;
    }

    const emailVal = validateEmail(email);
    if (!emailVal.valid) {
      setEmailError(emailVal.message);
      return;
    }

    // MANDATORY SYMPTOM VALIDATION
    if (!medicalProblem.trim()) {
      setSymptomError('⚠️ Please select or type your medical symptoms/problem! (Required)');
      return;
    }

    if (bookedPhones.includes(phone.trim()) || (email.trim() && bookedEmails.includes(email.trim()))) {
      setOpdDuplicateError(`⚠️ Already Booked! An active OPD token is already booked with this mobile number (${phone}). Please check your active token below.`);
      return;
    }

    playSuccessDing();

    // REAL-TIME CURRENT TIME CLOCK & ACCURATE QUEUE NUMBER
    const now = new Date();
    const bookingTimeString = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    
    const assignedTokenNum = nextTokenNumber;
    const currentServingNum = currentServingNumber;
    const peopleAheadCount = Math.max(1, assignedTokenNum - currentServingNum);
    const tokenNum = `SANJ-${assignedTokenNum}`;
    const currentlyServingStr = `SANJ-${currentServingNum}`;
    
    // Advance token counter for next booking
    setNextTokenNumber(prev => prev + 1);

    // Each person ahead takes ~12-15 mins
    const waitMins = peopleAheadCount * 15;
    const consultTime = new Date(now.getTime() + waitMins * 60000);
    const leaveTime = new Date(consultTime.getTime() - parseInt(commuteTime) * 60000);

    const tokenData = {
      tokenNumber: tokenNum,
      name: patientName,
      age: age || '42',
      gender,
      phone,
      email,
      hospital: hospital || nearbyHospitals[0]?.name,
      department: getAutoDepartment(medicalProblem),
      problem: medicalProblem,
      currentlyServing: currentlyServingStr,
      peopleAhead: peopleAheadCount,
      bookingTime: bookingTimeString,
      consultationTime: consultTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      leaveHomeTime: leaveTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      commuteMinutes: commuteTime
    };

    setGeneratedToken(tokenData);
    setBookedPhones(prev => [...prev, phone.trim()]);
    if (email.trim()) setBookedEmails(prev => [...prev, email.trim()]);
    setShowSuccessModal(true);

    const newEntry = {
      token: tokenNum,
      name: patientName,
      age: age || '42',
      gender,
      problem: medicalProblem,
      department: tokenData.department || 'Cardiology (Heart Care)',
      hospital: tokenData.hospital || nearbyHospitals[0]?.name || 'Apollo Trauma & Heart Institute (Zone 1)',
      phone,
      email,
      source: 'online' as const,
      status: 'Safe at Home (Pacing)' as const,
      etaOrArriveTime: `Leave home at ${tokenData.leaveHomeTime} (${commuteTime}m transit)`,
      consultationTime: tokenData.consultationTime,
      leaveHomeTime: tokenData.leaveHomeTime,
      bookingTime: tokenData.bookingTime
    };

    // Persist to unified queue in LocalStorage
    try {
      const existingQueueStr = localStorage.getItem('sanjeevani_unified_queue');
      let currentQueue = existingQueueStr ? JSON.parse(existingQueueStr) : [
        {
          token: 'SANJ-104',
          name: 'Kavita Menon',
          age: 48,
          gender: 'F',
          problem: 'Heart Palpitations & High Pulse',
          department: 'Cardiology (Heart Care)',
          phone: '+91 98450-12841',
          source: 'online',
          status: 'In Consultation',
          etaOrArriveTime: 'Currently with Doctor (Room 204)'
        },
        {
          token: 'SANJ-105',
          name: 'Arjun Das',
          age: 62,
          gender: 'M',
          problem: 'Post-CABG Blood Pressure Review',
          department: 'Cardiology (Heart Care)',
          phone: '+91 97110-33421',
          source: 'offline_kiosk',
          status: 'In Waiting Lobby',
          etaOrArriveTime: 'Arrived at Counter (Lobby Seat #4)'
        },
        {
          token: 'SANJ-106',
          name: 'Pooja Iyer',
          age: 39,
          gender: 'F',
          problem: 'Chest Discomfort & Acidity Check',
          department: 'Cardiology (Heart Care)',
          phone: '+91 94480-87612',
          source: 'online',
          status: 'Safe at Home (Pacing)',
          etaOrArriveTime: 'Leave Home at 10:45 AM (15m transit)'
        }
      ];

      currentQueue = [...currentQueue, newEntry];
      localStorage.setItem('sanjeevani_unified_queue', JSON.stringify(currentQueue));
      localStorage.setItem('sanjeevani_latest_booking', JSON.stringify(newEntry));
    } catch (e) {
      console.warn('Queue storage error:', e);
    }

    // Broadcast booking event to Admin Portal via liveBusRef
    try {
      const broadcastPayload = {
        ...tokenData,
        ...newEntry,
        token: tokenNum,
        tokenNumber: tokenNum
      };
      liveBusRef.current?.postMessage({
        type: 'PATIENT_BOOKED',
        payload: broadcastPayload
      });
    } catch (e) {}

    // ⚡ Direct Insert to Supabase Cloud Database (Live Cross-Device Sync)
    insertOpdToken({
      token_number: tokenNum,
      patient_name: patientName,
      age: age || '42',
      gender,
      phone,
      email,
      problem: medicalProblem,
      department: tokenData.department || 'Cardiology (Heart Care)',
      hospital: tokenData.hospital || 'Apollo Trauma & Heart Institute (Zone 1)',
      status: 'Safe at Home (Pacing)',
      leave_home_time: tokenData.leaveHomeTime,
      consultation_time: tokenData.consultationTime
    });
  };

  // Handle SOS Trigger: User clicks "DISPATCH EMERGENCY SOS"
  const handleTriggerSOS = () => {
    setSosPhoneError('');
    setSosDuplicateError('');

    const phoneVal = validatePhone(sosPhone);
    if (!phoneVal.valid) {
      setSosPhoneError(phoneVal.message);
      return;
    }

    // 🏥 Open Hospital Selector with 2-Minute (120s) Auto-Booking Timer!
    setAutoDispatchSeconds(120); // 2 minutes auto-booking countdown
    setIsSelectingHospital(true);
  };

  // Toggle CPR Metronome
  const toggleCPR = () => {
    if (isCprRunning) {
      cprPlayer.stop();
      setIsCprRunning(false);
    } else {
      cprPlayer.start((c) => setCprBeat(c));
      setIsCprRunning(true);
    }
  };

  useEffect(() => {
    return () => {
      cprPlayer.stop();
      stopVoiceMic();
    };
  }, []);

  const assignedHospital = nearbyHospitals.find(h => h.id === selectedSosHospitalId) || nearbyHospitals[0] || {
    id: 'h1',
    name: 'Apollo Emergency & Multi-Speciality',
    distance: '1.8 km',
    lat: userCoords.lat + 0.008,
    lng: userCoords.lng + 0.006,
    icu: 3,
    address: 'Main Ring Road, Health Hub 1'
  };

  const formatTimer = (s: number) => {
    const mins = Math.floor(s / 60);
    const secs = s % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-12">
      {/* 🌿 BRAND HEADER WITH HOSPITAL + SANJEEVANI LEAF ICON */}
      <div className="p-6 rounded-3xl bg-slate-900/60 backdrop-blur-xl border border-slate-800 shadow-2xl flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center space-x-4">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-emerald-500 via-teal-500 to-indigo-600 p-0.5 shadow-lg shadow-emerald-950/40 flex items-center justify-center">
            <div className="w-full h-full bg-slate-950/90 rounded-2xl flex items-center justify-center relative backdrop-blur-sm">
              <Building2 className="w-7 h-7 text-white" />
              <Leaf className="w-4 h-4 text-emerald-400 absolute -top-1 -right-1 fill-emerald-400 animate-pulse" />
            </div>
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h1 className="text-2xl font-black text-white tracking-tight">
                Sanjeevani <span className="text-emerald-400 font-extrabold">AI</span>
              </h1>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-950 text-emerald-300 border border-emerald-700">
                PATIENT PORTAL
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">Smart Hospital Queue & Rapid Emergency Life-Line</p>
          </div>
        </div>

        {/* Live GPS Area Badge */}
        <div className="flex items-center space-x-2 px-3.5 py-2 rounded-xl bg-slate-950/80 border border-slate-800 text-xs text-slate-300">
          <MapPin className="w-4 h-4 text-rose-500 shrink-0 animate-pulse" />
          <span className="truncate max-w-[220px] font-medium">{locationName}</span>
        </div>
      </div>

      {/* ⚠️ REAL-TIME DOCTOR DELAY BROADCAST BANNER */}
      {adminDelayNotice && (
        <div className="p-4 rounded-2xl bg-amber-950/80 border-2 border-amber-500 text-amber-200 text-xs font-bold shadow-lg shadow-amber-950/50 flex items-center justify-between animate-bounce">
          <div className="flex items-center space-x-2">
            <span className="text-base">📢</span>
            <span>{adminDelayNotice}</span>
          </div>
          <span className="text-[10px] text-amber-400 uppercase tracking-wider font-mono">PUSHED FROM DOCTOR DESK</span>
        </div>
      )}

      {/* 🔄 TAB SWITCHER */}
      <div className="grid grid-cols-2 p-1.5 rounded-2xl bg-slate-900/80 backdrop-blur-lg border border-slate-800">
        <button
          onClick={() => setActiveTab('opd')}
          className={`py-3.5 rounded-xl font-bold text-xs sm:text-sm flex items-center justify-center space-x-2 transition-all ${
            activeTab === 'opd'
              ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-lg shadow-emerald-950'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Calendar className="w-4 h-4" />
          <span>📅 Smart OPD Queue</span>
        </button>

        <button
          onClick={() => setActiveTab('emergency')}
          className={`py-3.5 rounded-xl font-bold text-xs sm:text-sm flex items-center justify-center space-x-2 transition-all ${
            activeTab === 'emergency'
              ? 'bg-gradient-to-r from-rose-600 to-red-600 text-white shadow-lg shadow-rose-950'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <AlertTriangle className="w-4 h-4" />
          <span>🚨 Emergency SOS & Ambulance</span>
        </button>
      </div>

      {/* ========================================================================= */}
      {/* 🌟 CONFIRMED SUCCESSFULLY RIGHT-TICK POPUP MODAL                          */}
      {/* ========================================================================= */}
      {showSuccessModal && generatedToken && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-in fade-in">
          <div className="bg-slate-900 border-2 border-emerald-500 rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl shadow-emerald-950 text-center space-y-4 relative">
            <button 
              onClick={() => setShowSuccessModal(false)}
              className="absolute right-4 top-4 text-slate-400 hover:text-white p-1"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="w-20 h-20 rounded-full bg-emerald-500/20 border-2 border-emerald-400 flex items-center justify-center mx-auto shadow-lg shadow-emerald-950 animate-bounce">
              <CheckCircle2 className="w-12 h-12 text-emerald-400" />
            </div>

            <div>
              <span className="px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                CONFIRMED SUCCESSFULLY! ✅
              </span>
              <h3 className="text-2xl font-black text-white mt-2">
                Token #{generatedToken.tokenNumber}
              </h3>
              <p className="text-xs text-emerald-400 font-bold mt-0.5">
                (OPD Queue Pass • Doctor Turn Number)
              </p>
              <p className="text-[11px] text-slate-400 mt-1">
                {generatedToken.hospital} • {generatedToken.department}
              </p>
              <button
                type="button"
                onClick={() => playSuccessDing()}
                className="mt-2.5 px-3 py-1.5 rounded-xl bg-slate-950 border border-emerald-500/40 hover:border-emerald-400 text-emerald-300 text-xs font-bold inline-flex items-center space-x-1.5 transition shadow-sm"
              >
                <Volume2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Replay Confirmation Chime 🔔</span>
              </button>
            </div>

            <div className="p-3.5 bg-slate-950/80 rounded-2xl border border-slate-800 text-left text-xs space-y-1.5">
              <div className="flex justify-between">
                <span className="text-slate-400">Patient Name:</span>
                <span className="font-bold text-white">{generatedToken.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Actual Booking Time:</span>
                <span className="font-bold text-slate-200">{generatedToken.bookingTime}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Estimated Turn:</span>
                <span className="font-bold text-emerald-400">{generatedToken.consultationTime}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Recommended Leave Time:</span>
                <span className="font-bold text-emerald-300">{generatedToken.leaveHomeTime}</span>
              </div>
            </div>

            <button
              onClick={() => setShowSuccessModal(false)}
              className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-sm transition shadow-lg shadow-emerald-950"
            >
              View My Live Token Screen
            </button>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 🏥 EMERGENCY PATIENT ADMITTED SUCCESSFULLY POPUP MODAL                     */}
      {/* Triggered when Admin marks Patient Received / Admitted in Trauma ER Desk */}
      {/* ========================================================================= */}
      {admissionAlert && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 animate-in fade-in">
          <div className="bg-slate-900 border-4 border-emerald-500 rounded-3xl p-6 sm:p-8 max-w-lg w-full shadow-[0_0_70px_rgba(16,185,129,0.5)] text-center space-y-5 relative">
            <button 
              type="button"
              onClick={() => {
                setAdmissionAlert(null);
                try { localStorage.removeItem('sanjeevani_patient_admitted_alert'); } catch(e) {}
              }}
              className="absolute right-4 top-4 text-slate-400 hover:text-white p-1 rounded-full hover:bg-slate-800 transition"
            >
              <X className="w-6 h-6" />
            </button>

            {/* Glowing Icon */}
            <div className="relative w-24 h-24 mx-auto flex items-center justify-center">
              <div className="absolute inset-0 rounded-full bg-emerald-500/20 animate-ping"></div>
              <div className="w-20 h-20 rounded-3xl bg-gradient-to-tr from-emerald-600 via-teal-600 to-emerald-500 border-2 border-white flex items-center justify-center text-4xl shadow-xl shadow-emerald-950 text-white animate-bounce">
                🏥
              </div>
            </div>

            <div>
              <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-emerald-950 border border-emerald-500 text-xs font-black text-emerald-300 uppercase tracking-widest animate-pulse">
                <span>✅ EMERGENCY CARE INITIATED • PATIENT SAFELY ADMITTED</span>
              </div>
              <h3 className="text-2xl sm:text-3xl font-black text-white mt-2">
                Admitted Successfully!
              </h3>
              <p className="text-xs text-emerald-300 font-bold mt-1">
                Your emergency ambulance arrived safely and the hospital ER trauma team has taken charge!
              </p>
            </div>

            {/* Hospital Admission Dossier Card */}
            <div className="p-4 rounded-2xl bg-slate-950 border border-emerald-700/60 text-left space-y-2.5 text-xs">
              <div className="flex justify-between border-b border-slate-800 pb-2">
                <span className="text-slate-400 font-bold">Destination Hospital:</span>
                <span className="font-bold text-white text-sm truncate max-w-[220px]">
                  {admissionAlert.hospitalName}
                </span>
              </div>
              <div className="flex justify-between border-b border-slate-800 pb-2">
                <span className="text-slate-400 font-bold">Assigned Emergency Bay:</span>
                <span className="font-black text-emerald-400">{admissionAlert.bed || 'Trauma Bay #2 (Reserved & Locked)'}</span>
              </div>
              <div className="flex justify-between border-b border-slate-800 pb-2">
                <span className="text-slate-400 font-bold">Attending Specialist:</span>
                <span className="font-bold text-slate-200">{admissionAlert.doctor || 'Dr. Sudhir Rao, MD (Trauma In-Charge)'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400 font-bold">Admission Recorded Time:</span>
                <span className="font-mono font-bold text-cyan-300">{admissionAlert.time}</span>
              </div>
            </div>

            {/* Reassurance Banner */}
            <div className="p-3 rounded-2xl bg-emerald-950/40 border border-emerald-800 text-[11px] text-emerald-200 text-center">
              The on-duty critical care specialists have begun clinical stabilization protocols. <strong>You are in safe hands.</strong>
            </div>

            {/* Big Action Button */}
            <button
              type="button"
              onClick={() => {
                setAdmissionAlert(null);
                try { localStorage.removeItem('sanjeevani_patient_admitted_alert'); } catch(e) {}
              }}
              className="w-full py-4 bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-500 hover:from-emerald-500 hover:to-teal-400 text-white font-black rounded-2xl text-base transition flex items-center justify-center space-x-2 shadow-2xl shadow-emerald-950 border-2 border-emerald-400 transform active:scale-95"
            >
              <CheckCircle2 className="w-5 h-5 text-white" />
              <span>✅ Acknowledge & Close (Admitted Successfully)</span>
            </button>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 📅 TAB 1: SMART OPD QUEUE BOOKING                                         */}
      {/* ========================================================================= */}
      {activeTab === 'opd' && (
        <div className="space-y-6">
          {/* DUPLICATE BOOKING WARNING */}
          {opdDuplicateError && (
            <div className="p-4 rounded-2xl bg-amber-950/60 border border-amber-600/80 text-amber-200 text-xs font-semibold flex items-center justify-between">
              <span>{opdDuplicateError}</span>
              <button onClick={() => setOpdDuplicateError('')} className="p-1 text-amber-400 hover:text-white">✕</button>
            </div>
          )}

          {/* ACTIVE TOKEN CARD (Once booked) */}
          {generatedToken && (
            <div className="p-6 rounded-3xl bg-slate-900/80 backdrop-blur-2xl border-2 border-emerald-500/80 shadow-2xl shadow-emerald-950/40 relative overflow-hidden">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
                <div>
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                    DIGITAL TOKEN ACTIVE ✅ (OPD QUEUE PASS)
                  </span>
                  <div className="text-3xl font-black text-white mt-1 flex items-center space-x-2">
                    <span>#{generatedToken.tokenNumber}</span>
                    <button
                      type="button"
                      onClick={() => playSuccessDing()}
                      title="Replay Confirmation Chime"
                      className="p-1.5 rounded-lg bg-emerald-950/80 border border-emerald-500/40 text-emerald-400 hover:text-white transition"
                    >
                      <Volume2 className="w-4 h-4" />
                    </button>
                  </div>
                  <div className="text-xs text-slate-400">
                    {generatedToken.name} • {generatedToken.department} (Doctor Turn Pass)
                  </div>
                </div>

                <div className="bg-slate-950/90 p-4 rounded-2xl border border-slate-800 text-right">
                  <div className="text-2xl font-black text-emerald-400">{generatedToken.peopleAhead} Ahead</div>
                  <div className="text-[11px] text-slate-400">Currently in Room: {generatedToken.currentlyServing}</div>
                </div>
              </div>

              {/* Dynamic Home-Wait Pacing */}
              <div className="my-5 p-4 rounded-2xl bg-emerald-950/40 border border-emerald-700/60 flex items-start space-x-3.5">
                <Clock className="w-6 h-6 text-emerald-400 shrink-0 mt-0.5" />
                <div>
                  <h3 className="text-xs font-black text-emerald-200 uppercase tracking-wide">
                    Smart Just-in-Time Home Waiting Pacing
                  </h3>
                  <p className="text-sm font-bold text-white mt-1">
                    Booked at <span className="text-slate-300">{generatedToken.bookingTime}</span> • Please leave home at <span className="text-emerald-400">{generatedToken.leaveHomeTime}</span> (Estimated Turn: {generatedToken.consultationTime})
                  </p>
                  <p className="text-xs text-emerald-100/70 mt-1">
                    Travel time: ~{generatedToken.commuteMinutes} mins. Do not sit in packed hospital lobbies—relax safely at home until your scheduled leave time!
                  </p>
                </div>
              </div>

              {/* Progress Steps */}
              <div className="grid grid-cols-3 gap-2 text-center text-xs pt-1 font-semibold">
                <div className="p-2.5 rounded-xl bg-emerald-600/20 border border-emerald-500 text-emerald-200">
                  🏠 Safe at Home
                </div>
                <div className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800 text-slate-400">
                  🚗 Leave at {generatedToken.leaveHomeTime}
                </div>
                <div className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800 text-slate-400">
                  👨⚕️ Consult at {generatedToken.consultationTime}
                </div>
              </div>
            </div>
          )}

          {/* OPD BOOKING FORM */}
          <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/60 backdrop-blur-xl border border-slate-800 shadow-2xl space-y-6">
            <div>
              <h2 className="text-xl font-bold text-white">Book Digital OPD Token</h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Zero waiting in crowded lines. Receive dynamic pacing alerts on when to leave home.
              </p>
            </div>

            <form onSubmit={handleBookToken} className="space-y-4">
              {/* Name + Age/Gender */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Patient Full Name *</label>
                  <input
                    type="text"
                    required
                    value={patientName}
                    onChange={(e) => setPatientName(e.target.value)}
                    placeholder="e.g. Ramesh Verma"
                    className="w-full bg-slate-950/80 border border-slate-700 rounded-xl px-4 py-3 text-xs sm:text-sm text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">Age</label>
                    <input
                      type="number"
                      value={age}
                      onChange={(e) => setAge(e.target.value)}
                      placeholder="45"
                      className="w-full bg-slate-950/80 border border-slate-700 rounded-xl px-3 py-3 text-xs sm:text-sm text-white focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">Gender</label>
                    <select
                      value={gender}
                      onChange={(e) => setGender(e.target.value)}
                      className="w-full bg-slate-950/80 border border-slate-700 rounded-xl px-2 py-3 text-xs sm:text-sm text-white focus:outline-none focus:border-emerald-500"
                    >
                      <option value="M">Male</option>
                      <option value="F">Female</option>
                      <option value="O">Other</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Phone (No 0, 10 Digits) + Email */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Mobile Number (10 Digits, Cannot start with 0) *
                  </label>
                  <input
                    type="tel"
                    required
                    maxLength={10}
                    value={phone}
                    onChange={(e) => {
                      setPhone(e.target.value);
                      if (phoneError) setPhoneError('');
                    }}
                    placeholder="9845012345 (Cannot start with 0)"
                    className={`w-full bg-slate-950/80 border rounded-xl px-4 py-3 text-xs sm:text-sm text-white focus:outline-none ${
                      phoneError ? 'border-rose-500' : 'border-slate-700 focus:border-emerald-500'
                    }`}
                  />
                  {phoneError && <p className="text-[11px] text-rose-400 mt-1 font-bold">{phoneError}</p>}
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Email ID (Valid Email)</label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => {
                      setEmail(e.target.value);
                      if (emailError) setEmailError('');
                    }}
                    placeholder="patient@gmail.com"
                    className={`w-full bg-slate-950/80 border rounded-xl px-4 py-3 text-xs sm:text-sm text-white focus:outline-none ${
                      emailError ? 'border-rose-500' : 'border-slate-700 focus:border-emerald-500'
                    }`}
                  />
                  {emailError && <p className="text-[11px] text-rose-400 mt-1 font-bold">{emailError}</p>}
                </div>
              </div>

              {/* Select Hospital & Commute Time */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Select Hospital (Nearest Around Your Location) *
                  </label>
                  <select
                    value={hospital}
                    onChange={(e) => setHospital(e.target.value)}
                    className="w-full bg-slate-950/80 border border-slate-700 rounded-xl px-4 py-3 text-xs sm:text-sm text-white focus:outline-none focus:border-emerald-500"
                  >
                    {nearbyHospitals.map(h => (
                      <option key={h.id} value={h.name}>
                        {h.name} ({h.distance} • {h.icu} ICU Beds)
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Travel Time from Home</label>
                  <select
                    value={commuteTime}
                    onChange={(e) => setCommuteTime(e.target.value)}
                    className="w-full bg-slate-950/80 border border-slate-700 rounded-xl px-3 py-3 text-xs sm:text-sm text-white focus:outline-none focus:border-emerald-500"
                  >
                    <option value="15">~15 Minutes</option>
                    <option value="20">~20 Minutes</option>
                    <option value="30">~30 Minutes</option>
                    <option value="45">~45 Minutes</option>
                  </select>
                </div>
              </div>

              {/* Choose Symptoms Chips + Custom Type */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-semibold text-slate-300">
                    Choose Symptoms (Tap or Type Custom) <span className="text-rose-400">* Required</span>
                  </label>
                  {medicalProblem && (
                    <span className="text-[11px] text-emerald-400 font-bold">
                      Auto-Assigned: {getAutoDepartment(medicalProblem)}
                    </span>
                  )}
                </div>

                <div className="flex flex-wrap gap-1.5">
                  {COMMON_OPD_SYMPTOMS.map((sym, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => {
                        setMedicalProblem(sym.label);
                        if (symptomError) setSymptomError('');
                      }}
                      className={`px-2.5 py-1.5 rounded-xl text-xs transition border ${
                        medicalProblem === sym.label
                          ? 'bg-emerald-600 text-white border-emerald-400 font-bold shadow-md shadow-emerald-950'
                          : 'bg-slate-950/70 text-slate-300 border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      {sym.label}
                    </button>
                  ))}
                </div>

                <input
                  type="text"
                  value={medicalProblem}
                  onChange={(e) => {
                    setMedicalProblem(e.target.value);
                    if (symptomError) setSymptomError('');
                  }}
                  placeholder="Or type custom symptoms (e.g. Chest tightness with palpitations, joint swelling)..."
                  className={`w-full bg-slate-950/80 border rounded-xl px-4 py-3 text-xs sm:text-sm text-white focus:outline-none mt-2 ${
                    symptomError ? 'border-rose-500 ring-1 ring-rose-500/50' : 'border-slate-700 focus:border-emerald-500'
                  }`}
                />
                {symptomError && (
                  <p className="text-[11px] text-rose-400 font-bold mt-1 animate-pulse">
                    {symptomError}
                  </p>
                )}
              </div>

              <button
                type="submit"
                className="w-full py-4 bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-500 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-sm sm:text-base rounded-2xl shadow-xl shadow-emerald-950 transition-all flex items-center justify-center space-x-2"
              >
                <span>Confirm & Generate Digital Token</span>
                <ArrowRight className="w-5 h-5" />
              </button>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 🚨 TAB 2: EMERGENCY SOS WITH HOSPITAL CHOOSER & 2-MIN AUTO-DISPATCH       */}
      {/* ========================================================================= */}
      {activeTab === 'emergency' && (
        <div className="space-y-6">
          {/* DUPLICATE SOS WARNING */}
          {sosDuplicateError && (
            <div className="p-4 rounded-2xl bg-rose-950/60 border border-rose-600 text-rose-200 text-xs font-semibold flex items-center justify-between">
              <span>{sosDuplicateError}</span>
              <button onClick={() => setSosDuplicateError('')} className="p-1 text-rose-400 hover:text-white">✕</button>
            </div>
          )}

          {/* ========================================================================= */}
          {/* 🚨 CASE 1: ACTIVE EMERGENCY DISPATCH STATUS (Ambulance En Route)         */}
          {/* ========================================================================= */}
          {isSosActive && (
            <div className="p-6 rounded-3xl bg-slate-900/80 backdrop-blur-2xl border-2 border-rose-500 shadow-2xl shadow-rose-950/50 space-y-5">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
                <div className="flex items-center space-x-3">
                  <div className="p-3 bg-rose-600 text-white rounded-2xl shadow-lg shadow-rose-950 animate-bounce">
                    <AmbulanceIcon className="w-7 h-7" />
                  </div>
                  <div>
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-rose-600 text-white">
                      AMBULANCE DISPATCHED & CONFIRMED ✅
                    </span>
                    <h3 className="text-xl font-black text-white mt-1">
                      {sosSymptom || 'Acute Emergency Trauma'}
                    </h3>
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-3xl font-black text-rose-400">~{sosEta} MINS</div>
                  <div className="text-xs text-slate-400">Live Ambulance Countdown</div>
                </div>
              </div>

              {/* 🚨 108 AMBULANCE SIREN ACTIVE CONTROL BANNER */}
              <div className="p-4 rounded-2xl bg-gradient-to-r from-rose-600 via-red-600 to-rose-700 text-white flex flex-col sm:flex-row items-center justify-between gap-3 shadow-2xl shadow-rose-950/80 border-2 border-white animate-pulse">
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 rounded-2xl bg-white text-rose-600 flex items-center justify-center font-black text-2xl shadow-lg shrink-0 animate-bounce">
                    🚨
                  </div>
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="text-[10px] font-black uppercase tracking-widest bg-white/20 px-2.5 py-0.5 rounded-full">
                        108 AMBULANCE SIREN ACTIVE
                      </span>
                      <span className="text-xs font-bold text-rose-100">
                        {isPatientSirenPlaying ? '🔊 Blaring Live' : 'Muted'}
                      </span>
                    </div>
                    <h3 className="text-base font-black mt-0.5">
                      Emergency Siren Blaring • Help is En Route!
                    </h3>
                    <p className="text-xs text-rose-100">
                      Authentic 108 emergency siren sound playing continuously.
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    if (isPatientSirenPlaying) {
                      patientSiren.stop();
                      setIsPatientSirenPlaying(false);
                    } else {
                      patientSiren.warmup();
                      patientSiren.start();
                      setIsPatientSirenPlaying(true);
                    }
                  }}
                  className="px-5 py-2.5 bg-white hover:bg-rose-50 text-rose-700 rounded-xl text-xs font-black transition flex items-center space-x-2 shadow-xl shrink-0"
                >
                  {isPatientSirenPlaying ? (
                    <>
                      <VolumeX className="w-4 h-4 text-rose-600" />
                      <span>🔕 Mute Siren</span>
                    </>
                  ) : (
                    <>
                      <Volume2 className="w-4 h-4 text-rose-600" />
                      <span>🔊 Play / Unmute Siren</span>
                    </>
                  )}
                </button>
              </div>

              {/* Driver & Bed Lock Info */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800">
                  <span className="text-[10px] uppercase font-bold text-slate-400">Ambulance Unit</span>
                  <div className="text-sm font-bold text-white mt-1">#KA-04-E-1234 (ALS)</div>
                  <div className="text-[11px] text-slate-400">Driver: Rajesh Kumar</div>
                </div>

                <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800">
                  <span className="text-[10px] uppercase font-bold text-slate-400">Pre-Locked Bed</span>
                  <div className="text-sm font-bold text-rose-300 mt-1">Trauma Bay #2 (Reserved)</div>
                  <div className="text-[11px] text-emerald-400 font-bold">{assignedHospital?.name || 'Apollo Emergency'}</div>
                </div>

                <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800">
                  <span className="text-[10px] uppercase font-bold text-slate-400">Your Number</span>
                  <div className="text-sm font-bold text-cyan-300 mt-1">{sosPhone}</div>
                  <div className="text-[11px] text-slate-400">Driver Callback Line</div>
                </div>
              </div>

              {/* 🗺️ REAL MAP WITH MOVING AMBULANCE & ROUTE */}
              <div className="h-64 rounded-2xl overflow-hidden border border-slate-800 relative">
                <MapContainer
                  center={[userCoords.lat, userCoords.lng]}
                  zoom={14}
                  style={{ height: '100%', width: '100%' }}
                  scrollWheelZoom={false}
                >
                  <TileLayer
                    attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
                    url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                  />
                  <Marker position={[userCoords.lat, userCoords.lng]} icon={patientIcon}>
                    <Popup>Your Location</Popup>
                  </Marker>
                  {assignedHospital && (
                    <Marker position={[assignedHospital.lat, assignedHospital.lng]} icon={hospIcon}>
                      <Popup>{assignedHospital.name} (Assigned Hospital)</Popup>
                    </Marker>
                  )}
                  <Marker position={[userCoords.lat + 0.005, userCoords.lng + 0.005]} icon={ambIcon}>
                    <Popup>Ambulance KA-04-1234 (~5 mins away)</Popup>
                  </Marker>
                  <Polyline
                    positions={[
                      [userCoords.lat + 0.005, userCoords.lng + 0.005],
                      [userCoords.lat, userCoords.lng]
                    ]}
                    pathOptions={{ color: '#ef4444', weight: 4, dashArray: '6, 6' }}
                  />
                </MapContainer>
              </div>

              {/* First-Aid Guidance */}
              <div className="p-4 rounded-2xl bg-slate-950/90 border border-slate-800 space-y-2">
                <h4 className="text-xs font-black uppercase tracking-wider text-rose-300 flex items-center space-x-1.5">
                  <Sparkles className="w-4 h-4 text-rose-400" />
                  <span>Sanjeevani AI First-Aid Guidance (While Waiting)</span>
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  <div className="p-2.5 rounded-xl bg-emerald-950/30 border border-emerald-900/60 text-emerald-200">
                    <strong className="block text-emerald-300 mb-0.5">✅ DO:</strong>
                    Keep patient calm at a 45-degree angle. Loosen tight collar, belt, or shirt.
                  </div>
                  <div className="p-2.5 rounded-xl bg-rose-950/30 border border-rose-900/60 text-rose-200">
                    <strong className="block text-rose-300 mb-0.5">❌ DON'T:</strong>
                    Do NOT force glasses of water if patient is breathless or unconscious.
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap gap-3 pt-1">
                <button
                  onClick={toggleCPR}
                  className={`px-4 py-2.5 rounded-xl text-xs font-bold flex items-center space-x-2 transition ${
                    isCprRunning 
                      ? 'bg-rose-600 text-white shadow-lg shadow-rose-950 animate-pulse' 
                      : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'
                  }`}
                >
                  <Heart className="w-4 h-4 fill-current text-rose-400" />
                  <span>{isCprRunning ? `Stop CPR Beat (#${cprBeat})` : 'Launch Bystander CPR Copilot (110 BPM)'}</span>
                </button>

                <a
                  href={`https://wa.me/?text=EMERGENCY:%20Ambulance%20KA-04-1234%20dispatched%20to%20my%20location.%20Hospital:%20${encodeURIComponent(assignedHospital?.name || 'Apollo')}.%20Bay%202%20Locked.`}
                  target="_blank"
                  rel="noreferrer"
                  className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold flex items-center space-x-2 transition shadow-lg shadow-emerald-950"
                >
                  <Share2 className="w-4 h-4" />
                  <span>Share Live Status on WhatsApp</span>
                </a>

                <a
                  href="tel:108"
                  className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-bold flex items-center space-x-2 border border-slate-700 transition"
                >
                  <Phone className="w-4 h-4 text-emerald-400" />
                  <span>Call Paramedic (108)</span>
                </a>

                <button
                  type="button"
                  onClick={() => {
                    patientSiren.stop();
                    setIsPatientSirenPlaying(false);
                    setIsSosActive(false);
                    setIsSelectingHospital(false);
                    if (autoDispatchTimerRef.current) clearInterval(autoDispatchTimerRef.current);
                  }}
                  className="px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white rounded-xl text-xs font-bold flex items-center space-x-1.5 border border-slate-800 transition"
                >
                  <RotateCcw className="w-4 h-4 text-rose-400" />
                  <span>Cancel Emergency / Reset</span>
                </button>
              </div>
            </div>
          )}

          {/* ========================================================================= */}
          {/* 🏥 CASE 2: SELECT DESTINATION HOSPITAL (After Dispatch Button Clicked)     */}
          {/* ⏱️ 2-MINUTE AUTO-DISPATCH COUNTDOWN TO #1 NEAREST HOSPITAL               */}
          {/* ========================================================================= */}
          {!isSosActive && isSelectingHospital && (
            <div className="space-y-4 animate-in fade-in">
              {/* 2-Minute Live Auto-Lock Countdown Banner */}
              <div className="p-5 rounded-3xl bg-rose-950/80 border-2 border-rose-500 shadow-2xl shadow-rose-950/60 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex items-center space-x-3">
                  <div className="p-3 bg-rose-600 text-white rounded-2xl animate-bounce">
                    <Timer className="w-6 h-6" />
                  </div>
                  <div>
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-rose-600 text-white">
                      EMERGENCY AMBULANCE TRIGGERED 🚨
                    </span>
                    <h3 className="text-xl font-black text-white mt-1">
                      Choose Preferred Destination Hospital
                    </h3>
                    <p className="text-xs text-rose-200 mt-0.5">
                      Select your hospital below. If not selected within <strong>{formatTimer(autoDispatchSeconds)}</strong> (2 mins), system will auto-book <strong className="text-white">#1 {nearbyHospitals[0]?.name || 'Apollo'}</strong>!
                    </p>
                  </div>
                </div>

                <div className="bg-slate-950 px-4 py-3 rounded-2xl border border-rose-800 text-center shrink-0">
                  <span className="text-[10px] text-rose-400 font-bold uppercase block">2-Min Auto-Lock Timer</span>
                  <span className="text-2xl font-black font-mono text-white animate-pulse">
                    {formatTimer(autoDispatchSeconds)}
                  </span>
                </div>
              </div>

              {/* Near Locations / Hospitals Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {nearbyHospitals.map((h) => {
                  return (
                    <div
                      key={h.id}
                      className="p-5 rounded-3xl bg-slate-900 border border-slate-800 hover:border-rose-500/70 shadow-xl transition flex flex-col justify-between space-y-3"
                    >
                      <div className="flex justify-between items-start">
                        <div>
                          <div className="flex items-center space-x-2">
                            <span className="text-lg">🏥</span>
                            <h4 className="text-sm font-black text-white">{h.name}</h4>
                          </div>
                          <p className="text-xs text-slate-400 mt-1">{h.address}</p>
                        </div>
                        <div className="text-right shrink-0">
                          <span className="text-sm font-black text-rose-400 block">{h.distance}</span>
                          <span className="text-[10px] font-bold text-emerald-400">{h.icu} ICU Beds</span>
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={() => confirmEmergencyDispatch(h.id)}
                        className="w-full py-3 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded-xl text-xs flex items-center justify-center space-x-2 transition shadow-lg shadow-rose-950"
                      >
                        <AmbulanceIcon className="w-4 h-4 text-white" />
                        <span>Book Ambulance to {h.name} ➔</span>
                      </button>
                    </div>
                  );
                })}
              </div>

              {/* Quick Actions: Instant Default or Modify */}
              <div className="flex flex-col sm:flex-row items-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => confirmEmergencyDispatch(nearbyHospitals[0]?.id || 'h1')}
                  className="w-full py-3.5 bg-gradient-to-r from-emerald-700 to-teal-700 hover:from-emerald-600 hover:to-teal-600 text-white font-bold rounded-2xl text-xs transition shadow-lg flex items-center justify-center space-x-2"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Instant Confirm #1 Closest ({nearbyHospitals[0]?.name || 'Apollo'})</span>
                </button>

                <button
                  type="button"
                  onClick={() => setIsSelectingHospital(false)}
                  className="w-full sm:w-auto px-5 py-3.5 bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white font-bold rounded-2xl text-xs transition border border-slate-800 flex items-center justify-center space-x-1.5 shrink-0"
                >
                  <RotateCcw className="w-4 h-4" />
                  <span>Back / Edit Details</span>
                </button>
              </div>
            </div>
          )}

          {/* ========================================================================= */}
          {/* 📝 CASE 3: INITIAL EMERGENCY SOS FORM (Before Dispatch Clicked)          */}
          {/* NO AUTO-BOOKING UNTIL USER CLICKS DISPATCH!                              */}
          {/* ========================================================================= */}
          {!isSosActive && !isSelectingHospital && (
            <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/60 backdrop-blur-xl border border-rose-900/40 shadow-2xl shadow-rose-950/30 space-y-6">
              <div className="text-center max-w-lg mx-auto space-y-2">
                <span className="px-3 py-1 rounded-full bg-rose-950/80 border border-rose-800 text-rose-300 text-xs font-bold">
                  RAPID LIFE-LINE DISPATCH
                </span>
                <h2 className="text-2xl sm:text-3xl font-black text-white">Emergency Medical SOS</h2>
                <p className="text-xs sm:text-sm text-slate-400">
                  Enter your details below and click Dispatch. You will be able to select your destination hospital from nearby locations.
                </p>
              </div>

              {/* Phone Number Input (Strict 10 Digits, No 0 start) */}
              <div className="max-w-lg mx-auto">
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Your Contact Number (For Ambulance Driver Callback - 10 Digits) *
                </label>
                <input
                  type="tel"
                  maxLength={10}
                  value={sosPhone}
                  onChange={(e) => {
                    setSosPhone(e.target.value);
                    if (sosPhoneError) setSosPhoneError('');
                  }}
                  placeholder="9845012345 (Cannot start with 0)"
                  className={`w-full bg-slate-950/90 border rounded-2xl px-4 py-3.5 text-sm text-white focus:outline-none ${
                    sosPhoneError ? 'border-rose-500' : 'border-rose-700/60 focus:border-rose-500'
                  }`}
                />
                {sosPhoneError && <p className="text-[11px] text-rose-400 mt-1 font-bold">{sosPhoneError}</p>}
              </div>

              {/* Quick 1-Tap Presets */}
              <div className="max-w-lg mx-auto">
                <label className="block text-xs font-bold text-slate-300 mb-2">
                  ⚡ 1-Tap Quick Condition Presets (Or describe below):
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {[
                    { label: '🫀 Chest Pain / Gunde Noppi', desc: 'Severe acute chest pain radiating to left arm & sweating' },
                    { label: '🚗 Road Accident / Ratha Raktham', desc: 'High-impact vehicle accident, heavy trauma & bleeding' },
                    { label: '😮‍💨 Breathing Shortness', desc: 'Severe gasping for breath, asthmatic distress' },
                    { label: '🧠 Stroke Signs / Murcha', desc: 'Sudden facial paralysis, speech slur and fainting' },
                    { label: '🩸 Heavy Hemorrhage', desc: 'Uncontrolled arterial bleeding requiring tourniquet' },
                    { label: '👶 Pediatric Emergency', desc: 'High fever seizure / infant respiratory distress' }
                  ].map((item, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setSosSymptom(item.desc)}
                      className={`p-2.5 rounded-2xl border text-left text-xs transition ${
                        sosSymptom === item.desc
                          ? 'bg-rose-950/90 border-rose-500 text-white ring-1 ring-rose-500 shadow-md shadow-rose-950'
                          : 'bg-slate-950/70 border-slate-800 text-slate-300 hover:border-slate-700 hover:bg-slate-900'
                      }`}
                    >
                      <div className="font-bold text-[11px] truncate">{item.label}</div>
                      <div className="text-[9px] text-slate-400 mt-0.5 truncate">{item.desc}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Multilingual Voice Mic & Symptom Description Input */}
              <div className="max-w-lg mx-auto space-y-2.5">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1.5">
                  <label className="block text-xs font-bold text-slate-300">
                    Medical Symptoms / Emergency Voice AI:
                  </label>
                  
                  {/* Multilingual Language Switcher Pills */}
                  <div className="inline-flex items-center space-x-1 bg-slate-900/90 p-1 rounded-xl border border-slate-800 self-start sm:self-auto">
                    <span className="text-[10px] text-slate-400 font-semibold px-1 hidden sm:inline">Voice Lang:</span>
                    <button
                      type="button"
                      onClick={() => {
                        setVoiceLang('en-IN');
                        if (isListeningVoice) {
                          stopVoiceMic();
                          setTimeout(() => startVoiceMic('en-IN'), 150);
                        }
                      }}
                      className={`px-2.5 py-1 rounded-lg text-[10px] font-black transition ${
                        voiceLang === 'en-IN'
                          ? 'bg-rose-600 text-white shadow-md shadow-rose-950 ring-1 ring-white/30'
                          : 'text-slate-400 hover:text-white hover:bg-slate-800'
                      }`}
                    >
                      🌐 English / Telenglish
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setVoiceLang('te-IN');
                        if (isListeningVoice) {
                          stopVoiceMic();
                          setTimeout(() => startVoiceMic('te-IN'), 150);
                        }
                      }}
                      className={`px-2.5 py-1 rounded-lg text-[10px] font-black transition ${
                        voiceLang === 'te-IN'
                          ? 'bg-rose-600 text-white shadow-md shadow-rose-950 ring-1 ring-white/30'
                          : 'text-slate-400 hover:text-white hover:bg-slate-800'
                      }`}
                    >
                      🇮🇳 తెలుగు
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setVoiceLang('hi-IN');
                        if (isListeningVoice) {
                          stopVoiceMic();
                          setTimeout(() => startVoiceMic('hi-IN'), 150);
                        }
                      }}
                      className={`px-2.5 py-1 rounded-lg text-[10px] font-black transition ${
                        voiceLang === 'hi-IN'
                          ? 'bg-rose-600 text-white shadow-md shadow-rose-950 ring-1 ring-white/30'
                          : 'text-slate-400 hover:text-white hover:bg-slate-800'
                      }`}
                    >
                      🇮🇳 हिन्दी
                    </button>
                  </div>
                </div>

                <div className="relative">
                  <input
                    type="text"
                    value={sosSymptom}
                    onChange={(e) => setSosSymptom(e.target.value)}
                    placeholder={
                      isListeningVoice
                        ? 'Listening... Speak into microphone (e.g. "accident ayyindi", "gunde noppi")...'
                        : voiceLang === 'te-IN'
                        ? 'యాక్సిడెంట్ అయింది / గుండె నొప్పి / ఆయాసం... (లేదా మైక్ నొక్కండి)'
                        : voiceLang === 'hi-IN'
                        ? 'एक्सीडेंट / सीने में दर्द / सांस लेने में दिक्कत... (या माइक दबाएं)'
                        : 'Accident / Severe chest pain / Breathlessness... (or click Speak Mic)'
                    }
                    className={`w-full bg-slate-950/90 border rounded-2xl px-4 py-3.5 text-xs sm:text-sm text-white pr-36 focus:outline-none transition shadow-inner ${
                      isListeningVoice 
                        ? 'border-rose-500 ring-2 ring-rose-500/50' 
                        : 'border-slate-700 focus:border-rose-500 focus:ring-1 focus:ring-rose-500'
                    }`}
                  />
                  {isListeningVoice ? (
                    <button
                      type="button"
                      onClick={stopVoiceMic}
                      title="Click to stop listening"
                      className="absolute right-2 top-2 px-3 py-1.5 rounded-xl border text-xs font-bold transition flex items-center space-x-1.5 bg-rose-600 text-white border-rose-400 animate-pulse ring-2 ring-rose-400 shadow-lg"
                    >
                      <div className="flex space-x-0.5 items-center mr-1">
                        <span className="w-1 h-3 bg-white animate-bounce rounded-full"></span>
                        <span className="w-1 h-4 bg-white animate-bounce rounded-full [animation-delay:0.15s]"></span>
                        <span className="w-1 h-2 bg-white animate-bounce rounded-full [animation-delay:0.3s]"></span>
                      </div>
                      <span>Stop ⏹️</span>
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => startVoiceMic(voiceLang)}
                      title={`Click to speak in ${voiceLang === 'te-IN' ? 'Telugu' : voiceLang === 'hi-IN' ? 'Hindi' : 'English / Telenglish'}`}
                      className="absolute right-2 top-2 px-3 py-1.5 rounded-xl border text-xs font-bold transition flex items-center space-x-1.5 bg-gradient-to-r from-rose-950 to-red-950 text-rose-300 border-rose-700 hover:from-rose-900 hover:to-red-900 shadow hover:text-white"
                    >
                      <Mic className="w-3.5 h-3.5 text-rose-400" />
                      <span>{voiceLang === 'te-IN' ? '🎙️ మాట్లాడండి' : voiceLang === 'hi-IN' ? '🎙️ बोलिए' : '🎙️ Speak (Mic)'}</span>
                    </button>
                  )}
                </div>

                {/* Microphone Error / Permission Alert */}
                {micError && (
                  <div className="p-3.5 rounded-2xl bg-amber-950/80 border border-amber-500/80 flex items-start justify-between gap-3 text-xs text-amber-200 animate-in fade-in shadow-lg shadow-amber-950/40">
                    <div className="flex items-start space-x-2">
                      <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                      <div>
                        <strong className="block text-white font-bold mb-0.5">Microphone Notice</strong>
                        <span>{micError}</span>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2 shrink-0">
                      <button
                        type="button"
                        onClick={() => startVoiceMic('en-IN')}
                        className="px-2.5 py-1 bg-amber-600 hover:bg-amber-500 text-white rounded-lg text-[10px] font-bold transition shadow"
                      >
                        Retry (Mic)
                      </button>
                      <button
                        type="button"
                        onClick={() => setMicError('')}
                        className="p-1 text-amber-400 hover:text-white"
                      >
                        ✕
                      </button>
                    </div>
                  </div>
                )}

                {/* ⚡ Instant 1-Tap Emergency Health Chips */}
                <div className="flex flex-wrap items-center gap-1.5 pt-0.5">
                  <span className="text-[10px] text-slate-400 font-semibold mr-1">⚡ Quick Tap:</span>
                  {[
                    { label: '🚗 Accident Ayyindi', complaint: 'Road Accident & Severe Trauma (Accident Ayyindi - Urgent Ambulance Requested)' },
                    { label: '❤️ Gunde Noppi', complaint: 'Severe Acute Chest Pain & Suspected STEMI / Heart Attack (Gunde Noppi)' },
                    { label: '🫁 Aayasam', complaint: 'Acute Respiratory Distress & Severe Breathlessness (Aayasam - High Oxygen Priority)' },
                    { label: '🩸 Raktham Bleeding', complaint: 'Severe External Hemorrhage & Active Bleeding (Emergency Pressure Bandage Needed)' },
                    { label: '🧠 Stroke / Spruha Ledu', complaint: 'Suspected Acute Stroke / FAST Positive (Altered Sensorium - Golden Hour Emergency)' },
                  ].map((chip) => (
                    <button
                      key={chip.label}
                      type="button"
                      onClick={() => {
                        setSosSymptom(chip.complaint);
                        setMicError('');
                        if (isListeningVoice) stopVoiceMic();
                      }}
                      className={`px-2.5 py-1 rounded-xl text-[10px] font-bold border transition ${
                        sosSymptom === chip.complaint
                          ? 'bg-rose-600 text-white border-rose-400 shadow'
                          : 'bg-slate-900/80 hover:bg-slate-800 text-slate-300 border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      {chip.label}
                    </button>
                  ))}
                </div>

                {/* Live Mic Listening Status Box */}
                {isListeningVoice && (
                  <div className="p-3.5 rounded-2xl bg-rose-950/90 border border-rose-600 flex items-center justify-between text-xs text-rose-100 shadow-xl shadow-rose-950/50">
                    <div className="flex items-center space-x-3">
                      <div className="relative flex items-center justify-center">
                        <span className="w-3 h-3 rounded-full bg-rose-500 animate-ping"></span>
                        <span className="absolute w-2 h-2 rounded-full bg-rose-400"></span>
                      </div>
                      <div>
                        <div className="flex items-center space-x-2">
                          <strong className="block text-white font-black">
                            🎙️ Microphone Active ({voiceLang === 'te-IN' ? 'Telugu' : voiceLang === 'hi-IN' ? 'Hindi' : 'English / Telenglish'}):
                          </strong>
                          <span className="px-1.5 py-0.5 rounded bg-emerald-500/20 border border-emerald-500/40 text-[9px] font-black text-emerald-300 uppercase tracking-wide">
                            ⚡ Ultra-Fast 150ms Catch
                          </span>
                        </div>
                        {interimSpokenText ? (
                          <span className="text-[11px] text-emerald-300 font-mono block mt-0.5">
                            👂 Live Audio: &quot;{interimSpokenText}&quot; ➔ Auto-Standardized!
                          </span>
                        ) : (
                          <span className="text-[11px] text-rose-200 block mt-0.5">
                            Listening live... Speak clearly (e.g. &quot;accident ayyindi&quot;, &quot;gunde noppi&quot;, &quot;chest pain&quot;)
                          </span>
                        )}
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={stopVoiceMic}
                      className="px-3 py-1.5 bg-slate-950 hover:bg-slate-900 rounded-xl text-[11px] font-black text-rose-300 hover:text-white border border-rose-700 shrink-0 shadow"
                    >
                      Done / Stop ⏹️
                    </button>
                  </div>
                )}
              </div>

              {/* Blood Group */}
              <div className="max-w-lg mx-auto flex items-center justify-between text-xs pt-1">
                <span className="text-slate-400 font-semibold">Blood Group (Optional):</span>
                <div className="flex space-x-1">
                  {['O+', 'A+', 'B+', 'AB+', 'O-'].map((bg) => (
                    <button
                      key={bg}
                      type="button"
                      onClick={() => setBloodGroup(bg)}
                      className={`px-2 py-1 rounded-lg border text-[11px] font-bold ${
                        bloodGroup === bg
                          ? 'bg-rose-600 text-white border-rose-500'
                          : 'bg-slate-950 border-slate-800 text-slate-400'
                      }`}
                    >
                      {bg}
                    </button>
                  ))}
                </div>
              </div>

              {/* DISPATCH BUTTON */}
              <div className="max-w-lg mx-auto pt-2">
                <button
                  type="button"
                  onClick={handleTriggerSOS}
                  className="w-full py-5 rounded-3xl bg-gradient-to-r from-rose-600 via-red-600 to-rose-700 hover:from-rose-500 hover:to-red-500 text-white font-black text-base sm:text-lg shadow-2xl shadow-rose-950/80 border border-rose-400/30 transition-all flex items-center justify-center space-x-3"
                >
                  <AlertTriangle className="w-6 h-6 animate-bounce" />
                  <span>🚨 DISPATCH EMERGENCY SOS (AMBULANCE)</span>
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default PatientPortal;
