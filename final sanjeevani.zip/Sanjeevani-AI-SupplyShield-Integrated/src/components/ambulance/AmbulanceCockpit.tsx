import React, { useState } from 'react';
import { 
  Activity, 
  MapPin, 
  AlertTriangle, 
  RefreshCw, 
  CheckCircle2, 
  Heart, 
  Radio, 
  Gauge, 
  ArrowRight,
  ShieldAlert,
  Building2,
  Sparkles,
  Ambulance as AmbulanceIcon
} from 'lucide-react';
import { useHealthEcosystem } from '../../store/healthEcosystemStore';

export const AmbulanceCockpit: React.FC = () => {
  const { ambulances, actions } = useHealthEcosystem();
  const [isDiverted, setIsDiverted] = useState(false);
  const [targetHospital, setTargetHospital] = useState('Apollo Emergency & Multi-Speciality');
  const [eta, setEta] = useState(5);

  const handleSimulateDiversion = () => {
    setIsDiverted(true);
    setTargetHospital('City Care Trauma & Stroke Institute');
    setEta(8);
    if (ambulances[0]) {
      actions.triggerMidTransitAutoDiversion(ambulances[0].id);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-12">
      {/* 🚑 TOP HEADER */}
      <div className="p-6 rounded-3xl bg-slate-900/60 backdrop-blur-xl border border-slate-800 shadow-2xl flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center space-x-4">
          <div className="w-14 h-14 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center">
            <AmbulanceIcon className="w-8 h-8 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h2 className="text-xl font-black text-white">Ambulance Telemetry Cockpit</h2>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-950 text-amber-300 border border-amber-800">
                ALS UNIT #KA-04-1234
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">Paramedic: Anjali Sharma • Pilot: Rajesh Kumar</p>
          </div>
        </div>

        <div className="text-right bg-slate-950 px-4 py-2 rounded-2xl border border-slate-800">
          <span className="text-[10px] text-slate-400 uppercase font-bold">Current Speed & Status</span>
          <div className="text-sm font-bold text-emerald-400">62 km/h • Transporting</div>
        </div>
      </div>

      {/* 🔄 MID-TRANSIT AUTO-DIVERSION ALERT (When Triggered) */}
      {isDiverted && (
        <div className="p-5 rounded-3xl bg-amber-950/70 border-2 border-amber-500 shadow-2xl space-y-2 animate-pulse">
          <div className="flex items-center space-x-2 text-amber-300 font-bold text-xs uppercase tracking-wider">
            <AlertTriangle className="w-5 h-5 text-amber-400" />
            <span>CRITICAL AUTO-DIVERSION EXECUTED</span>
          </div>
          <h3 className="text-lg font-black text-white">
            Primary Hospital (Apollo) Reached 100% Saturation!
          </h3>
          <p className="text-xs text-amber-200">
            System automatically re-routed the ambulance to <strong className="text-white">City Care Trauma & Stroke Institute</strong>. 
            Trauma Bay #3 pre-locked. Zero time lost!
          </p>
        </div>
      )}

      {/* 📍 DESTINATION BANNER */}
      <div className="p-5 rounded-3xl bg-slate-900 border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center space-x-3">
          <Building2 className="w-6 h-6 text-indigo-400" />
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-400">En Route Destination</span>
            <div className="text-base font-black text-white">{targetHospital}</div>
          </div>
        </div>
        <div className="text-right">
          <div className="text-2xl font-black text-rose-400">ETA ~{eta} MINS</div>
          <span className="text-[10px] text-slate-400">Live GPS Corridor Sync</span>
        </div>
      </div>

      {/* 💓 3 BIG CLEAN VITALS METRICS */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-5 rounded-3xl bg-slate-900/80 border border-slate-800 text-center space-y-1">
          <div className="text-xs text-slate-400 uppercase font-bold flex items-center justify-center space-x-1">
            <Heart className="w-4 h-4 text-rose-500 fill-rose-500" />
            <span>Heart Rate</span>
          </div>
          <div className="text-4xl font-black text-rose-400">118 <span className="text-sm text-slate-500 font-normal">BPM</span></div>
          <div className="text-[11px] text-amber-400 font-bold">Tachycardic (High)</div>
        </div>

        <div className="p-5 rounded-3xl bg-slate-900/80 border border-slate-800 text-center space-y-1">
          <div className="text-xs text-slate-400 uppercase font-bold flex items-center justify-center space-x-1">
            <Gauge className="w-4 h-4 text-indigo-400" />
            <span>Blood Pressure</span>
          </div>
          <div className="text-4xl font-black text-indigo-300">90/60</div>
          <div className="text-[11px] text-amber-400 font-bold">Hypotensive Warning</div>
        </div>

        <div className="p-5 rounded-3xl bg-slate-900/80 border border-slate-800 text-center space-y-1">
          <div className="text-xs text-slate-400 uppercase font-bold flex items-center justify-center space-x-1">
            <Activity className="w-4 h-4 text-cyan-400" />
            <span>Oxygen (SpO2)</span>
          </div>
          <div className="text-4xl font-black text-cyan-300">92%</div>
          <div className="text-[11px] text-emerald-400 font-bold">15L Mask Administered</div>
        </div>
      </div>

      {/* 🎯 THE KILLER FEATURE TEST BUTTON FOR JUDGES */}
      <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-3">
        <div className="flex items-center space-x-2">
          <Sparkles className="w-5 h-5 text-amber-400" />
          <h3 className="text-sm font-bold text-white">Hackathon Killer Feature: Mid-Transit Auto-Diversion</h3>
        </div>
        <p className="text-xs text-slate-400 leading-relaxed">
          In normal apps, if a hospital runs out of beds while the ambulance is driving, the patient gets rejected at the door. 
          In Sanjeevani AI, our system monitors bed saturation in real-time. Test it now:
        </p>
        <button
          onClick={handleSimulateDiversion}
          className="w-full py-4 bg-amber-600 hover:bg-amber-500 text-white font-bold rounded-2xl text-xs sm:text-sm transition flex items-center justify-center space-x-2 shadow-lg shadow-amber-950"
        >
          <RefreshCw className="w-4 h-4" />
          <span>Simulate Hospital Saturation & Auto-Reroute Ambulance</span>
        </button>
      </div>
    </div>
  );
};

export default AmbulanceCockpit;
