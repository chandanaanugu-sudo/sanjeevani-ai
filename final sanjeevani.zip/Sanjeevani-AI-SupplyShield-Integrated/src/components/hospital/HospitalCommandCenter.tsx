import React, { useState, useEffect } from 'react';
import { 
  Building2, 
  ShieldAlert, 
  Clock, 
  CheckCircle2, 
  Users, 
  Volume2, 
  ChevronRight, 
  AlertTriangle
} from 'lucide-react';
import { useHealthEcosystem } from '../../store/healthEcosystemStore';

function playChime() {
  try {
    const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    const ctx = new AudioCtx();
    ctx.resume().then(() => {
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(523.25, now);
      osc.frequency.setValueAtTime(659.25, now + 0.15);
      osc.frequency.setValueAtTime(783.99, now + 0.3);
      gain.gain.setValueAtTime(0.25, now);
      gain.gain.exponentialRampToValueAtTime(0.005, now + 0.7);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.7);
    });
  } catch (e) {
    console.warn(e);
  }
}

export const HospitalCommandCenter: React.FC = () => {
  const { actions } = useHealthEcosystem();

  const [bedTimerSeconds, setBedTimerSeconds] = useState(24 * 60 + 12);
  const [patientAdmitted, setPatientAdmitted] = useState(false);
  const [currentServing, setCurrentServing] = useState('CARD-101');
  const [delayNotice, setDelayNotice] = useState('');

  const [queueList, setQueueList] = useState([
    { token: 'CARD-101', name: 'Kavita Menon', problem: 'Heart Palpitations', status: 'In Consultation' },
    { token: 'CARD-102', name: 'Arjun Das', problem: 'High Blood Pressure Check', status: 'In Waiting Lobby' },
    { token: 'CARD-103', name: 'Pooja Iyer', problem: 'Post-Surgery Followup', status: 'Safe at Home (Arrives 10:40 AM)' },
    { token: 'CARD-104', name: 'Ramesh Verma', problem: 'Chest Tightness', status: 'Safe at Home (Arrives 11:10 AM)' }
  ]);

  // Countdown timer for 30-min bed lock
  useEffect(() => {
    const timer = setInterval(() => {
      setBedTimerSeconds(prev => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatTimer = (s: number) => {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return `${m}:${sec < 10 ? '0' : ''}${sec}`;
  };

  const handleCallNext = () => {
    playChime();
    const currentIndex = queueList.findIndex(q => q.status === 'In Consultation');
    if (currentIndex !== -1 && currentIndex < queueList.length - 1) {
      const nextToken = queueList[currentIndex + 1].token;
      setCurrentServing(nextToken);
      setQueueList(prev => prev.map((item, idx) => {
        if (idx === currentIndex) return { ...item, status: 'Completed' };
        if (idx === currentIndex + 1) return { ...item, status: 'In Consultation' };
        if (idx === currentIndex + 2) return { ...item, status: 'In Waiting Lobby' };
        return item;
      }));
    }
  };

  const handleBroadcastDelay = () => {
    setDelayNotice('⚠️ Doctor Delayed by +15 mins broadcasted to all home-waiting patients!');
    setTimeout(() => setDelayNotice(''), 5000);
  };

  const handleAdmit = () => {
    setPatientAdmitted(true);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-12">
      {/* 🏥 HEADER & BED INVENTORY */}
      <div className="p-6 rounded-3xl bg-slate-900/60 backdrop-blur-xl border border-slate-800 shadow-2xl flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center space-x-4">
          <div className="w-14 h-14 rounded-2xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 flex items-center justify-center">
            <Building2 className="w-8 h-8" />
          </div>
          <div>
            <h2 className="text-xl font-black text-white">Apollo Hospital Command Desk</h2>
            <p className="text-xs text-slate-400 mt-0.5">Doctor In-Charge: Dr. Sudhir Rao, MD (Cardiology)</p>
          </div>
        </div>

        <div className="flex space-x-2">
          <div className="px-3.5 py-2 rounded-2xl bg-slate-950 border border-slate-800 text-center">
            <span className="text-[10px] text-slate-400 uppercase font-bold block">Available ER Beds</span>
            <span className="text-lg font-black text-white">4 / 16</span>
          </div>
          <div className="px-3.5 py-2 rounded-2xl bg-slate-950 border border-slate-800 text-center">
            <span className="text-[10px] text-slate-400 uppercase font-bold block">Available ICU Beds</span>
            <span className="text-lg font-black text-emerald-400">2 / 8</span>
          </div>
        </div>
      </div>

      {/* 🚨 SECTION 1: EMERGENCY TRAUMA CODE RED CARD */}
      <div className="p-6 rounded-3xl bg-slate-900/80 backdrop-blur-2xl border-2 border-rose-600/80 shadow-2xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 bg-rose-600 text-white rounded-xl animate-bounce">
              <ShieldAlert className="w-6 h-6" />
            </div>
            <div>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-rose-600 text-white">
                CODE RED • EMERGENCY ARRIVAL
              </span>
              <h3 className="text-lg font-black text-white mt-0.5">
                Incoming: 52/M, Acute STEMI (Heart Attack)
              </h3>
            </div>
          </div>

          <div className="text-right bg-slate-950 px-4 py-2 rounded-2xl border border-slate-800">
            <span className="text-[10px] text-rose-400 uppercase font-bold block">30-Min Bed Reservation</span>
            <div className="text-xl font-mono font-black text-white">
              {patientAdmitted ? 'ADMITTED ✅' : `Hold: ${formatTimer(bedTimerSeconds)}`}
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
          <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
            <span className="text-slate-400 block">Locked Resus Bay:</span>
            <strong className="text-rose-300 text-sm">Trauma Bay #2 (Reserved)</strong>
          </div>
          <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
            <span className="text-slate-400 block">Incoming Unit:</span>
            <strong className="text-white text-sm">Ambulance KA-04-1234</strong>
          </div>
          <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
            <span className="text-slate-400 block">Required Facility:</span>
            <strong className="text-emerald-400 text-sm">Cath Lab Team Ready</strong>
          </div>
        </div>

        <div className="pt-2">
          {!patientAdmitted ? (
            <button
              onClick={handleAdmit}
              className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-2xl text-xs sm:text-sm transition flex items-center justify-center space-x-2 shadow-lg shadow-emerald-950"
            >
              <CheckCircle2 className="w-5 h-5" />
              <span>Admit Patient & Fulfill Bed Hold (Ambulance Arrived)</span>
            </button>
          ) : (
            <div className="p-3 bg-emerald-950/60 border border-emerald-500 text-emerald-300 rounded-2xl text-center text-xs font-bold">
              ✅ Patient Successfully Admitted to Trauma Bay #2. Clinical Handoff Complete!
            </div>
          )}
        </div>
      </div>

      {/* ⏱️ SECTION 2: OPD QUEUE CONTROLLER (DOCTOR DESK) */}
      <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
          <div className="flex items-center space-x-2">
            <Users className="w-5 h-5 text-indigo-400" />
            <h3 className="text-base font-bold text-white">OPD Consultation Queue (Cardiology)</h3>
          </div>

          <div className="flex space-x-2">
            <button
              onClick={handleBroadcastDelay}
              className="px-3.5 py-2 bg-amber-600/20 hover:bg-amber-600/30 text-amber-300 border border-amber-500/40 rounded-xl text-xs font-bold transition"
            >
              Broadcast +15m Delay
            </button>

            <button
              onClick={handleCallNext}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold transition flex items-center space-x-1.5 shadow-md shadow-indigo-950"
            >
              <span>Call Next Patient</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {delayNotice && (
          <div className="p-3 rounded-xl bg-amber-950/60 border border-amber-600 text-amber-200 text-xs font-semibold">
            {delayNotice}
          </div>
        )}

        {/* Patient List */}
        <div className="space-y-2">
          {queueList.map((q) => (
            <div 
              key={q.token}
              className={`p-3.5 rounded-2xl border flex items-center justify-between text-xs transition ${
                q.status === 'In Consultation'
                  ? 'bg-indigo-950/70 border-indigo-500 text-white font-bold'
                  : 'bg-slate-950/60 border-slate-800 text-slate-300'
              }`}
            >
              <div className="flex items-center space-x-3">
                <span className="font-mono text-indigo-400 font-bold">{q.token}</span>
                <span className="text-white font-semibold">{q.name}</span>
                <span className="text-slate-400">({q.problem})</span>
              </div>

              <div>
                <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold ${
                  q.status === 'In Consultation'
                    ? 'bg-indigo-600 text-white'
                    : q.status === 'In Waiting Lobby'
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                    : q.status === 'Completed'
                    ? 'bg-slate-800 text-slate-500 line-through'
                    : 'bg-slate-900 text-slate-400 border border-slate-800'
                }`}>
                  {q.status}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default HospitalCommandCenter;
