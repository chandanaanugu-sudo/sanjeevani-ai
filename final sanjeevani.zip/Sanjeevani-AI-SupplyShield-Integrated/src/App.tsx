import React, { useState, useEffect } from 'react';
import { useHealthEcosystem } from './store/healthEcosystemStore';
import { Navbar } from './components/layout/Navbar';
import { PatientPortal } from './components/patient/PatientPortal';
import { AmbulanceCockpit } from './components/ambulance/AmbulanceCockpit';
import { AdminPortal } from './components/admin/AdminPortal';
import { SupplyShieldDashboard } from './components/admin/SupplyShieldDashboard';
import { CityNetworkMap } from './components/city/CityNetworkMap';
import { Activity, ShieldCheck, Heart, Sparkles, Award } from 'lucide-react';

export const App: React.FC = () => {
  const [isAdminRoute, setIsAdminRoute] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const path = window.location.pathname.toLowerCase();
      const search = window.location.search.toLowerCase();
      const hash = window.location.hash.toLowerCase();
      return path.includes('admin') || search.includes('admin') || hash.includes('admin');
    }
    return false;
  });

  // Independent route checking for this window
  useEffect(() => {
    const handleUrlChange = () => {
      const path = window.location.pathname.toLowerCase();
      const search = window.location.search.toLowerCase();
      const hash = window.location.hash.toLowerCase();
      setIsAdminRoute(path.includes('admin') || search.includes('admin') || hash.includes('admin'));
    };

    window.addEventListener('popstate', handleUrlChange);
    window.addEventListener('hashchange', handleUrlChange);
    return () => {
      window.removeEventListener('popstate', handleUrlChange);
      window.removeEventListener('hashchange', handleUrlChange);
    };
  }, []);

  const handleNavigateToAdmin = () => {
    setIsAdminRoute(true);
    try {
      window.history.pushState({}, '', '/admin');
    } catch (e) {}
  };

  const handleNavigateToPatient = () => {
    setIsAdminRoute(false);
    try {
      window.history.pushState({}, '', '/');
    } catch (e) {}
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col selection:bg-rose-500 selection:text-white">
      {/* Top Navigation & Live Ticker */}
      <Navbar isAdmin={isAdminRoute} />

      {/* Main Perspective Container (100% Isolated: Left is Patient, Right is Admin) */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {isAdminRoute ? (
          <AdminPortal />
        ) : (
          <div className="space-y-8">
            <PatientPortal />

            {/* Unified Sanjeevani AI + SupplyShield view */}
            <section
              id="supplyshield"
              aria-label="SupplyShield medicine supply intelligence"
              className="border-t border-slate-800/80 pt-8"
            >
              <div className="mb-5 flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
                <div>
                  <p className="text-[10px] font-black uppercase tracking-[0.2em] text-cyan-400">
                    Sanjeevani AI + SupplyShield
                  </p>
                  <h2 className="mt-1 text-2xl font-black text-white">
                    Patient Care & Medicine Supply Intelligence
                  </h2>
                  <p className="mt-1 max-w-3xl text-xs text-slate-400">
                    Patient care remains connected to the same live health ecosystem,
                    while SupplyShield predicts medicine shortages and coordinates supply.
                  </p>
                </div>
                <span className="w-fit rounded-full border border-emerald-500/20 bg-emerald-500/5 px-3 py-1 text-[10px] font-bold text-emerald-300">
                  ● Integrated Demo
                </span>
              </div>

              <SupplyShieldDashboard />
            </section>
          </div>
        )}
      </main>

      {/* Hackathon Judge Feature Ribbon Footer */}
      <footer className="border-t border-slate-800/80 bg-slate-950/90 py-6 px-4">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-slate-400">
          <div className="flex items-center space-x-3">
            <div className="flex items-center space-x-2">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              <span className="font-bold text-slate-200">Sanjeevani AI</span>
              <span>— {!isAdminRoute ? 'Patient Portal' : 'Hospital Command Network'}</span>
            </div>

            {/* Subtle Staff / Hospital Login */}
            <span className="text-slate-700">|</span>
            {!isAdminRoute ? (
              <button
                onClick={handleNavigateToAdmin}
                className="text-slate-500 hover:text-slate-300 transition underline underline-offset-4 text-[11px]"
              >
                🔒 Hospital Staff / Admin Login
              </button>
            ) : (
              <button
                onClick={handleNavigateToPatient}
                className="text-emerald-400 hover:text-emerald-300 font-bold transition text-[11px]"
              >
                ← Return to Patient Portal
              </button>
            )}
          </div>

          {/* Hackathon Differentiators Checklist for Judges */}
          <div className="flex flex-wrap items-center gap-3 text-[11px]">
            <span className="flex items-center space-x-1 text-emerald-400">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Capability-Based Matching</span>
            </span>
            <span className="flex items-center space-x-1 text-amber-400">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Mid-Transit Auto-Diversion</span>
            </span>
            <span className="flex items-center space-x-1 text-rose-400">
              <Heart className="w-3.5 h-3.5" />
              <span>110 BPM CPR Copilot</span>
            </span>
            <span className="flex items-center space-x-1 text-indigo-400">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Gemini Clinical Triage</span>
            </span>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;
