import type {
  MedicineInventory,
  StockRiskLevel,
  MedicineSupplier
} from '../types';

// ==================== DEMAND FORECAST ====================

export function calculateDemandGrowth(weeklyDemand: number[]): number {
  if (weeklyDemand.length < 2) return 0;

  const first = weeklyDemand[0];
  const last = weeklyDemand[weeklyDemand.length - 1];

  if (first === 0) return 0;

  return Number((((last - first) / first) * 100).toFixed(1));
}

export function calculateForecastDailyDemand(
  inventory: MedicineInventory
): number {
  const demand = inventory.weeklyDemand;

  if (demand.length === 0) {
    return inventory.dailyDemand;
  }

  const recentDemand =
    demand.reduce((sum, value) => sum + value, 0) / demand.length;

  const latestDemand = demand[demand.length - 1];

  const forecast = recentDemand * 0.4 + latestDemand * 0.6;

  return Number(forecast.toFixed(1));
}

// ==================== STOCKOUT PREDICTION ====================

export interface StockoutPrediction {
  medicineId: string;
  medicineName: string;
  hospitalId: string;
  currentStock: number;
  forecastDailyDemand: number;
  daysUntilStockout: number;
  daysUntilMinimumStock: number;
  riskLevel: StockRiskLevel;
  demandGrowthPercent: number;
  recommendation: string;
}

export function calculateStockoutPrediction(
  inventory: MedicineInventory
): StockoutPrediction {
  const forecastDailyDemand =
    calculateForecastDailyDemand(inventory);

  const demandGrowthPercent =
    calculateDemandGrowth(inventory.weeklyDemand);

  const safeDemand = Math.max(1, forecastDailyDemand);

  const daysUntilStockout = Math.floor(
    inventory.currentStock / safeDemand
  );

  const stockAboveMinimum = Math.max(
    0,
    inventory.currentStock - inventory.minimumStock
  );

  const daysUntilMinimumStock = Math.floor(
    stockAboveMinimum / safeDemand
  );

  let riskLevel: StockRiskLevel;

  if (inventory.currentStock <= 0) {
    riskLevel = 'critical';
  } else if (daysUntilStockout <= 2) {
    riskLevel = 'critical';
  } else if (daysUntilStockout <= 4) {
    riskLevel = 'high';
  } else if (inventory.currentStock <= inventory.minimumStock) {
    riskLevel = 'high';
  } else if (daysUntilStockout <= 7) {
    riskLevel = 'moderate';
  } else {
    riskLevel = 'safe';
  }

  let recommendation: string;

  if (riskLevel === 'critical') {
    recommendation =
      'Immediate redistribution or emergency supplier order required.';
  } else if (riskLevel === 'high') {
    recommendation =
      'Prepare replenishment and identify hospitals with surplus stock.';
  } else if (riskLevel === 'moderate') {
    recommendation =
      'Monitor demand closely and prepare a replenishment plan.';
  } else {
    recommendation =
      'Inventory is currently within a safe operating range.';
  }

  return {
    medicineId: inventory.id,
    medicineName: inventory.medicineName,
    hospitalId: inventory.hospitalId,
    currentStock: inventory.currentStock,
    forecastDailyDemand,
    daysUntilStockout,
    daysUntilMinimumStock,
    riskLevel,
    demandGrowthPercent,
    recommendation
  };
}

// ==================== SMART REDISTRIBUTION ====================

export interface RedistributionRecommendation {
  id: string;
  medicineName: string;
  sourceHospitalId: string;
  destinationHospitalId: string;
  quantity: number;
  reason: string;
  sourceRemainingStock: number;
  destinationProjectedStock: number;
}

export function calculateRedistributionQuantity(
  source: MedicineInventory,
  destination: MedicineInventory
): number {
  const destinationForecast =
    calculateForecastDailyDemand(destination);

  // Keep roughly 3 days of demand at the destination after transfer.
  const targetStock = Math.max(
    destination.minimumStock,
    Math.ceil(destinationForecast * 3)
  );

  const destinationNeed = Math.max(
    0,
    targetStock - destination.currentStock
  );

  const sourceForecast =
    calculateForecastDailyDemand(source);

  // Keep roughly 7 days of source demand plus minimum stock.
  const sourceProtectedStock = Math.max(
    source.minimumStock,
    Math.ceil(sourceForecast * 7)
  );

  const sourceSurplus = Math.max(
    0,
    source.currentStock - sourceProtectedStock
  );

  return Math.min(
    destinationNeed,
    sourceSurplus
  );
}

export function findRedistributionSource(
  destination: MedicineInventory,
  inventories: MedicineInventory[]
): MedicineInventory | null {
  const candidates = inventories.filter(
    item =>
      item.id !== destination.id &&
      item.medicineName === destination.medicineName &&
      item.currentStock > item.minimumStock
  );

  if (candidates.length === 0) return null;

  candidates.sort((a, b) => {
    const surplusA = a.currentStock - a.minimumStock;
    const surplusB = b.currentStock - b.minimumStock;
    return surplusB - surplusA;
  });

  return candidates[0];
}

// ==================== DELIVERY RISK ====================

export type DeliveryRiskLevel =
  | 'low'
  | 'medium'
  | 'high';

export function calculateDeliveryRisk(
  supplier: MedicineSupplier,
  daysUntilStockout: number
): DeliveryRiskLevel {
  const deliveryDays =
    supplier.averageDeliveryHours / 24;

  if (deliveryDays >= daysUntilStockout) {
    return 'high';
  }

  if (deliveryDays >= daysUntilStockout - 1) {
    return 'medium';
  }

  return 'low';
}

// ==================== COMPLETE RECOMMENDATION ====================

export function buildRedistributionRecommendation(
  destination: MedicineInventory,
  inventories: MedicineInventory[]
): RedistributionRecommendation | null {
  const source = findRedistributionSource(
    destination,
    inventories
  );

  if (!source) return null;

  const quantity = calculateRedistributionQuantity(
    source,
    destination
  );

  if (quantity <= 0) return null;

  return {
    id: `transfer-${destination.id}-${source.id}`,
    medicineName: destination.medicineName,
    sourceHospitalId: source.hospitalId,
    destinationHospitalId: destination.hospitalId,
    quantity,
    reason:
      `${destination.medicineName} is approaching stockout while another hospital has enough protected surplus inventory.`,
    sourceRemainingStock:
      source.currentStock - quantity,
    destinationProjectedStock:
      destination.currentStock + quantity
  };
}
