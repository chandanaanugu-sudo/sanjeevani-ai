// Web Audio API sound synthesizer for CPR metronome and hospital telemetry
class SoundSynthesizer {
  private ctx: AudioContext | null = null;
  private cprIntervalId: number | null = null;
  private isCprRunning: boolean = false;

  private getContext(): AudioContext {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
    return this.ctx;
  }

  // 110 BPM CPR Metronome (60 / 110 = 0.5454s interval)
  startCPRMetronome(onBeat?: (count: number) => void) {
    if (this.isCprRunning) return;
    this.isCprRunning = true;
    let count = 0;

    const playBeep = () => {
      try {
        const ctx = this.getContext();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        // Distinct metronome click (800Hz, crisp decay)
        const isDownbeat = count % 30 === 0; // 30 compressions cycle
        osc.type = 'sine';
        osc.frequency.setValueAtTime(isDownbeat ? 1046.5 : 784, ctx.currentTime); // C6 or G5

        gain.gain.setValueAtTime(0.3, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.08);

        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.start();
        osc.stop(ctx.currentTime + 0.08);

        count++;
        if (onBeat) onBeat(count);
      } catch (e) {
        console.warn('Audio play error:', e);
      }
    };

    playBeep();
    this.cprIntervalId = window.setInterval(playBeep, (60 / 110) * 1000);
  }

  stopCPRMetronome() {
    if (this.cprIntervalId !== null) {
      clearInterval(this.cprIntervalId);
      this.cprIntervalId = null;
    }
    this.isCprRunning = false;
  }

  getIsCprRunning(): boolean {
    return this.isCprRunning;
  }

  // Hospital Code Red Trauma Alarm (two-tone alert)
  playCodeRedAlert() {
    try {
      const ctx = this.getContext();
      const now = ctx.currentTime;

      // Tone 1
      const osc1 = ctx.createOscillator();
      const gain1 = ctx.createGain();
      osc1.frequency.setValueAtTime(880, now); // A5
      gain1.gain.setValueAtTime(0.25, now);
      gain1.gain.exponentialRampToValueAtTime(0.01, now + 0.25);
      osc1.connect(gain1);
      gain1.connect(ctx.destination);
      osc1.start(now);
      osc1.stop(now + 0.25);

      // Tone 2
      const osc2 = ctx.createOscillator();
      const gain2 = ctx.createGain();
      osc2.frequency.setValueAtTime(659.25, now + 0.25); // E5
      gain2.gain.setValueAtTime(0.25, now + 0.25);
      gain2.gain.exponentialRampToValueAtTime(0.01, now + 0.55);
      osc2.connect(gain2);
      gain2.connect(ctx.destination);
      osc2.start(now + 0.25);
      osc2.stop(now + 0.55);
    } catch (e) {
      console.warn('Audio alert error:', e);
    }
  }

  // Mid-Transit Diversion Reroute Tone
  playDiversionSound() {
    try {
      const ctx = this.getContext();
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(440, now);
      osc.frequency.exponentialRampToValueAtTime(880, now + 0.3);

      gain.gain.setValueAtTime(0.2, now);
      gain.gain.exponentialRampToValueAtTime(0.01, now + 0.4);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.4);
    } catch (e) {
      console.warn('Diversion sound error:', e);
    }
  }

  // OPD Token Bell Call Chime
  playTokenChime() {
    try {
      const ctx = this.getContext();
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(523.25, now); // C5
      osc.frequency.setValueAtTime(659.25, now + 0.15); // E5
      osc.frequency.setValueAtTime(783.99, now + 0.3); // G5

      gain.gain.setValueAtTime(0.2, now);
      gain.gain.exponentialRampToValueAtTime(0.005, now + 0.7);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.7);
    } catch (e) {
      console.warn('Token chime error:', e);
    }
  }
}

export const audioService = new SoundSynthesizer();
