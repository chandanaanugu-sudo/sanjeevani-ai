import { createClient } from '@supabase/supabase-js';

export const SUPABASE_URL = 
  import.meta.env.VITE_SUPABASE_URL || 'https://sheurefzkjjjgqfjjtaf.supabase.co';

export const SUPABASE_ANON_KEY = 
  import.meta.env.VITE_SUPABASE_ANON_KEY || 'sb_publishable_bAN6RCrv9PIiW0uzCOX6Bw_LCk3Nle4';

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  realtime: {
    params: {
      eventsPerSecond: 10,
    },
  },
});

export interface SupabaseOpdToken {
  id?: string;
  token_number: string;
  patient_name: string;
  age: string;
  gender: string;
  phone: string;
  email?: string;
  problem: string;
  department: string;
  hospital?: string;
  status: string;
  leave_home_time?: string;
  consultation_time?: string;
  created_at?: string;
}

export interface SupabaseEmergencySos {
  id?: string;
  phone: string;
  symptoms: string;
  blood_group?: string;
  location?: string;
  hospital_name?: string;
  status: string;
  created_at?: string;
}

// Fetch all OPD tokens ordered by creation time
export async function fetchOpdTokens(): Promise<SupabaseOpdToken[]> {
  try {
    const { data, error } = await supabase
      .from('opd_tokens')
      .select('*')
      .order('created_at', { ascending: true });

    if (error) {
      console.warn('Supabase fetchOpdTokens error:', error);
      return [];
    }
    return data || [];
  } catch (err) {
    console.warn('Supabase fetchOpdTokens exception:', err);
    return [];
  }
}

// Insert new OPD token
export async function insertOpdToken(token: SupabaseOpdToken): Promise<boolean> {
  try {
    const { error } = await supabase.from('opd_tokens').insert([token]);
    if (error) {
      console.warn('Supabase insertOpdToken error:', error);
      return false;
    }
    return true;
  } catch (err) {
    console.warn('Supabase insertOpdToken exception:', err);
    return false;
  }
}

// Update token status (e.g. 'In Consultation', 'Completed')
export async function updateTokenStatus(tokenNumber: string, status: string): Promise<boolean> {
  try {
    const { error } = await supabase
      .from('opd_tokens')
      .update({ status })
      .eq('token_number', tokenNumber);

    if (error) {
      console.warn('Supabase updateTokenStatus error:', error);
      return false;
    }
    return true;
  } catch (err) {
    console.warn('Supabase updateTokenStatus exception:', err);
    return false;
  }
}

// Insert Emergency SOS Incident
export async function insertEmergencySos(sos: SupabaseEmergencySos): Promise<boolean> {
  try {
    const { error } = await supabase.from('emergency_sos').insert([sos]);
    if (error) {
      console.warn('Supabase insertEmergencySos error:', error);
      return false;
    }
    return true;
  } catch (err) {
    console.warn('Supabase insertEmergencySos exception:', err);
    return false;
  }
}

// Fetch latest active Emergency SOS
export async function fetchLatestActiveSos(): Promise<SupabaseEmergencySos | null> {
  try {
    const { data, error } = await supabase
      .from('emergency_sos')
      .select('*')
      .eq('status', 'Ambulance Dispatched')
      .order('created_at', { ascending: false })
      .limit(1);

    if (error || !data || data.length === 0) return null;
    return data[0];
  } catch (err) {
    return null;
  }
}

// Resolve Emergency SOS
export async function resolveEmergencySos(id?: string): Promise<boolean> {
  try {
    let query = supabase.from('emergency_sos').update({ status: 'Admitted & Resolved' });
    if (id) {
      query = query.eq('id', id);
    } else {
      query = query.eq('status', 'Ambulance Dispatched');
    }
    const { error } = await query;
    return !error;
  } catch (err) {
    return false;
  }
}
